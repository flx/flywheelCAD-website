"""
fuselage.py — glider fuselage component (body + cockpit + tail boom).

One smooth solid built by lofting full elliptical cross-sections along the
fore/aft axis (world +X). The sections grow from a rounded nose into the wide
pod / cockpit bulge, then taper down into a long slender tail boom — the whole
"body, cockpit and fuselage" as a single lofted piece. No hollowing.

World frame: +X = fore/aft (nose at 0), +Y = span (right), +Z = up.
Each section sits on a plane perpendicular to X (local u = +Y width, v = +Z height),
centred on the fuselage axis (Y = 0, Z = 0).
"""

import math

from flywheelcad import *
from profiles import ellipse_section
from config import MODEL_SCALE as S

cad = FlywheelCAD()

SECTION_POINTS = 18        # closed-spline control points per ellipse (smooth)
QUALITY = "preview"        # raise to "standard"/"high" for a finer surface (slower)

# The fuselage is a single lofted solid, so its first cross-section becomes the
# nose *face*. A lone small ellipse there reads as a blunt, flat-tipped cone — no
# single section can round the tip. Instead we grow the first full station back
# into a half-ellipsoid cap: extra cross-sections whose size follows a
# quarter-ellipse law so the surface sweeps smoothly to a rounded point.
#
# With  s = sin θ  (section scale) and  x = L(1 - cos θ)  (station position),
# the sections trace the ellipse  (x/L - 1)² + s² = 1  as θ runs 0 → 90°:
# a true point at the tip (θ→0, s→0) that meets the body at full size (θ=90°).
NOSE_JOIN = (120, 42, 58)   # first full body station the cap blends into
NOSE_SECTIONS = 7           # cap cross-sections ahead of the join (excl. tip/join)


def _nose_stations(join, n):
    """Half-ellipsoid nose cap: `n` (x, half_width, half_height) stations from a
    small rounded tip up to — but not including — the full `join` station."""
    xj, hwj, hhj = join
    out = []
    for k in range(1, n + 1):
        theta = (math.pi / 2) * k / (n + 1)   # in (0, 90°): skips tip and join
        s = math.sin(theta)
        out.append((xj * (1 - math.cos(theta)), hwj * s, hhj * s))
    return out


# (station_x, half_width, half_height) — nose -> pod/cockpit -> boom -> tail.
# In full-size units; every value is multiplied by MODEL_SCALE below.
STATIONS = _nose_stations(NOSE_JOIN, NOSE_SECTIONS) + [
    (120,   42,   58),     # cap meets the body here (half-ellipsoid equator)
    (320,   78,  104),
    (520,   96,  146),     # pod widest
    (720,   90,  166),     # cockpit bulge (tallest)
    (930,   76,  120),
    (1160,  50,   72),     # shoulder into the boom
    (1450,  32,   44),
    (1740,  22,   29),     # slender tail boom
    (1950,  15,   20),
    (2050,   9,   12),     # boom end
]


with cad.component("fuselage"):
    planes, regions = [], []
    for i, (x, hw, hh) in enumerate(STATIONS):
        x, hw, hh = x * S, hw * S, hh * S
        origin = cad.point(x, 0, 0)
        along_w = cad.point(x, 1, 0)    # local u = +Y (width)
        along_h = cad.point(x, 0, 1)    # local v = +Z (height)
        plane = cad.create_sketch_plane(origin, along_w, along_h, name="fuse_%d" % i)

        cad.with_sketch(plane)
        pts = [cad.point2d(u, v) for (u, v) in ellipse_section(hw, hh, SECTION_POINTS)]
        section = cad.spline2d(pts, closed=True)

        planes.append(plane)
        regions.append(cad.region(loop=[section], inside=(0, 0)))

    body = cad.multi_loft(planes, regions, quality=QUALITY)
    cad.set_color(body, "#F2EEE3", finish="matte")   # soft off-white gelcoat
    cad.component_export(body)

    # Anchors the assembly can mate to (mid-pod wing seat, boom-top tail seat).
    cad.component_export_point("wing_mount", cad.point(640 * S, 0, 95 * S))
    cad.component_export_point("tail_mount", cad.point(1850 * S, 0, 20 * S))

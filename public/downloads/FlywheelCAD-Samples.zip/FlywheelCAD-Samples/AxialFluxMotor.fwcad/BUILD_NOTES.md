# AxialFluxMotor — build notes

Double-rotor, coreless-stator (ironless) axial flux machine, ~400 mm OD
(stator plate radius 200 mm). 32 poles / 24 coils, 3-phase. This topology has
zero cogging, needs no laminations, and every structural part prints flat —
it is the same architecture proven by DIY axial-flux wind generators.

## Bill of materials (everything off-the-shelf)

| Qty | Part | Where |
|----:|------|-------|
| 64 | N42 neodymium block magnet **40 × 20 × 10 mm**, magnetized through 10 mm | Amazon / eBay / supermagnete / first4magnets |
| 2 | **6902** deep-groove ball bearing (15 × 28 × 7) | any bearing shop online |
| 1 | 15 mm precision shaft, 100 mm | eBay / linear-motion shops |
| 2 | 3 mm mild-steel disc, OD 370 / bore 68, 4 holes Ø4.4 at R40 | laser-cut service (SendCutSend, Fractory) — DXF from the `steel_disc` body |
| 8 | M4 × 30 cap screw + nyloc nut | hardware store |
| 6 | M5 screw (stator mounting) | hardware store |
| ~0.5 kg | 0.5–0.8 mm enamelled magnet wire | eBay / motor rewind suppliers |

## Printed parts (in the 3MF export)

- `stator_plate` — R200 × 14 mm disc, 24 coil windows, 6 × M5 mounts at R193
- `stator_hub` — bearing bush: two 6902 seats, press/glue into the plate bore
- `carrier_top` / `carrier_bot` — rotor discs with 32 magnet through-windows
- `hub_top` / `hub_bot` — rotor hubs (flange + 15 mm shaft boss; cross-drill
  for an M4 grub screw or pin after printing)
- `former0..23` — 24 identical coil winding formers (print all 24; each stays
  inside its coil)

Print flat, 40 %+ infill, PETG or better (magnets get warm under load).

Before exporting for print, set mesh quality to **High or Ultra** in the app
(or render with `--quality high`): the rotor hub is a boolean body and its
15 mm bore / M4 holes are coarse at Standard.

## Assembly order

1. Press the two 6902 bearings into the stator hub, glue hub into the plate.
2. Wind 24 coils directly around the printed formers (the winding bundle is
   8 mm wide x 10 mm tall all round); epoxy former + coil into the stator
   windows, wire as 3 phases x 8 coils (every 3rd coil is the same phase),
   star point in the middle.
3. Drop magnets into the carrier windows **on** the steel disc — polarity
   alternates N/S around the ring (red/blue in the model), and the two rotors
   must attract each other through the stator (opposite poles facing).
4. Bolt steel disc + carrier + rotor hub with 4 × M4 per rotor.
5. Slide the first rotor onto the shaft, shaft through the bearings, second
   rotor on. **Caution: the closing force between the rotors is hundreds of
   newtons — use threaded rod as a jig to lower the second rotor evenly.**

## Electromagnetic sanity numbers (estimates, not measurements)

- Magnetic gap between opposing magnet faces: 17 mm (14 stator + 2 × 1.5 air);
  N42 10 mm magnets facing each other give roughly **0.7 T** in the gap.
- Flux per pole ≈ 0.55 mWb → with 8 series coils per phase, phase EMF is about
  **1.0–1.2 V·s/rad per 100 turns per coil** (≈ 30 Vrms/phase at 300 rpm with
  50-turn coils). Pick turns for your controller voltage; more strands in
  parallel of thinner wire fills the same window with lower resistance.
- Electrical frequency: 16 pole pairs → 267 Hz at 1000 rpm; keep rpm modest
  or use a controller happy at high eRPM.

# flywheelcad-library: standard/bearings 1.0 (vendored 2026-07-04)
# Imported library file — do not edit; "Update from Library" overwrites it.

# flywheelcad standard library
"""Deep-groove ball bearings (metric, ISO 15 series), plain and flanged.

One revolved solid per bearing: inner ring, outer ring, and the seal
faces suggested by shallow V grooves at the ring seam — the catalog
cross-section without per-ball geometry. Flanged variants add the
locating flange at one face.

Common designations included (bore × OD × width, mm):
    623 3×10×4      624 4×13×5      625 5×16×5      626 6×19×6
    608 8×22×7      688 8×16×5      6000 10×26×8    6001 12×28×8
    6800 10×19×5    6801 12×21×5    6900 10×22×6    6902 15×28×7

Anchor contract:
    face_a   bore center on the z=0 face (flange side, when flanged)
    face_b   bore center on the opposite face
    center   bore center at mid-width

Orientation: axis along +Z, face_a on the world XY plane at z = 0.
"""

__library_version__ = "1.0"

# designation: bore Ø, outer Ø, width; flanged variants (F608 …) add
# flange Ø and thickness per the common catalog dimensions.
BEARING = {
    "623":  dict(bore=3.0,  od=10.0, w=4.0, flange_od=11.5, flange_t=1.0),
    "624":  dict(bore=4.0,  od=13.0, w=5.0, flange_od=15.0, flange_t=1.0),
    "625":  dict(bore=5.0,  od=16.0, w=5.0, flange_od=18.0, flange_t=1.2),
    "626":  dict(bore=6.0,  od=19.0, w=6.0, flange_od=22.0, flange_t=1.2),
    "608":  dict(bore=8.0,  od=22.0, w=7.0, flange_od=25.0, flange_t=1.5),
    "688":  dict(bore=8.0,  od=16.0, w=5.0, flange_od=18.0, flange_t=1.2),
    "6000": dict(bore=10.0, od=26.0, w=8.0, flange_od=29.0, flange_t=1.5),
    "6001": dict(bore=12.0, od=28.0, w=8.0, flange_od=31.0, flange_t=1.5),
    "6800": dict(bore=10.0, od=19.0, w=5.0, flange_od=21.0, flange_t=1.2),
    "6801": dict(bore=12.0, od=21.0, w=5.0, flange_od=23.0, flange_t=1.2),
    "6900": dict(bore=10.0, od=22.0, w=6.0, flange_od=25.0, flange_t=1.2),
    "6902": dict(bore=15.0, od=28.0, w=7.0, flange_od=31.0, flange_t=1.5),
}


def bearing(cad, designation="608", flanged=False, quality=None):
    """A deep-groove ball bearing (see module docstring for designations).

    designation: e.g. "608", "625", "6900"
    flanged:     True adds the locating flange at the z=0 face (F-series)

    Returns a component name for cad.instance(...). Anchors: face_a
    (z=0, flange side), face_b, center.
    """
    key = str(designation)
    d = BEARING[key]
    has_flange = bool(flanged)

    def build():
        bore_r, outer_r, w = d["bore"] / 2.0, d["od"] / 2.0, d["w"]
        seam_r = (bore_r + outer_r) / 2.0     # inner/outer ring seam radius
        groove = min(0.6, w * 0.12)           # V-groove depth at each face
        gw = min(1.2, (outer_r - bore_r) * 0.25)

        # Cross-section on zx as (radius, height): a rectangle from bore to
        # OD with a shallow V notch at each face on the seam radius, plus
        # the flange step at z=0 when flanged.
        cad.with_sketch("zx")
        pts = []

        def P(r, z):
            pts.append(cad.point2d(r, z))

        P(bore_r, 0.0)                      # bottom of the bore wall
        if has_flange:
            fr = d["flange_od"] / 2.0
            ft = d["flange_t"]
            P(fr, 0.0)                      # out along the flange face
            P(fr, ft)                       # up the flange rim
            P(outer_r, ft)                  # back in to the OD
            P(outer_r, w)                   # up the OD wall
        else:
            P(seam_r - gw / 2.0, 0.0)
            P(seam_r, groove)               # V notch, bottom face
            P(seam_r + gw / 2.0, 0.0)
            P(outer_r, 0.0)
            P(outer_r, w)
        P(seam_r + gw / 2.0, w)
        P(seam_r, w - groove)               # V notch, top face
        P(seam_r - gw / 2.0, w)
        P(bore_r, w)                        # top of the bore wall

        lines = [cad.line2d(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
        lines.append(cad.line2d(pts[-1], pts[0]))  # close down the bore wall

        # The ring cross-section is annular (never touches radius 0), so the
        # revolve axis is a separate construction line along r = 0.
        axis_line = cad.line2d(cad.point2d(0.0, 0.0), cad.point2d(0.0, w),
                               construction=True)
        ring = cad.revolve("zx",
                           cad.region(loop=lines,
                                      inside=((bore_r + seam_r) / 2.0, w / 2.0)),
                           axis_line=axis_line, angle=360.0, quality=quality)
        cad.set_color(ring, "#B0BEC5", finish="metallic")
        cad.component_export(ring)

        cad.component_export_point("face_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("face_b", cad.point(0.0, 0.0, w))
        cad.component_export_point("center", cad.point(0.0, 0.0, w / 2.0))

    return cad.parametric(f"bearing_{key}", build,
                          flanged=has_flange, quality=quality or "std")

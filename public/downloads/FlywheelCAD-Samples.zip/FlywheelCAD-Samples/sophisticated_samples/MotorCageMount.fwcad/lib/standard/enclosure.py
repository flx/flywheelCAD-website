# flywheelcad standard library
"""Enclosure hardware: DIN rail, latches, handles and vents.

`modules` already ships relay boards, buck converters and stepper drivers —
all of which mount to DIN rail — but the rail itself was missing, so a control
box could not be assembled from the library alone. These are the parts that
turn a box into an enclosure.

Anchor contract:
    din_rail     : end_a (z=0), end_b, mid  (rail runs along +Z, back on XY)
    draw_latch   : base (mounting face centre), hook, hole_a, hole_b
    handle       : center, foot_a, foot_b  (the two mounting feet)
    vent_grille  : center, corner  (plate on XY, slots cut through)

Orientation: mounting face on the world XY plane, part standing up in +Z.
"""

__library_version__ = "1.0"

_STEEL = "#B0BEC5"
_ZINC = "#9EA7AD"
_PLASTIC = "#37474F"

# TS35 "top hat" DIN rail (EN 60715): 35 mm across the hat, 7.5 mm deep,
# 1 mm stock, 27 mm between the lip centres.
_TS35 = dict(width=35.0, depth=7.5, stock=1.0, base=27.0)

PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "din_rail": {"size": ["TS35"]},
    "vent_grille": {"pattern": ["slots", "grid"]},
}


def _plane_at(cad, z):
    return cad.create_sketch_plane(cad.point(0, 0, z), cad.point(1, 0, z), cad.point(0, 1, z))


def _rect_region(cad, cx, cy, w, h):
    x0, y0 = cx - w / 2.0, cy - h / 2.0
    p = [cad.point2d(x0, y0), cad.point2d(x0 + w, y0),
         cad.point2d(x0 + w, y0 + h), cad.point2d(x0, y0 + h)]
    ls = [cad.line2d(p[i], p[(i + 1) % 4]) for i in range(4)]
    return cad.region(loop=ls, inside=(cx, cy))


def din_rail(cad, length=150.0, size="TS35", quality=None):
    """A TS35 top-hat DIN rail (EN 60715): the 35 mm hat section every
    din-mount module in `modules` clips onto.

    The profile is a real top hat, built as five strips of 1 mm stock: a
    27 mm base that sits against the panel, two webs rising 7.5 mm, and two
    flanges turning back OUTWARD to the full 35 mm width. Those outer flanges
    are the whole point — they are what a module's clip grabs. (A plain
    U-channel of the right envelope looks similar in a thumbnail and nothing
    can clip to it.)

    Anchors: end_a (z=0), end_b, mid."""
    length = float(length)
    s = _TS35
    w, d, t = s["width"], s["depth"], s["stock"]
    base_w = s["base"]                          # flat part against the panel

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        strips = []
        # 1. Base, against the panel.
        strips.append(cad.extrude(p, _rect_region(cad, 0.0, t / 2.0, base_w, t),
                                  length, quality=quality, export=False))
        for sgn in (-1.0, 1.0):
            # 2/3. Webs rising from the base edges.
            wx = sgn * (base_w / 2.0 - t / 2.0)
            strips.append(cad.extrude(p, _rect_region(cad, wx, d / 2.0, t, d),
                                      length, quality=quality, export=False))
            # 4/5. Flanges turning outward at the top — the clip surfaces.
            # Span from the web's OUTER face to the full 35 mm envelope.
            fw = (w - base_w) / 2.0
            fx = sgn * (w / 2.0 - fw / 2.0)
            strips.append(cad.extrude(p, _rect_region(cad, fx, d - t / 2.0, fw, t),
                                      length, quality=quality, export=False))
        part = cad.bool_union(*strips, quality=quality, export=False)
        cad.set_color(part, _ZINC, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, length))
        cad.component_export_point("mid", cad.point(0.0, 0.0, length / 2.0))

    return cad.parametric("din_rail", build,
                          length=length, size="TS35", quality=quality or "std",
                          label=f"DIN rail TS35 x{length:g}")


def draw_latch(cad, size=60.0, quality=None):
    """A draw (toggle) latch: the base plate that screws to the enclosure and
    the hooked lever that pulls a lid down. Modelled closed.

    size: overall base length, mm. Anchors: base, hook, hole_a, hole_b."""
    L = float(size)
    W = L * 0.35
    t = max(1.5, L * 0.03)
    hole_d = 4.2
    hx = L / 2.0 - W * 0.35

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        base = cad.extrude(p, _rect_region(cad, 0.0, 0.0, L, W), t,
                           quality=quality, export=False)
        # The lever: a shorter plate standing proud of the base.
        lp = _plane_at(cad, t)
        cad.with_sketch(lp)
        lever = cad.extrude(lp, _rect_region(cad, -L * 0.1, 0.0, L * 0.65, W * 0.7),
                            t * 1.6, quality=quality, export=False)
        # The hook: a small tab turned up at the free end.
        hp = cad.create_sketch_plane(cad.point(L * 0.30, 0, 0), cad.point(L * 0.30, 1, 0),
                                     cad.point(L * 0.30, 0, 1))
        cad.with_sketch(hp)
        hook = cad.extrude(hp, _rect_region(cad, 0.0, t * 2.2, W * 0.5, t * 3.0),
                           t * 1.4, quality=quality, export=False)
        part = cad.bool_union(base, lever, hook, quality=quality, export=False)
        # Two fixing holes, one at each end of the base.
        dp = _plane_at(cad, -1.0)
        cad.with_sketch(dp)
        drills = []
        for x in (-hx, hx):
            c = cad.circle2d(cad.point2d(x, 0.0), hole_d / 2.0)
            drills.append(cad.extrude(dp, cad.region(loop=[c], inside=(x, 0.0)),
                                      t + 2.0, quality=quality, export=False))
        part = cad.bool_difference(part, *drills, quality=quality, export=False)
        cad.set_color(part, _STEEL, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("hook", cad.point(L * 0.30, 0.0, t * 3.5))
        cad.component_export_point("hole_a", cad.point(-hx, 0.0, 0.0))
        cad.component_export_point("hole_b", cad.point(hx, 0.0, 0.0))

    return cad.parametric("draw_latch", build,
                          size=L, quality=quality or "std",
                          label=f"Draw latch {L:g}mm")


def handle(cad, span=120.0, height=32.0, bar_d=12.0, quality=None):
    """A U-shaped pull handle: two feet and a round bar between them.

    span   : centre-to-centre of the mounting feet, mm.
    height : how far the bar stands off the panel.
    Anchors: center (bar mid), foot_a, foot_b (panel faces)."""
    span = float(span)
    height = float(height)
    r = float(bar_d) / 2.0
    foot = bar_d * 1.6
    ft = max(3.0, bar_d * 0.3)
    hole_d = 5.2

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        feet = []
        for x in (-span / 2.0, span / 2.0):
            feet.append(cad.extrude(p, _rect_region(cad, x, 0.0, foot, foot), ft,
                                    quality=quality, export=False))
        # Uprights and the crossbar.
        posts = []
        for x in (-span / 2.0, span / 2.0):
            pp = _plane_at(cad, ft)
            cad.with_sketch(pp)
            c = cad.circle2d(cad.point2d(x, 0.0), r)
            posts.append(cad.extrude(pp, cad.region(loop=[c], inside=(x, 0.0)),
                                     height - ft, quality=quality, export=False))
        bp = cad.create_sketch_plane(cad.point(-span / 2.0, 0, height),
                                     cad.point(-span / 2.0, 1, height),
                                     cad.point(-span / 2.0, 0, height + 1))
        cad.with_sketch(bp)
        bc = cad.circle2d(cad.point2d(0.0, 0.0), r)
        bar = cad.extrude(bp, cad.region(loop=[bc], inside=(0.0, 0.0)), span,
                          quality=quality, export=False)
        part = cad.bool_union(*(feet + posts + [bar]), quality=quality, export=False)
        dp = _plane_at(cad, -1.0)
        cad.with_sketch(dp)
        drills = []
        for x in (-span / 2.0, span / 2.0):
            c = cad.circle2d(cad.point2d(x, 0.0), hole_d / 2.0)
            drills.append(cad.extrude(dp, cad.region(loop=[c], inside=(x, 0.0)),
                                      ft + 2.0, quality=quality, export=False))
        part = cad.bool_difference(part, *drills, quality=quality, export=False)
        cad.set_color(part, _STEEL, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, height))
        cad.component_export_point("foot_a", cad.point(-span / 2.0, 0.0, 0.0))
        cad.component_export_point("foot_b", cad.point(span / 2.0, 0.0, 0.0))

    return cad.parametric("handle", build,
                          span=span, height=height, bar=bar_d,
                          quality=quality or "std",
                          label=f"Handle {span:g}mm")


def vent_grille(cad, width=60.0, height=40.0, pattern="slots", quality=None):
    """A ventilation panel: a plate with a louvre pattern cut through, for
    dropping into an enclosure wall.

    pattern: "slots" — parallel louvres (the usual pressed-panel look).
             "grid"  — a square hole array.
    Anchors: center, corner."""
    W, H = float(width), float(height)
    pattern = str(pattern).lower()
    t = 2.0
    margin = 5.0

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        plate = cad.extrude(p, _rect_region(cad, 0.0, 0.0, W, H), t,
                            quality=quality, export=False)
        cp = _plane_at(cad, -1.0)
        cad.with_sketch(cp)
        cuts = []
        if pattern == "grid":
            hole, pitch = 3.0, 6.0
            nx = max(int((W - 2 * margin) // pitch), 1)
            ny = max(int((H - 2 * margin) // pitch), 1)
            for ix in range(nx):
                for iy in range(ny):
                    cx = (-(nx - 1) / 2.0 + ix) * pitch
                    cy = (-(ny - 1) / 2.0 + iy) * pitch
                    cuts.append(cad.extrude(cp, _rect_region(cad, cx, cy, hole, hole),
                                            t + 2.0, quality=quality, export=False))
        else:
            slot_h, pitch = 3.0, 7.0
            slot_w = W - 2 * margin
            n = max(int((H - 2 * margin) // pitch), 1)
            for i in range(n):
                cy = (-(n - 1) / 2.0 + i) * pitch
                cuts.append(cad.extrude(cp, _rect_region(cad, 0.0, cy, slot_w, slot_h),
                                        t + 2.0, quality=quality, export=False))
        part = cad.bool_difference(plate, *cuts, quality=quality, export=False)
        cad.set_color(part, _PLASTIC, finish="matte")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, t))
        cad.component_export_point("corner", cad.point(-W / 2.0, -H / 2.0, t))

    return cad.parametric("vent_grille", build,
                          w=W, h=H, pattern=pattern, quality=quality or "std",
                          label=f"Vent grille {W:g}x{H:g} {pattern}")

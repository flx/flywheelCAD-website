# flywheelcad standard library
"""T-slot framing hardware: the parts that JOIN the rails in `extrusions`.

`extrusions.rail` gives you the profile; nothing in the library previously
connected two of them, so every frame started by hand-modelling these four.

Every part is driven from `extrusions.SERIES`, so a `t_slot_nut` for the 20
series is sized against the same slot the 20-series rail actually cuts —
opening width, neck depth and cavity width all come from one table rather than
being re-typed here. Change the rail profile and the hardware follows.

Anchor contract:
    t_slot_nut     : center (thread axis, at the nut's seating face), back
    corner_bracket : corner (inside corner), arm_a_hole, arm_b_hole
    angle_plate    : center, hole_<i> (each fixing hole, in order)
    end_cap        : center (outer face), back (the face against the rail)

Orientation: each part sits with its mounting face on the world XY plane and
its thread/insert axis along +Z unless the docstring says otherwise.
"""

__library_version__ = "1.0"

from .extrusions import SERIES

# Common fastener sizes per extrusion series (the tap the slot is used with).
_THREAD_FOR = {20: 5.0, 30: 8.0, 40: 10.0}

_STEEL = "#B0BEC5"
_ALU = "#CFD8DC"


def _series(size):
    """Accept 20 / "20" / "2020" and return the SERIES dict."""
    key = str(size)
    if key.isdigit() and len(key) == 4:
        key = key[:2]
    n = int(key)
    if n not in SERIES:
        raise ValueError(f"unknown extrusion series {size!r}; have {sorted(SERIES)}")
    return n, SERIES[n]


def _rect(cad, plane, cx, cy, w, h):
    """A centred rectangle region on `plane`."""
    x0, y0 = cx - w / 2.0, cy - h / 2.0
    p = [cad.point2d(x0, y0), cad.point2d(x0 + w, y0),
         cad.point2d(x0 + w, y0 + h), cad.point2d(x0, y0 + h)]
    ls = [cad.line2d(p[i], p[(i + 1) % 4]) for i in range(4)]
    return cad.region(loop=ls, inside=(cx, cy))


def t_slot_nut(cad, size=20, thread=None, style="tee", quality=None):
    """A T-slot nut: the sliding block that drops into a rail slot and takes a
    screw from outside.

    size   : extrusion series (20 / 30 / 40, or a profile name like "2020").
    thread : tapped hole diameter, mm. Defaults to the series' usual size
             (M5 / M8 / M10).
    style  : "tee"   — the standard tee section, slid in from the rail end.
             "drop"  — a plain rectangular block, dropped in anywhere along
                       the slot and turned 90 deg to lock (a "post-assembly"
                       nut). Same envelope, no neck.

    Sized from `extrusions.SERIES`: the body is the slot CAVITY width minus a
    sliding clearance, and the neck matches the slot OPENING, so the nut seats
    in the cavity and cannot pull through the opening. Anchors: center (thread
    axis at the seating face), back.
    """
    n, s = _series(size)
    thread = float(thread if thread is not None else _THREAD_FOR[n])
    style = str(style).lower()
    clear = 0.4                                   # sliding fit in the cavity
    body_w = s["cavity_w"] - clear
    body_h = s["cavity_d"] - 0.2
    neck_w = s["slot_w"] - clear
    neck_h = s["neck"]
    length = body_w                               # square-ish in plan

    def build():
        base = cad.create_sketch_plane(cad.point(0, 0, 0), cad.point(1, 0, 0), cad.point(0, 1, 0))
        cad.with_sketch(base)
        block = cad.extrude(base, _rect(cad, base, 0, 0, body_w, length),
                            body_h, quality=quality, export=False)
        part = block
        if style == "tee":
            top = cad.create_sketch_plane(cad.point(0, 0, body_h), cad.point(1, 0, body_h),
                                          cad.point(0, 1, body_h))
            cad.with_sketch(top)
            neck = cad.extrude(top, _rect(cad, top, 0, 0, neck_w, length),
                               neck_h, quality=quality, export=False)
            part = cad.bool_union(block, neck, quality=quality, export=False)
        # Tapped hole through the whole stack, on the insert axis.
        total = body_h + (neck_h if style == "tee" else 0.0)
        hp = cad.create_sketch_plane(cad.point(0, 0, -1), cad.point(1, 0, -1), cad.point(0, 1, -1))
        cad.with_sketch(hp)
        hc = cad.circle2d(cad.point2d(0.0, 0.0), thread / 2.0)
        drill = cad.extrude(hp, cad.region(loop=[hc], inside=(0.0, 0.0)),
                            total + 2.0, quality=quality, export=False)
        part = cad.bool_difference(part, drill, quality=quality, export=False)
        cad.set_color(part, _STEEL, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, total))
        cad.component_export_point("back", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("t_slot_nut", build,
                          series=n, thread=thread, style=style,
                          quality=quality or "std",
                          label=f"T-slot nut {n} series M{thread:g}")


def corner_bracket(cad, size=20, thickness=None, gusset=True, quality=None):
    """An L bracket joining two rails at 90 deg: two arms, each with a
    clearance slot for a screw into a rail slot, and an optional triangular
    gusset across the inside corner.

    size      : extrusion series; the arm width matches the rail cell.
    thickness : plate thickness, mm (default: series/5, i.e. 4 mm at 20).
    gusset    : add the corner web (stiffens it; leave off for a low-profile
                bracket that clears an adjacent rail).

    Anchors: corner (the inside corner at the base plane), arm_a_hole,
    arm_b_hole (each screw axis, on the outer face of its arm).
    """
    n, s = _series(size)
    cell = s["cell"]
    t = float(thickness if thickness is not None else cell / 5.0)
    arm = cell                                    # one cell long per arm
    hole_d = _THREAD_FOR[n] + 0.6                 # clearance, not tapped
    hole_at = arm / 2.0

    def build():
        # Arm A lies along +X (plate z = 0..t), arm B rises along +Z (plate
        # x = -t..0); both `arm` long, `cell` wide, centred on y = 0.
        #
        # NOTE on the sketch frames below: a plane's u/v axes come from its
        # NORMAL, not from the three points that defined it. Arm B's plane and
        # the gusset's plane both have a normal that is not +Z, so their (u, v)
        # are NOT (x, z) — writing them as if they were put arm B in the wrong
        # place entirely and threw the gusset clear of the bracket. Each frame
        # is spelled out where it is used.
        pa = cad.create_sketch_plane(cad.point(0, 0, 0), cad.point(1, 0, 0), cad.point(0, 1, 0))
        cad.with_sketch(pa)
        a = cad.extrude(pa, _rect(cad, pa, arm / 2.0, 0.0, arm, cell), t,
                        quality=quality, export=False)
        # normal -X  ->  u = -Y, v = +Z. So (u, v) = (-y, z): the rect is
        # centred across the width and runs 0..arm UP.
        pb = cad.create_sketch_plane(cad.point(0, 0, 0), cad.point(0, 0, 1), cad.point(0, 1, 0))
        cad.with_sketch(pb)
        b = cad.extrude(pb, _rect(cad, pb, 0.0, arm / 2.0, cell, arm), t,
                        quality=quality, export=False)
        part = cad.bool_union(a, b, quality=quality, export=False)
        if gusset:
            # normal -Y  ->  u = +X, v = +Z, and the extrude runs -Y. Starting
            # at y = +cell/2 therefore fills -cell/2..+cell/2, flush with the
            # arms; starting at -cell/2 (as this once did) puts the whole web
            # outside the bracket.
            gp = cad.create_sketch_plane(cad.point(0, cell / 2.0, 0),
                                         cad.point(1, cell / 2.0, 0),
                                         cad.point(0, cell / 2.0, 1))
            cad.with_sketch(gp)
            g = arm * 0.7
            # The right angle sits on arm B's inner face (x = -t) at the base
            # (z = 0), so the web genuinely OVERLAPS both arms rather than
            # touching them — a union of merely-touching solids is not one solid.
            tri = [cad.point2d(-t, 0.0), cad.point2d(g, 0.0), cad.point2d(-t, g)]
            ls = [cad.line2d(tri[i], tri[(i + 1) % 3]) for i in range(3)]
            web = cad.extrude(gp, cad.region(loop=ls, inside=(0.0, g / 4.0)),
                              cell, quality=quality, export=False)
            part = cad.bool_union(part, web, quality=quality, export=False)
        # One clearance hole per arm.
        ha = cad.create_sketch_plane(cad.point(0, 0, -1), cad.point(1, 0, -1), cad.point(0, 1, -1))
        cad.with_sketch(ha)
        ca = cad.circle2d(cad.point2d(hole_at, 0.0), hole_d / 2.0)
        da = cad.extrude(ha, cad.region(loop=[ca], inside=(hole_at, 0.0)), t + 2.0,
                         quality=quality, export=False)
        # Same -X normal as arm B (u = -Y, v = +Z), and the extrude runs -X —
        # so the cutter starts just OUTSIDE the arm at x = +1 and drills back
        # through it. Started at x = -1 it drilled away from the arm entirely.
        hb = cad.create_sketch_plane(cad.point(1, 0, 0), cad.point(1, 0, 1), cad.point(1, 1, 0))
        cad.with_sketch(hb)
        cb = cad.circle2d(cad.point2d(0.0, hole_at), hole_d / 2.0)
        db = cad.extrude(hb, cad.region(loop=[cb], inside=(0.0, hole_at)), t + 2.0,
                         quality=quality, export=False)
        part = cad.bool_difference(part, da, db, quality=quality, export=False)
        cad.set_color(part, _ALU, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("corner", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("arm_a_hole", cad.point(hole_at, 0.0, 0.0))
        cad.component_export_point("arm_b_hole", cad.point(0.0, 0.0, hole_at))

    return cad.parametric("corner_bracket", build,
                          series=n, t=t, gusset=bool(gusset),
                          quality=quality or "std",
                          label=f"Corner bracket {n} series")


def angle_plate(cad, size=20, holes=2, thickness=None, quality=None):
    """A flat joining plate (straight, not cornered): a strip with a row of
    clearance holes on the rail's cell pitch, for splicing two rails end to
    end or stiffening a joint from one face.

    holes: number of holes in the row (>= 2), spaced one cell apart.

    Anchors: center, hole_0 … hole_<n-1>.
    """
    n, s = _series(size)
    cell = s["cell"]
    holes = max(int(holes), 2)
    t = float(thickness if thickness is not None else cell / 5.0)
    hole_d = _THREAD_FOR[n] + 0.6
    length = cell * holes
    xs = [(-(holes - 1) / 2.0 + i) * cell for i in range(holes)]

    def build():
        p = cad.create_sketch_plane(cad.point(0, 0, 0), cad.point(1, 0, 0), cad.point(0, 1, 0))
        cad.with_sketch(p)
        plate = cad.extrude(p, _rect(cad, p, 0.0, 0.0, length, cell), t,
                            quality=quality, export=False)
        hp = cad.create_sketch_plane(cad.point(0, 0, -1), cad.point(1, 0, -1), cad.point(0, 1, -1))
        cad.with_sketch(hp)
        drills = []
        for x in xs:
            c = cad.circle2d(cad.point2d(x, 0.0), hole_d / 2.0)
            drills.append(cad.extrude(hp, cad.region(loop=[c], inside=(x, 0.0)),
                                      t + 2.0, quality=quality, export=False))
        part = cad.bool_difference(plate, *drills, quality=quality, export=False)
        cad.set_color(part, _ALU, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, t))
        for i, x in enumerate(xs):
            cad.component_export_point(f"hole_{i}", cad.point(x, 0.0, t))

    return cad.parametric("angle_plate", build,
                          series=n, holes=holes, t=t, quality=quality or "std",
                          label=f"Joining plate {n} series x{holes}")


def end_cap(cad, size="2020", thickness=2.5, quality=None):
    """A moulded end cap that closes a rail's open end: a plate the size of the
    profile envelope with short spigots that push into the cell bores.

    size: a PROFILE name ("2020", "2040", "4040" …) — the cap covers the whole
          profile, so it needs the cell grid, not just the series.

    Anchors: center (outer face), back (the face against the rail).
    """
    from .extrusions import PROFILES
    key = str(size)
    if key not in PROFILES:
        raise ValueError(f"unknown profile {size!r}; have {sorted(PROFILES)}")
    n, nx, ny = PROFILES[key]
    s = SERIES[n]
    cell = s["cell"]
    t = float(thickness)
    w, h = cell * nx, cell * ny
    spigot_d = s["bore_d"] - 0.3
    spigot_l = cell * 0.25

    def build():
        p = cad.create_sketch_plane(cad.point(0, 0, 0), cad.point(1, 0, 0), cad.point(0, 1, 0))
        cad.with_sketch(p)
        cap = cad.extrude(p, _rect(cad, p, 0.0, 0.0, w, h), t, quality=quality, export=False)
        sp = cad.create_sketch_plane(cad.point(0, 0, t), cad.point(1, 0, t), cad.point(0, 1, t))
        cad.with_sketch(sp)
        pegs = []
        for ix in range(nx):
            for iy in range(ny):
                cx = (-(nx - 1) / 2.0 + ix) * cell
                cy = (-(ny - 1) / 2.0 + iy) * cell
                c = cad.circle2d(cad.point2d(cx, cy), spigot_d / 2.0)
                pegs.append(cad.extrude(sp, cad.region(loop=[c], inside=(cx, cy)),
                                        spigot_l, quality=quality, export=False))
        part = cad.bool_union(cap, *pegs, quality=quality, export=False)
        cad.set_color(part, "#37474F", finish="matte")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("back", cad.point(0.0, 0.0, t))

    return cad.parametric("end_cap", build,
                          profile=key, t=t, quality=quality or "std",
                          label=f"End cap {key}")

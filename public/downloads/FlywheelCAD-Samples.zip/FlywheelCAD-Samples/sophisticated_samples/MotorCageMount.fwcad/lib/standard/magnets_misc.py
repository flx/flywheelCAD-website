# flywheelcad standard library
"""Magnets and small rubber/plastic hardware: neodymium magnets (disc, ring,
block), rubber bumper feet, and panel grommets.

Dimensions are common catalog sizes (magnets: standard neodymium stock sizes;
feet: adhesive/screw bumper classes; grommets: nominal panel-hole fits). All
are simple representative solids — the numbers you design cavities and pockets
around, not precision parts.

Anchor contract:
    magnet       bottom (z=0), top, center
    rubber_foot  base (z=0, the mounting face), top
    grommet      bottom (z=0), top ; the panel seats in the middle groove

Orientation: axis / thickness along +Z, the seating face on world XY at z = 0.
"""

__library_version__ = "1.0"

# Dropdown choices for the browser's "Insert from Library" form.
# Literal lists only (the app's AST scan ignores variables / list(...) calls).
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "magnet": {"shape": ["disc", "ring", "block"]},
    "rubber_foot": {"size": ["small", "medium", "large"]},
}

# Rubber foot classes: base Ø, top Ø, height, screw-pocket Ø (mm).
FOOT = {
    "small":  dict(base=8.0,  top=6.0,  height=4.0,  pocket=3.2),
    "medium": dict(base=12.0, top=9.0,  height=6.0,  pocket=4.0),
    "large":  dict(base=20.0, top=15.0, height=10.0, pocket=5.0),
}

_STEEL = "#B0BEC5"
_RUBBER = "#212121"


def _revolve(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) ZX profile about r = 0.

    on_axis=True: the profile touches r=0 and the closing edge is the axis.
    on_axis=False: annular profile — a separate r=0 construction axis is used.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def magnet(cad, shape="disc", diameter=10.0, bore=0.0, thickness=3.0, quality=None):
    """A neodymium magnet. shape: "disc" (solid cyl), "ring" (annular, uses
    `bore` as the hole Ø), or "block" (square prism, side = `diameter`).

    Anchors: bottom (z=0), top, center."""
    kind = str(shape)
    diameter = float(diameter)
    thickness = float(thickness)
    bore = float(bore)
    r = diameter / 2.0

    def build():
        if kind == "block":
            cad.with_sketch("xy")
            h = diameter / 2.0
            a = cad.point2d(-h, -h)
            b = cad.point2d(h, -h)
            c = cad.point2d(h, h)
            d = cad.point2d(-h, h)
            m = cad.extrude("xy",
                            cad.region(loop=[cad.line2d(a, b), cad.line2d(b, c),
                                             cad.line2d(c, d), cad.line2d(d, a)],
                                       inside=(0.0, 0.0)),
                            thickness, export=False)
        elif kind == "ring":
            br = max(bore, 1.0) / 2.0
            m = _revolve(cad, [(br, 0.0), (r, 0.0), (r, thickness), (br, thickness)],
                         inside=((br + r) / 2.0, thickness / 2.0), quality=quality,
                         on_axis=False)
        else:  # disc
            m = _revolve(cad, [(0.0, 0.0), (r, 0.0), (r, thickness), (0.0, thickness)],
                         inside=(r / 2.0, thickness / 2.0), quality=quality)
        cad.set_color(m, _STEEL, finish="metallic")
        cad.component_export(m)
        cad.component_export_point("bottom", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, thickness))
        cad.component_export_point("center", cad.point(0.0, 0.0, thickness / 2.0))

    return cad.parametric("magnet", build,
                          shape=kind, d=diameter, bore=bore, t=thickness,
                          quality=quality or "std",
                          label=f"{kind.title()} magnet Ø{diameter:g}x{thickness:g}")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def rubber_foot(cad, size="medium", quality=None):
    """A rubber bumper foot: a truncated cone with a central screw through-hole.
    One annular revolve (bore wall -> outer slant). Anchors: base (z=0, mounting
    face), top."""
    key = str(size)
    d = FOOT[key]
    base_r, top_r, h = d["base"] / 2.0, d["top"] / 2.0, d["height"]
    hole_r = d["pocket"] / 2.0

    def build():
        # Annular cross-section: bore wall at r=hole_r up to the outer frustum;
        # a separate r=0 construction axis carries the revolve.
        foot = _revolve(cad, [
            (hole_r, 0.0), (base_r, 0.0), (top_r, h), (hole_r, h),
        ], inside=((hole_r + base_r) / 2.0, h / 2.0), quality=quality, on_axis=False)
        cad.set_color(foot, _RUBBER, finish="glossy")
        cad.component_export(foot)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, h))

    return cad.parametric("foot", build, size=key, quality=quality or "std",
                          label=f"{key.title()} rubber foot")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def grommet(cad, panel_bore=8.0, thickness=1.5, quality=None):
    """A rubber panel grommet (spool): flanges grip a panel of `thickness`
    seated in the middle groove; a cable passes through the inner bore.
    `panel_bore` is the panel hole Ø the grommet snaps into. Anchors: bottom
    (z=0), top."""
    panel_bore = float(panel_bore)
    thickness = float(thickness)
    groove_r = panel_bore / 2.0                 # sits in the panel hole
    flange_r = groove_r + 2.0                    # flanges overhang the panel
    inner_r = max(groove_r - 2.0, 1.5)           # cable bore
    flange_t = 1.5
    total = 2.0 * flange_t + thickness

    def build():
        g = _revolve(cad, [
            (inner_r, 0.0), (flange_r, 0.0), (flange_r, flange_t),
            (groove_r, flange_t), (groove_r, flange_t + thickness),
            (flange_r, flange_t + thickness), (flange_r, total), (inner_r, total),
        ], inside=((inner_r + groove_r) / 2.0, total / 2.0), quality=quality,
           on_axis=False)
        cad.set_color(g, _RUBBER, finish="matte")
        cad.component_export(g)
        cad.component_export_point("bottom", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, total))

    return cad.parametric("grommet", build,
                          bore=panel_bore, t=thickness, quality=quality or "std",
                          label=f"Grommet Ø{panel_bore:g} panel")

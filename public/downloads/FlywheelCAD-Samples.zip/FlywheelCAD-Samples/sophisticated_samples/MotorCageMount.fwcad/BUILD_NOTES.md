# Motor cage mount — build notes

A 240 × 240 × 220 mm 20-series aluminium extrusion cage with a NEMA 23 hung
under a mount plate on four rubber isolators. Fourteen rails, real joining
hardware, a vented front panel with an 80 mm fan behind it, and a DIN rail
across the floor carrying the driver and a buck converter.

## What this sample is for

Everything except **two plates** is a standard-library part. That is the
lesson: a frame like this is 95 % catalog, and the design work is deciding
where the two custom plates go and what holes they carry. The file is
therefore mostly *placement* code — and placement is where T-slot framing
actually goes wrong.

| Drawn here | Everything else |
|---|---|
| `mount_plate` — 200 × 120 × 8 aluminium, NEMA 23 interface + isolator holes | 14 rails, 8 corner brackets, 4 splice plates, 28 T-slot nuts, 32 screws, 4 end caps, 8 rubber feet, the stepper, the DIN rail, the driver, the buck converter, the fan, the grille, the switch, the gland, the handle, the clips |
| `vent_panel` — 240 × 120 × 3 aluminium | |

## What is editable, and where

| You want to change | Do it |
|---|---|
| plate size, motor boss bore, panel size and thickness | **In the app** — `V_PLATE_L`, `V_PLATE_W`, `V_PLATE_T`, `V_MOTOR_BOSS_R`, `V_PANEL_W/H/T`; both plates are constrained rectangles (parallel/perpendicular, not four loose points) with distance dimensions bound to those variables |
| cage size, deck height, isolator spacing, hole patterns | **In `main.py`** — `CAGE_W/D/H`, `Z_DECK`, `X_ISO`/`Y_ISO`. Every rail length and every piece of hardware is computed from them, so changing `CAGE_W` and re-running rebuilds the whole frame |

## Three placement traps this file works around

**1. A rail component always extrudes +Z.** `extrusions.rail` puts the profile
CORNER at the sketch origin and runs the rail up +Z, so every horizontal rail
is that same component given a quarter turn. Rotating +Z onto +X drops the
profile to z = −CELL…0, which is why `rail_x` / `rail_y` add a cell back — the
caller then says where the rail's low corner goes and means it.

**2. A corner bracket has a handedness.** `framing.corner_bracket` is an L
whose horizontal arm lies on a rail's top face running +X, with the vertical
plate on the −X side of the corner. So each bracket goes at the post's inner
face *pushed out by one plate thickness* (its own vertical arm fills that gap)
and turned to face along the beam it ties. Get this wrong and the bracket is
4 mm inside the post.

**3. A T-slot nut has to end up in the cavity.** Every screw here is placed at
a bracket's published anchor, and its nut is pushed back along the *screw's
own axis* by the plate thickness plus the nut's height. That lands the nut in
the slot with its seating face against the lips, whichever way the screw
points — and it keeps working if the library re-proportions the bracket.

## Assembly order

1. Cut the rails: 4 × 220 (uprights), 10 × 200 (rings and cross-members).
2. Bottom ring: post, beam, corner bracket, two M5 into two T-nuts, repeat.
   Square it before tightening — a T-slot frame is only square if you make it.
3. Uprights, then the top ring; splice each top corner with a flat plate.
4. Cross-members at 100 mm, both ends into the side rails' slots.
5. Rubber isolators on the cross-members, mount plate on top, M5 × 25 down
   through plate + rubber into the T-nuts.
6. NEMA 23 up under the plate, shaft through the boss bore, four M5 × 16 from
   above.
7. DIN rail on the floor, driver and buck converter clipped on.
8. Vent panel from inside onto the two uprights' rear slots; 80 mm fan on its
   inner face over the window, grille on the outer face; switch and gland in
   the panel.
9. End caps on the upright tops, rubber feet underneath.

## Notes on the model

- **Mesh:** the mount plate meshes exactly (1 200 triangles). The vent panel
  does not — a small hole close to the edge of a large thin plate takes a body
  off the exact-mesh path and onto the sampled one, and the panel's four M5s
  are 10 mm in from a 240 mm edge. That costs triangles, not accuracy: a
  volume check against the analytic figure agrees to 0.06 %, so every hole is
  there. If the triangle count matters for your export, `set_cell_size` is the
  knob.
- **The frame is not modelled below the cage.** The four flange screws under
  the feet bear on whatever you stand this on.
- **A real build would use more hardware than this.** Eight corner brackets
  and four splice plates is the minimum that reads as a frame; add a bracket
  at every joint if the cage carries load.

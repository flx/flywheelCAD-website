# flywheelcad-format: 1
# =============================================================================
# MOTOR CAGE MOUNT — a NEMA 23 on an isolated plate inside a 2020 T-slot cage
# =============================================================================
# A motor test / dyno frame: 240 x 240 x 220 mm of 20-series aluminium
# extrusion, joined by real corner brackets and T-slot nuts, with a stepper
# hanging under a mount plate on four rubber isolators so its vibration never
# reaches the frame. The floor of the cage carries a DIN rail with the driver
# and a buck converter on it; one wall is a vent grille and the top has a
# carry handle and an 80 mm fan.
#
# Almost every part here is a STANDARD-LIBRARY part — the rails, every piece
# of joining hardware, the motor, the feet, the electronics and the enclosure
# furniture. Exactly two bodies are drawn by this file: the motor mount plate
# and the vent panel it screws to. That is the point of the sample: a frame
# like this is 95 % catalog, and the design work is the two plates.
#
# ---------------------------------------------------------------------------
# HOW TO CHANGE THIS DESIGN
# ---------------------------------------------------------------------------
#   IN THE APP   — the mount plate and vent panel are drawn at module level
#                  from constrained sketches whose dimensions are bound to
#                  driving variables (`V_PLATE_L`, `V_MOTOR_BOSS_R`, …), so
#                  the Variables panel and double-click-a-dimension both work.
#   IN THIS FILE — the cage geometry. `CAGE_W/D/H` and `CELL` drive every
#                  rail length and every hardware position through the helper
#                  functions below; a rail is not something you dimension, it
#                  is something you cut to length.
#
# Change `CAGE_W`, `CAGE_D`, `CAGE_H` and re-run: all 14 rails, 16 brackets,
# 32 nuts, 32 screws, the feet, the caps and the panels follow.
#
# ---------------------------------------------------------------------------
# BILL OF MATERIALS
# ---------------------------------------------------------------------------
#    4x  2020 extrusion, 220 mm (uprights)                  [library part]
#    8x  2020 extrusion, 200 mm (top and bottom rings)      [library part]
#    2x  2020 extrusion, 200 mm (motor cross-members)       [library part]
#    8x  20-series corner bracket with gusset               [library part]
#    4x  20-series 2-hole splice plate                       [library part]
#   28x  20-series T-slot nut, M5                           [library part]
#   24x  M5 x 10 socket cap screw (frame + panel)           [library part]
#    4x  M5 x 16 (motor) and 4x M5 x 25 (isolators)         [library part]
#    4x  2020 end cap                                       [library part]
#    4x  large rubber foot (cage feet)                      [library part]
#    4x  large rubber foot (motor isolators)                [library part]
#    1x  NEMA 23 stepper, 56 mm body                        [library part]
#    4x  M5 x 16 cap screw (motor to plate)                 [library part]
#    1x  TS35 DIN rail, 180 mm + A4988 driver + buck converter [library parts]
#    1x  80 mm fan + 1x rocker switch + 1x M12 cable gland  [library parts]
#    1x  carry handle + 2x cable clip                       [library parts]
#    1x  motor mount plate, 8 mm aluminium (drawn here)
#    1x  vent panel, 3 mm aluminium (drawn here)
# =============================================================================
from flywheelcad import *

cad = FlywheelCAD()

from lib.standard.extrusions import rail
from lib.standard.framing import corner_bracket, t_slot_nut, end_cap, angle_plate
from lib.standard.fasteners import cap_screw
from lib.standard.steppers import stepper
from lib.standard.magnets_misc import rubber_foot
from lib.standard.enclosure import din_rail, handle, vent_grille
from lib.standard.electronics import fan
from lib.standard.modules import stepper_driver, buck_converter
from lib.standard.switches import rocker_switch
from lib.standard.pneumatics import cable_gland
from lib.standard.mounts import cable_clip

# =============================================================================
# PARAMETER BLOCK
# =============================================================================

# ---- the cage ---------------------------------------------------------------
CELL = 20.0                 # 20-series: every rail is CELL square
PROFILE = "2020"
CAGE_W = 240.0              # outside, X
CAGE_D = 240.0              # outside, Y
CAGE_H = 220.0              # outside, Z
SPAN_X = CAGE_W - 2 * CELL  # rails run BETWEEN the corner posts
SPAN_Y = CAGE_D - 2 * CELL

# ---- motor deck -------------------------------------------------------------
Z_DECK = 100.0              # underside of the two cross-members
ISO_H = 10.0                # large rubber foot height = the isolator stack
Z_PLATE = Z_DECK + CELL + ISO_H            # 130 — underside of the mount plate
X_CROSS_A = 60.0            # cross-member near faces (their -X faces)
X_CROSS_B = 160.0

# ---- motor mount plate (drawn here) ----------------------------------------
PLATE_L = 200.0             # X
PLATE_W = 120.0             # Y
PLATE_T = 8.0
MOTOR_BOLT = 47.14          # NEMA 23 bolt square                  (coupled)
MOTOR_BOLT_R = 2.75         # M5 clearance                         (coupled)
MOTOR_BOSS_R = 20.0         # clears the NEMA 23 Ø38.1 boss        (coupled)
ISO_BOLT_R = 2.75           # isolator screw clearance             (coupled)
X_ISO = 50.0                # isolator bolt pattern: sits on the two
Y_ISO = 40.0                # cross-members, in from the plate edges (coupled)

# ---- vent panel (drawn here) ------------------------------------------------
PANEL_W = CAGE_W            # laps onto both uprights, which is what it bolts to
PANEL_H = 120.0
PANEL_T = 3.0
PANEL_HOLE_R = 2.75         # M5 clearance into the rail slots     (coupled)

COL_PLATE = "#546E7A"
COL_PANEL = "#B0BEC5"


# =============================================================================
# HELPERS — rail placement.
#
# `extrusions.rail` always extrudes along +Z from a profile whose CORNER sits
# at the sketch origin, so every horizontal rail is that same component turned
# a quarter turn. Rotating +Z onto +X (about +Y) drops the profile to
# z = -CELL..0; rotating it onto +Y (about +X) does the same. Both helpers
# add CELL back so the caller can say where the rail's LOW corner goes and
# mean it.
# =============================================================================
def rail_z(length, x0, y0, z0, name):
    """A rail running +Z, low profile corner at (x0, y0, z0)."""
    return cad.instance(rail(cad, profile=PROFILE, length=length),
                        translate=(x0, y0, z0), name=name, export=False)


def rail_x(length, x0, y0, z0, name):
    """A rail running +X, low corner at (x0, y0, z0)."""
    return cad.instance(rail(cad, profile=PROFILE, length=length),
                        axis=(0, 1, 0), angle=90.0,
                        translate=(x0, y0, z0 + CELL), name=name, export=False)


def rail_y(length, x0, y0, z0, name):
    """A rail running +Y, low corner at (x0, y0, z0)."""
    return cad.instance(rail(cad, profile=PROFILE, length=length),
                        axis=(1, 0, 0), angle=-90.0,
                        translate=(x0, y0, z0 + CELL), name=name, export=False)


# =============================================================================
# THE CAGE — 4 uprights, a bottom ring, a top ring, and 2 cross-members.
# =============================================================================
POSTS = [(0.0, 0.0), (CAGE_W - CELL, 0.0),
         (CAGE_W - CELL, CAGE_D - CELL), (0.0, CAGE_D - CELL)]
for i, (px, py) in enumerate(POSTS):
    rail_z(CAGE_H, px, py, 0.0, f"post{i}")

for i, z0 in enumerate([0.0, CAGE_H - CELL]):          # bottom ring, top ring
    rail_x(SPAN_X, CELL, 0.0, z0, f"beam_x_front{i}")
    rail_x(SPAN_X, CELL, CAGE_D - CELL, z0, f"beam_x_back{i}")
    rail_y(SPAN_Y, 0.0, CELL, z0, f"beam_y_left{i}")
    rail_y(SPAN_Y, CAGE_W - CELL, CELL, z0, f"beam_y_right{i}")

rail_y(SPAN_Y, X_CROSS_A, CELL, Z_DECK, "cross_a")
rail_y(SPAN_Y, X_CROSS_B, CELL, Z_DECK, "cross_b")

# =============================================================================
# JOINING HARDWARE — this is where a T-slot frame is actually designed.
#
# `corner_bracket` is an L whose horizontal arm lies ON a rail's top face
# extending +X, and whose vertical plate hugs a post's face on the -X side of
# the corner. So each bracket goes at the post's inner face, pushed out by one
# plate thickness (its own vertical arm then fills that gap), and turned to
# face along the beam it ties down.
#
# Each bracket's two screws come straight from its published anchors —
# `arm_a_hole` at (arm/2, 0, 0) and `arm_b_hole` at (0, 0, arm/2) in bracket
# space — so if the library ever re-proportions the bracket, the screws move
# with it. Behind each screw sits a T-slot nut, dropped back along the screw
# axis by one plate thickness plus its own height, which lands it in the slot
# cavity with its seating face against the slot lips.
# =============================================================================
BRACKET_T = CELL / 5.0              # framing.corner_bracket's default plate
NUT_TOTAL = 5.0                     # 20-series tee nut: body 3.2 + neck 1.8
BRACKET = corner_bracket(cad, size=20, gusset=True)
TNUT = t_slot_nut(cad, size=20, thread=5.0, style="tee")
M5_10 = cap_screw(cad, thread="M5", length=10.0)
ARM_HOLE = CELL / 2.0               # framing puts each arm's hole at arm/2


def _rot_z(vx, vy, deg):
    import math
    a = math.radians(deg)
    return (vx * math.cos(a) - vy * math.sin(a), vx * math.sin(a) + vy * math.cos(a))


def place_screw_and_nut(px, py, pz, axis, angle, direction, tag,
                        plate=None, screw=None):
    """An M5 whose under-head plane is (px, py, pz), plus the T-slot nut it
    threads into. `axis`/`angle` turn the screw (which points -Z untouched)
    onto `direction`; the nut is then pushed back along that same direction by
    the bracket plate the screw passes through plus the nut's own height,
    which lands it in the slot cavity with its face against the slot lips."""
    dx, dy, dz = direction
    back = (BRACKET_T if plate is None else plate) + NUT_TOTAL
    cad.instance(screw or M5_10, axis=axis, angle=angle, translate=(px, py, pz),
                 name=f"screw_{tag}", export=False)
    cad.instance(TNUT, axis=axis, angle=angle,
                 translate=(px + dx * back, py + dy * back, pz + dz * back),
                 name=f"nut_{tag}", export=False)


DOWN = ((0, 0, 1), 0.0, (0.0, 0.0, -1.0))          # the untouched screw


# ---- 8 bottom corner brackets: one per beam end -----------------------------
# (corner xy, z-rotation, and the axis/angle that turns a -Z screw onto the
# horizontal direction that bracket's vertical arm screws along.)
BOTTOM_JOINTS = []
for (px, py) in POSTS:
    sx = 1.0 if px == 0.0 else -1.0
    sy = 1.0 if py == 0.0 else -1.0
    inner_x = CELL if px == 0.0 else CAGE_W - CELL
    inner_y = CELL if py == 0.0 else CAGE_D - CELL
    # X-beam joint: bracket turned so its arm runs along the beam, and its
    # vertical-arm screw driven horizontally into the post's slot.
    BOTTOM_JOINTS.append((inner_x + sx * BRACKET_T, py + CELL / 2.0,
                          0.0 if sx > 0 else 180.0,
                          (0, 1, 0), 90.0 if sx > 0 else -90.0,
                          (-sx, 0.0, 0.0)))
    # Y-beam joint: the same, a quarter turn round.
    BOTTOM_JOINTS.append((px + CELL / 2.0, inner_y + sy * BRACKET_T,
                          90.0 if sy > 0 else 270.0,
                          (1, 0, 0), -90.0 if sy > 0 else 90.0,
                          (0.0, -sy, 0.0)))

for i, (cx, cy, crot, baxis, bang, bdir) in enumerate(BOTTOM_JOINTS):
    cad.instance(BRACKET, axis=(0, 0, 1), angle=crot, translate=(cx, cy, CELL),
                 name=f"bracket{i}", export=False)
    ahx, ahy = _rot_z(ARM_HOLE, 0.0, crot)
    place_screw_and_nut(cx + ahx, cy + ahy, CELL + BRACKET_T, *DOWN, f"a{i}")
    place_screw_and_nut(cx, cy, CELL + ARM_HOLE, baxis, bang, bdir, f"b{i}")

# ---- 4 top splice plates: a flat strip across each top corner ---------------
# `angle_plate` is a straight strip with its holes on the rail's cell pitch —
# two holes, one over the post and one over the beam, laid flat on the top
# face of both. One per corner, alternating direction so no two overlap.
PLATE2 = angle_plate(cad, size=20, holes=2)
PLATE_T_TOP = CELL / 5.0
for i, (px, py) in enumerate(POSTS):
    along_x = (i % 2 == 0)
    sx = 1.0 if px == 0.0 else -1.0
    sy = 1.0 if py == 0.0 else -1.0
    if along_x:
        anchor = (px + CELL if px == 0.0 else px, py + CELL / 2.0)
        prot = 0.0
        holes = [(anchor[0] - sx * CELL / 2.0, anchor[1]),
                 (anchor[0] + sx * CELL / 2.0, anchor[1])]
    else:
        anchor = (px + CELL / 2.0, py + CELL if py == 0.0 else py)
        prot = 90.0
        holes = [(anchor[0], anchor[1] - sy * CELL / 2.0),
                 (anchor[0], anchor[1] + sy * CELL / 2.0)]
    cad.instance(PLATE2, axis=(0, 0, 1), angle=prot,
                 translate=(anchor[0], anchor[1], CAGE_H), name=f"splice{i}",
                 export=False)
    for j, (hx, hy) in enumerate(holes):
        place_screw_and_nut(hx, hy, CAGE_H + PLATE_T_TOP, *DOWN, f"t{i}_{j}")

# =============================================================================
# FEET AND CAPS — the cage stands on four rubber feet and its posts are
# capped. `end_cap`'s spigots point +Z out of its back face, so a cap for an
# upward-facing rail end sits one cap-thickness below that end.
# =============================================================================
CAP = end_cap(cad, size=PROFILE, thickness=2.5)
FOOT = rubber_foot(cad, size="large")
for i, (px, py) in enumerate(POSTS):
    cx, cy = px + CELL / 2.0, py + CELL / 2.0
    # Mirrored: the cap's spigots point +Z out of its back face, so an
    # upward-facing rail end needs them turned to point back DOWN into it.
    cad.instance(CAP, mirror_plane="xy", translate=(cx, cy, CAGE_H + 2.5),
                 name=f"cap{i}", export=False)
    cad.instance(FOOT, mirror_plane="xy", translate=(cx, cy, 0.0),
                 name=f"foot{i}", export=False)

# =============================================================================
# MOTOR MOUNT PLATE — one of the two bodies this file actually draws.
#
# A constrained rectangle (both pairs of edges parallel, corners square, the
# two overall sizes dimensioned to variables), with the NEMA 23 interface cut
# into it: a boss clearance bore on the plate centre and the 47.14 mm bolt
# square around it, plus four isolator holes out at the corners. Every one of
# those numbers is a dimension bound to a variable, because every one is a
# decision someone might revisit.
# =============================================================================
V_PLATE_L = cad.variable(PLATE_L, driving=True)
V_PLATE_W = cad.variable(PLATE_W, driving=True)
V_PLATE_T = cad.variable(PLATE_T, driving=True)
V_MOTOR_BOSS_R = cad.variable(MOTOR_BOSS_R, driving=True)

plate_plane = cad.create_sketch_plane(cad.point(0.0, 0.0, Z_PLATE),
                                      cad.point(1.0, 0.0, Z_PLATE),
                                      cad.point(0.0, 1.0, Z_PLATE),
                                      name="mount_plate_face")
cad.with_sketch(plate_plane)

CX, CY = CAGE_W / 2.0, CAGE_D / 2.0
hl, hw = PLATE_L / 2.0, PLATE_W / 2.0
mp1 = cad.point2d(CX - hl, CY - hw)
mp2 = cad.point2d(CX + hl, CY - hw)
mp3 = cad.point2d(CX + hl, CY + hw)
mp4 = cad.point2d(CX - hl, CY + hw)
ml1 = cad.line2d(mp1, mp2)
ml2 = cad.line2d(mp2, mp3)
ml3 = cad.line2d(mp3, mp4)
ml4 = cad.line2d(mp4, mp1)

cad.horizontal(line=ml1)                 # it IS a rectangle, not four points
cad.parallel(line1=ml3, line2=ml1)
cad.vertical(line=ml2)
cad.perpendicular(line1=ml4, line2=ml1)
cad.distance(mp1, mp2, V_PLATE_L)        # the two numbers that matter
cad.distance(mp2, mp3, V_PLATE_W)

boss_c = cad.point2d(CX, CY)
motor_boss = cad.circle2d(boss_c, MOTOR_BOSS_R)
cad.radius(circle=motor_boss, radius=V_MOTOR_BOSS_R)
cad.point_line_distance(point=boss_c, line=ml1, distance=PLATE_W / 2.0)
cad.point_line_distance(point=boss_c, line=ml4, distance=PLATE_L / 2.0)

plate_holes = [[motor_boss]]
MOTOR_HALF = MOTOR_BOLT / 2.0
for (sx, sy) in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
    plate_holes.append([cad.circle2d(
        cad.point2d(CX + sx * MOTOR_HALF, CY + sy * MOTOR_HALF), MOTOR_BOLT_R)])
for (sx, sy) in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
    plate_holes.append([cad.circle2d(
        cad.point2d(CX + sx * X_ISO, CY + sy * Y_ISO), ISO_BOLT_R)])
cad.ensure_convergence()

mount_plate = cad.extrude(plate_plane,
                          cad.region(loop=[ml1, ml2, ml3, ml4], holes=plate_holes,
                                     inside=(CX - hl + 6.0, CY)),
                          V_PLATE_T)
cad.set_color("mount_plate", COL_PLATE, finish="metallic")

# =============================================================================
# VENT PANEL — the second drawn body. A 3 mm sheet filling one wall opening,
# with a library vent grille bolted over its window and four M5s into the
# surrounding rail slots.
# =============================================================================
V_PANEL_W = cad.variable(PANEL_W, driving=True)
V_PANEL_H = cad.variable(PANEL_H, driving=True)
V_PANEL_T = cad.variable(PANEL_T, driving=True)

# The plane sits at the panel's INNER face and its normal points -Y, so an
# ordinary positive extrude fills back to y = CELL, onto the rails. Reaching
# the same place with `direction="negative"` also works, but it drops the body
# off the exact-mesh path and onto the sampled one — 355 k triangles for a
# flat plate, instead of 1.2 k.
panel_plane = cad.create_sketch_plane(cad.point(0.0, CELL + PANEL_T, 0.0),
                                      cad.point(1.0, CELL + PANEL_T, 0.0),
                                      cad.point(0.0, CELL + PANEL_T, 1.0),
                                      name="vent_panel_face")
cad.with_sketch(panel_plane)

# A plane's sketch axes come from its NORMAL, not from the points that defined
# it: for this one (normal -Y) they work out as u = +X, v = +Z, so the panel is
# drawn in ordinary (x, z).
PANEL_X0 = 0.0
PANEL_Z0 = CELL + 20.0
vp1 = cad.point2d(PANEL_X0, PANEL_Z0)
vp2 = cad.point2d(PANEL_X0 + PANEL_W, PANEL_Z0)
vp3 = cad.point2d(PANEL_X0 + PANEL_W, PANEL_Z0 + PANEL_H)
vp4 = cad.point2d(PANEL_X0, PANEL_Z0 + PANEL_H)
vl1 = cad.line2d(vp1, vp2)
vl2 = cad.line2d(vp2, vp3)
vl3 = cad.line2d(vp3, vp4)
vl4 = cad.line2d(vp4, vp1)
cad.horizontal(line=vl1)
cad.parallel(line1=vl3, line2=vl1)
cad.vertical(line=vl2)
cad.perpendicular(line1=vl4, line2=vl1)
cad.distance(vp1, vp2, V_PANEL_W)
cad.distance(vp2, vp3, V_PANEL_H)

PANEL_CX = PANEL_X0 + PANEL_W / 2.0
PANEL_CY = PANEL_Z0 + PANEL_H / 2.0
vent_window = [cad.circle2d(cad.point2d(PANEL_CX, PANEL_CY), 34.0)]
panel_holes = [vent_window]
# On the two uprights' slot centre-lines — a panel screw has to land in a slot,
# so these positions are dictated by the frame, not chosen.
for (sx, sy) in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
    panel_holes.append([cad.circle2d(
        cad.point2d(PANEL_CX + sx * (PANEL_W / 2.0 - CELL / 2.0),
                    PANEL_CY + sy * (PANEL_H / 2.0 - 25.0)), PANEL_HOLE_R)])
cad.ensure_convergence()

# Note on the mesh: a small hole close to the edge of a large thin plate takes
# this body off the exact-mesh path and onto the sampled one (the four M5s are
# 10 mm in from a 240 mm edge). That costs triangles, not accuracy — the holes
# are 3.5 cells across at the document default and come through intact.
vent_panel = cad.extrude(panel_plane,
                         cad.region(loop=[vl1, vl2, vl3, vl4], holes=panel_holes,
                                    inside=(PANEL_X0 + 5.0, PANEL_CY)),
                         V_PANEL_T)
cad.set_color("vent_panel", COL_PANEL, finish="metallic")

# Four M5s from inside, through the panel and into each upright's rear slot.
for i, (sx, sy) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
    place_screw_and_nut(PANEL_CX + sx * (PANEL_W / 2.0 - CELL / 2.0),
                        CELL + PANEL_T,
                        PANEL_CY + sy * (PANEL_H / 2.0 - 25.0),
                        (1, 0, 0), -90.0, (0.0, -1.0, 0.0), f"p{i}",
                        plate=PANEL_T)

# =============================================================================
# THE MOTOR AND ITS ISOLATION
# =============================================================================
NEMA23 = stepper(cad, size=23)
# Mount face on the plate's UNDERSIDE: the can hangs into the cage and the
# shaft comes up through the plate's boss bore.
cad.instance(NEMA23, translate=(CX, CY, Z_PLATE), name="nema23", export=False)

M5_16 = cap_screw(cad, thread="M5", length=16.0)
M5_25 = cap_screw(cad, thread="M5", length=25.0)
for i, (sx, sy) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
    cad.instance(M5_16, translate=(CX + sx * MOTOR_HALF, CY + sy * MOTOR_HALF,
                                   Z_PLATE + PLATE_T),
                 name=f"mscrew{i}", export=False)

# Four rubber isolators carry the plate off the cross-members: the whole point
# of the deck. Each sits on a rail's top face with an M5 down into a T-nut.
for i, (sx, sy) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
    ix, iy = CX + sx * X_ISO, CY + sy * Y_ISO
    cad.instance(FOOT, translate=(ix, iy, Z_DECK + CELL), name=f"iso{i}",
                 export=False)
    # Plate (8) + rubber (10) + nut (5) = 23, so a 25 stops just inside the nut.
    cad.instance(M5_25, translate=(ix, iy, Z_PLATE + PLATE_T),
                 name=f"iscrew{i}", export=False)
    cad.instance(TNUT, translate=(ix, iy, Z_DECK + CELL - NUT_TOTAL),
                 name=f"inut{i}", export=False)

# =============================================================================
# ELECTRONICS AND ENCLOSURE FURNITURE — all catalog.
# =============================================================================
# DIN rail across the cage floor, driver and buck converter clipped to it.
# +90 about X, not -90: the rail's hat rises +Y in its own frame, and only
# this direction lands it face-up on the cage floor.
cad.instance(din_rail(cad, length=180.0, size="TS35"),
             axis=(1, 0, 0), angle=90.0, translate=(70.0, 210.0, CELL),
             name="din_strip", export=False)
cad.instance(stepper_driver(cad, kind="A4988"),
             translate=(70.0, 80.0, CELL + 7.5), name="drv_board", export=False)
cad.instance(buck_converter(cad),
             translate=(70.0, 140.0, CELL + 7.5), name="buck_board", export=False)

# Top deck: a carry handle.
cad.instance(handle(cad, span=120.0, height=32.0, bar_d=12.0),
             translate=(CX, CELL / 2.0, CAGE_H), name="top_handle", export=False)
# The 80 mm fan draws through the vent panel's window, bolted to the panel's
# inner face; the library vent grille on the outer face is the finger guard.
cad.instance(fan(cad, size="80mm"), axis=(1, 0, 0), angle=-90.0,
             translate=(CX, CELL + PANEL_T, PANEL_Z0 + PANEL_H / 2.0),
             name="case_fan", export=False)

# A library vent grille bolted over the panel's window, plus the panel's
# switch and cable gland.
cad.instance(vent_grille(cad, width=60.0, height=40.0, pattern="slots"),
             axis=(1, 0, 0), angle=-90.0,
             translate=(CAGE_W / 2.0, CELL - 2.0, PANEL_Z0 + PANEL_H / 2.0),
             name="vent_face", export=False)
cad.instance(rocker_switch(cad), axis=(1, 0, 0), angle=90.0,
             translate=(CAGE_W / 2.0 - 60.0, CELL + PANEL_T, PANEL_Z0 + 20.0),
             name="psw", export=False)
cad.instance(cable_gland(cad, size="M12"), axis=(1, 0, 0), angle=-90.0,
             translate=(CAGE_W / 2.0 + 60.0, CELL, PANEL_Z0 + 20.0),
             name="gland_m12", export=False)

# Cable management up one post.
CLIP = cable_clip(cad, cable_d=6.0)
for i, cz in enumerate((60.0, 150.0)):
    cad.instance(CLIP, axis=(0, 0, 1), angle=180.0,
                 translate=(CELL, CELL + 4.0, cz), name=f"clip{i}", export=False)

# Axial flux motor — build notes

Double-rotor, coreless-stator (ironless) axial flux machine, ~400 mm OD
(stator plate radius 200 mm). 32 poles / 24 coils, 3-phase. This topology has
zero cogging, needs no laminations, and every structural part prints flat —
the same architecture proven by DIY axial-flux wind generators.

## What is editable, and where

| You want to change | Do it |
|---|---|
| stator/rotor diameters, bores, bolt circles, plate and carrier thicknesses | **In the app** — Variables panel, or double-click the dimension on the sketch. `V_R_STATOR`, `V_R_ROTOR`, `V_STATOR_T`, `V_CARRIER_T`, … |
| bearing seat Ø and depth, hub bore | **In the app** — the hub is a revolved half-section, so its seats are real dimensioned lines (`V_HUB_R_SEAT`, `V_HUB_R_BORE`) |
| pole count, coil count, magnet size, air gap | **In `main.py`**, in the parameter block. These also move the placed magnets/coils/screws, which are positioned in python |

Two dimensions per part carry the design; the 24 coil windows and 32 magnet
windows are pattern *output* and are deliberately left undimensioned — they
follow from the counts and radii above them.

### One authoring rule this file follows deliberately

Each `cad.variable(...)` is declared **immediately above the sketch it drives**,
not in the parameter block. In FlywheelCAD 0.22 a variable declared before a
sketch that contains `cad.fillet(...)` is dragged off its value by that
sketch's solve — the coil windows are filleted, and hoisting the declarations
produced a 92 mm rotor and a 0 mm-thick stator plate. Declaring them at the
point of use avoids it and reads better anyway.

## Bill of materials (everything off-the-shelf)

| Qty | Part | Where |
|----:|------|-------|
| 64 | N42 neodymium block magnet **40 × 20 × 10 mm**, magnetized through 10 mm | Amazon / eBay / supermagnete / first4magnets |
| 2 | **6902** deep-groove ball bearing (15 × 28 × 7) | any bearing shop online |
| 1 | 15 mm precision shaft, 100 mm | eBay / linear-motion shops |
| 2 | 3 mm mild-steel disc, OD 370 / bore 68, 4 holes Ø4.4 at R40 | laser-cut service (SendCutSend, Fractory) — DXF from the `steel_top` body |
| 8 | M4 × 30 cap screw + washer + nyloc nut | hardware store |
| 6 | M5 × 16 cap screw (stator mounting) | hardware store |
| 2 | M4 × 6 grub screw (rotor hub → shaft) | hardware store |
| 2 | 15 mm split shaft collar | linear-motion shops |
| ~0.5 kg | 0.5–0.8 mm enamelled magnet wire | eBay / motor rewind suppliers |

Every line above except the magnets and the wire is a **standard-library
part** in the model (`lib/standard/`), so it is drawn to catalog size and
moves with the holes it passes through.

## Printed parts (in the 3MF export)

- `stator_plate` — R200 × 14 mm disc, 24 coil windows, 6 × M5 mounts at R193
- `stator_hub` — bearing bush: two 6902 seats, press/glue into the plate bore
- `carrier_top` / `carrier_bot` — rotor discs with 32 magnet through-windows
- `hub_top` / `hub_bot` — rotor hubs (flange + 15 mm shaft boss; cross-drill
  for the M4 grub screw after printing)
- `former0..23` — 24 identical coil winding formers (print all 24; each stays
  inside its coil)

Print flat, 40 %+ infill, PETG or better (magnets get warm under load).

**Mesh quality:** unlike the older version of this sample, this one does *not*
pin a document-wide quality. Only the stator plate carries its own
`quality="ultra"` — a 400 mm disc with 8 mm fillets is below one cell at the
document default and meshes as confetti without it. Everything else is left to
your Settings, so the quality picker in the app still works. A default-quality
render of the whole assembly takes about 11 seconds.

## Assembly order

1. Press the two 6902 bearings into the stator hub, glue hub into the plate.
2. Wind 24 coils directly around the printed formers (the winding bundle is
   8 mm wide × 10 mm tall all round); epoxy former + coil into the stator
   windows, wire as 3 phases × 8 coils (every 3rd coil is the same phase),
   star point in the middle.
3. Drop magnets into the carrier windows **onto** the steel disc — polarity
   alternates N/S around the ring (red/blue in the model), and the two rotors
   must attract each other through the stator (opposite poles facing).
4. Bolt steel disc + carrier + rotor hub with 4 × M4 per rotor.
5. Slide the first rotor onto the shaft, shaft through the bearings, second
   rotor on, shaft collars last. **Caution: the closing force between the
   rotors is hundreds of newtons — use threaded rod as a jig to lower the
   second rotor evenly.**

## Electromagnetic sanity numbers (estimates, not measurements)

- Magnetic gap between opposing magnet faces: 17 mm (14 stator + 2 × 1.5 air);
  N42 10 mm magnets facing each other give roughly **0.7 T** in the gap.
- Flux per pole ≈ 0.55 mWb → with 8 series coils per phase, phase EMF is about
  **1.0–1.2 V·s/rad per 100 turns per coil** (≈ 30 Vrms/phase at 300 rpm with
  50-turn coils). Pick turns for your controller voltage; more strands in
  parallel of thinner wire fills the same window with lower resistance.
- Electrical frequency: 16 pole pairs → 267 Hz at 1000 rpm; keep rpm modest
  or use a controller happy at high eRPM.

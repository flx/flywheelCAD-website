# flywheelcad-format: 1
# =============================================================================
# AXIAL FLUX MOTOR — double-rotor, coreless (ironless) stator, ~400 mm OD
# =============================================================================
# A 3D-printable axial flux machine: one printed coreless stator disc carrying
# 24 flat "racetrack" coils, sandwiched between two rotor discs that each carry
# 32 off-the-shelf N42 block magnets (40 x 20 x 10 mm) seated against a 3 mm
# laser-cut steel back-iron disc. The rotors turn on a 15 mm shaft running in
# two 6902 bearings housed in the stator hub. Zero cogging, no laminations,
# every structural part prints flat.
#
# ---------------------------------------------------------------------------
# HOW TO CHANGE THIS DESIGN
# ---------------------------------------------------------------------------
# Every number that is a design decision lives ONCE, in the parameter block
# below, and the ones that shape a part are published as DRIVING VARIABLES.
# That means three things:
#
#   * the sketches are really constrained — open the stator plate's sketch and
#     the solver badge reads "Fully constrained", not "31 DOFs free";
#   * the dimensions you see on those sketches are bound to a named variable,
#     so double-clicking one shows you `V_R_STATOR`, not an anonymous 200;
#   * the plate/carrier THICKNESSES are bound too — an extrude distance takes
#     a variable just like a radius does, so `V_STATOR_T` drives the solid.
#
# Two ways to edit, and they differ:
#
#   IN THE APP  — Variables panel, or double-click any dimension. The sketches
#                 re-solve and the bodies re-derive immediately. This is the
#                 right route for the sizes of the printed parts.
#   IN THIS FILE — the parameter block. Needed when a change also has to move
#                 the PLACED catalog parts (bearings, screws, magnets), whose
#                 positions are computed from the same block in python. Numbers
#                 in that class are marked (coupled) below.
#
# The `cad.variable(...)` declarations do NOT sit in that block: each one is
# declared immediately above the sketch it drives. That is deliberate — see
# the note at the head of the STATOR PLATE section.
#
# ---------------------------------------------------------------------------
# BILL OF MATERIALS — everything not printed is an internet-catalog part
# ---------------------------------------------------------------------------
#   64x  N42 neodymium block magnet 40 x 20 x 10 mm, magnetized through 10 mm
#    2x  6902 deep-groove ball bearing, 15 x 28 x 7 mm       [library part]
#    1x  15 mm ground steel shaft, 100 mm                    [library part]
#    2x  3 mm mild-steel disc, OD 370 / bore 68 (laser-cut from `steel_top`)
#    8x  M4 x 30 socket cap screw + washer + nut (rotor stacks) [library part]
#    6x  M5 x 16 socket cap screw (stator mounting)          [library part]
#    2x  M4 x 6 grub screw (rotor hub -> shaft)              [library part]
#    2x  15 mm shaft collar (axial retention)                [library part]
#   ~0.5 kg 0.5-0.8 mm enamelled magnet wire
#
# PRINTED: stator_plate, stator_hub, carrier_top/bot, hub_top/bot, 24x former.
# See BUILD_NOTES.md for winding, assembly order and the magnetics numbers.
# =============================================================================
from flywheelcad import *

cad = FlywheelCAD()

import math

from lib.standard.bearings import bearing
from lib.standard.shafting import shaft, shaft_collar
from lib.standard.fasteners import cap_screw, hex_nut, washer
from lib.standard.fasteners_more import grub_screw

# =============================================================================
# PARAMETER BLOCK — the whole design, once.
# Every number below is used exactly twice: once by the python that PLACES the
# catalog parts, and once by the `cad.variable(NAME, driving=True)` further
# down that BINDS it to a sketch dimension or an extrude distance. Edit a
# number here and both follow; edit its variable in the app and the sketched
# part follows on its own.
# =============================================================================

# ---- pole/slot counts (integers — a count is not a dimension, so no variable)
N_POLES = 32                      # magnets per rotor; must be even
N_COILS = 24                      # 3/4 of N_POLES — the classic coreless ratio

# ---- stator plate
R_STATOR = 200.0                  # outer radius of the printed stator disc
R_STATOR_BORE = 24.2              # bore the bearing hub presses into
R_MOUNT = 193.0                   # M5 stator mounting-hole circle   (coupled)
R_MOUNT_HOLE = 2.6                # M5 clearance radius              (coupled)
STATOR_T = 14.0                   # plate thickness = coil + 2 mm skin per side


# ---- coil (the winding envelope, not individual strands)
COIL_RIN, COIL_ROUT = 125.0, 185.0            # radial span of the coil block
COIL_HALF_W_IN, COIL_HALF_W_OUT = 14.5, 21.5  # half-width at RIN / at ROUT
COIL_T = 10.0                                 # bundle thickness
COIL_CORNER_R = 8.0                           # outline corner radius
WIND_W = 8.0                                  # winding wall, outline -> window
WINDOW_CLEAR = 0.3                            # stator window clearance per side

# ---- magnet (catalog part: N42 block 40 x 20 x 10)
MAG_RIN, MAG_ROUT = 135.0, 175.0  # working radii of the 40 mm magnet length
MAG_HALF_W = 10.0                 # half of the 20 mm tangential width
MAG_T = 10.0                      # magnet thickness (through-magnetized)
POCKET_CLEAR = 0.2                # carrier window clearance per side

# ---- rotor
R_ROTOR = 185.0                   # rotor disc outer radius
R_ROTOR_BORE = 34.0               # carrier / steel bore (clears the hub flange)
R_BOLTS = 40.0                    # M4 rotor-stack bolt circle       (coupled)
R_BOLT_HOLE = 2.2                 # M4 clearance radius              (coupled)
CARRIER_T = 10.0                  # printed magnet carrier = magnet thickness
STEEL_T = 3.0                     # laser-cut back-iron thickness
AIR_GAP = 1.5                     # running clearance, stator face -> magnet


# ---- rotor hub
R_HUB_FLANGE = 44.0               # hub flange radius
R_HUB_BOSS = 16.0                 # shaft-boss outer radius
R_SHAFT = 7.5                     # 15 mm shaft, radius
HUB_FLANGE_T = 5.0                # flange thickness
HUB_BOSS_H = 18.0                 # boss height above the flange


# ---- derived stack heights (pure consequences of the numbers above) ---------
Z_ROTOR = STATOR_T / 2.0 + AIR_GAP            # carrier inner face
Z_STEEL = Z_ROTOR + CARRIER_T                 # steel disc inner face
Z_HUB = Z_STEEL + STEEL_T                     # hub flange seats on the steel

PHASE_COLORS = ["#B87333", "#2E7D32", "#5E35B1"]   # phase A copper / B / C
COL_N, COL_S = "#C62828", "#1565C0"                # pole facing the stator
COL_PRINT_STATOR = "#455A64"
COL_PRINT_HUB = "#607D8B"
COL_PRINT_CARRIER = "#F57C00"
COL_PRINT_ROTORHUB = "#00695C"
COL_STEEL = "#90A4AE"


# =============================================================================
# HELPERS — pattern geometry only. Everything these build is DERIVED data (one
# sample of a 24- or 32-fold pattern), so per §D it is deliberately left
# undimensioned: the design decision lives on the count and the radii above.
# =============================================================================
def _rot(x, y, deg):
    a = math.radians(deg)
    return (x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a))


def _quad(corners):
    """4 corner tuples (CCW) -> a closed list of 4 sketch lines."""
    qpts = [cad.point2d(round(x, 3), round(y, 3)) for (x, y) in corners]
    return [cad.line2d(qpts[j], qpts[(j + 1) % 4]) for j in range(4)]


def _rounded_quad(corners, radius):
    """_quad plus a tangent fillet at every corner -> an 8-element loop."""
    rq_lines = _quad(corners)
    rq_fils = [cad.fillet(rq_lines[j], rq_lines[(j + 1) % 4], radius=radius)
               for j in range(4)]
    return [rq_lines[0], rq_fils[0], rq_lines[1], rq_fils[1],
            rq_lines[2], rq_fils[2], rq_lines[3], rq_fils[3]]


def _coil_hole_corners(inset=0.0):
    """Corners of the coil's winding window: the outline drawn in by a uniform
    WIND_W (+ inset) wall, so the wound bundle is the same thickness on every
    side. (The side edges slope ~6.6 deg, so treating the offset as radial /
    tangential is accurate to about 1 %.)"""
    t = WIND_W + inset
    wx0, wx1 = COIL_RIN + t, COIL_ROUT - t

    def hw(x):
        return (COIL_HALF_W_IN + (COIL_HALF_W_OUT - COIL_HALF_W_IN)
                * (x - COIL_RIN) / (COIL_ROUT - COIL_RIN))

    return [(wx0, -(hw(wx0) - t)), (wx1, -(hw(wx1) - t)),
            (wx1, hw(wx1) - t), (wx0, hw(wx0) - t)]


def _plane_at(z, name):
    """A sketch plane parallel to XY at height z (frame u=+X, v=+Y).

    Each module-level part gets its OWN plane. That is not decoration: two
    parts sketched on the same plane share one sketch, and 24 coil windows
    overlapping 32 magnet windows would subdivide each other's regions.
    """
    return cad.create_sketch_plane(cad.point(0.0, 0.0, z),
                                   cad.point(1.0, 0.0, z),
                                   cad.point(0.0, 1.0, z), name=name)


# =============================================================================
# STATOR PLATE — printed. A R200 x 14 disc with 24 through-windows the coils
# drop into, a bore for the bearing hub, and 6 M5 mounting holes.
#
# The outer circle and the bore are the two circles a person re-sizes, so both
# are concentric-constrained to the plane origin and carry a radius dimension
# bound to a variable. The 6 mounting holes and 24 coil windows are pattern
# output: constrained by construction, deliberately not dimensioned.
#
# WHY THE VARIABLES ARE DECLARED HERE AND NOT IN THE PARAMETER BLOCK
# A `cad.variable(...)` declared BEFORE a sketch that contains `cad.fillet(...)`
# is dragged off its value by that sketch's solve (FlywheelCAD 0.22 — the coil
# windows below are filleted, and a variable declared above them came out at
# half its value). Declaring each part's variables immediately above the sketch
# that uses them side-steps it, and reads better anyway.
# =============================================================================
V_R_STATOR = cad.variable(R_STATOR, driving=True)
V_R_STATOR_BORE = cad.variable(R_STATOR_BORE, driving=True)
V_R_MOUNT = cad.variable(R_MOUNT, driving=True)

sp_plane = _plane_at(-STATOR_T / 2.0, "stator_face")
cad.with_sketch(sp_plane)

sp_center = cad.point2d(0.0, 0.0)
stator_outer = cad.circle2d(sp_center, R_STATOR)
cad.coincident(p0=sp_center, p1=origin_stator_face)
cad.radius(circle=stator_outer, radius=V_R_STATOR)

sb_center = cad.point2d(0.0, 0.0)
stator_bore = cad.circle2d(sb_center, R_STATOR_BORE)
cad.concentric(circle1=stator_bore, circle2=stator_outer)
cad.radius(circle=stator_bore, radius=V_R_STATOR_BORE)

# A construction circle IS the M5 bolt circle — dimension it once, and every
# mounting hole is "on the bolt circle" rather than at 6 unrelated coordinates.
sm_center = cad.point2d(0.0, 0.0)
stator_bolt_circle = cad.circle2d(sm_center, R_MOUNT, construction=True)
cad.concentric(circle1=stator_bolt_circle, circle2=stator_outer)
cad.radius(circle=stator_bolt_circle, radius=V_R_MOUNT)

stator_holes = [[stator_bore]]
for i in range(6):                            # M5 mounting holes
    mx, my = _rot(R_MOUNT, 0.0, i * 60.0)
    mc = cad.point2d(round(mx, 3), round(my, 3))
    stator_holes.append([cad.circle2d(mc, R_MOUNT_HOLE)])
    cad.point_on_circle(point=mc, circle=stator_bolt_circle)

for i in range(N_COILS):                      # coil windows = coil + clearance
    ang = i * 360.0 / N_COILS
    stator_holes.append(_rounded_quad(
        [_rot(COIL_RIN - WINDOW_CLEAR, -(COIL_HALF_W_IN + WINDOW_CLEAR), ang),
         _rot(COIL_ROUT + WINDOW_CLEAR, -(COIL_HALF_W_OUT + WINDOW_CLEAR), ang),
         _rot(COIL_ROUT + WINDOW_CLEAR, COIL_HALF_W_OUT + WINDOW_CLEAR, ang),
         _rot(COIL_RIN - WINDOW_CLEAR, COIL_HALF_W_IN + WINDOW_CLEAR, ang)],
        COIL_CORNER_R + WINDOW_CLEAR))

cad.ensure_convergence()

# Declared HERE, below the filleted windows, for the same reason the others
# are declared above their sketch: a variable that predates a `cad.fillet(...)`
# comes out of that solve at the wrong value, and an extrude distance is read
# AFTER the solve — declared up in the block, this one built a 0 mm plate.
V_STATOR_T = cad.variable(STATOR_T, driving=True)

sp_inside = _rot(100.0, 0.0, 7.5)             # between window 0 and window 1
stator_plate = cad.extrude(
    sp_plane,
    cad.region(loop=[stator_outer], holes=stator_holes,
               inside=(round(sp_inside[0], 3), round(sp_inside[1], 3))),
    V_STATOR_T,
    # The one body in this document that needs its own mesh quality (§C rule 2):
    # a 400 mm disc carrying 8 mm fillets and 24 windows is far below one cell
    # at the document default, and meshes as confetti. Everything else here is
    # left to the document's own setting.
    quality="ultra")
cad.set_color("stator_plate", COL_PRINT_STATOR, finish="matte")

# =============================================================================
# STATOR HUB — printed. A revolved bush that presses into the plate bore and
# carries the two 6902 bearings (seats R14 x 7 deep at each end), with a
# registration flange under the plate.
#
# A revolve profile is the one place a THICKNESS is ordinary sketch geometry,
# so this part is dimensioned the way a lathe drawing is: the bearing seat
# radius and depth, and the flange, are real dimensions on real lines.
# =============================================================================
cad.with_sketch("zx")
HUB_R_BORE = 8.5                  # clears the 15 mm shaft
HUB_R_SEAT = 14.0                 # 6902 outer radius — the press-fit seat
HUB_R_BODY = 24.0                 # body radius, a slip fit in the plate bore
HUB_R_FLANGE = 32.0               # registration flange under the plate
HUB_HALF_H = 16.0                 # half the overall hub height
HUB_SEAT_D = 7.0                  # 6902 width — seat depth at each end

V_HUB_R_SEAT = cad.variable(HUB_R_SEAT, driving=True)
V_HUB_R_BORE = cad.variable(HUB_R_BORE, driving=True)

# The profile is a half-section in (r, z): 12 points, alternating radial and
# axial runs. Consecutive segments share their endpoints by construction, so
# what the sketch still needs said is (a) that every run really is orthogonal
# and (b) the four numbers a person would change. The rest of the z-levels are
# left free on purpose — the sketch reads "6 DOFs free", which is the honest
# state for a shape whose steps follow from the seats, not the other way round.
hub_axis = cad.line2d(cad.point2d(0.0, -HUB_HALF_H), cad.point2d(0.0, HUB_HALF_H),
                      construction=True)

hub_prof = [(HUB_R_BORE, -9.0), (HUB_R_SEAT, -9.0), (HUB_R_SEAT, -HUB_HALF_H),
            (HUB_R_BODY, -HUB_HALF_H), (HUB_R_BODY, -9.0), (HUB_R_FLANGE, -9.0),
            (HUB_R_FLANGE, -7.0), (HUB_R_BODY, -7.0), (HUB_R_BODY, HUB_HALF_H),
            (HUB_R_SEAT, HUB_HALF_H), (HUB_R_SEAT, 9.0), (HUB_R_BORE, 9.0)]
hub_pts = [cad.point2d(r, z) for (r, z) in hub_prof]
hub_lines = [cad.line2d(hub_pts[j], hub_pts[j + 1]) for j in range(len(hub_pts) - 1)]
hub_lines.append(cad.line2d(hub_pts[-1], hub_pts[0]))

# Even index = a radial run (constant z); odd = an axial run (constant r).
for j in range(0, 12, 2):
    cad.horizontal(line=hub_lines[j])
for j in range(1, 12, 2):
    cad.vertical(line=hub_lines[j])

# hub_lines[1] is the lower bearing-seat wall, hub_pts[1] its shoulder corner.
cad.point_line_distance(point=hub_pts[1], line=hub_axis, distance=V_HUB_R_SEAT)
cad.point_line_distance(point=hub_pts[0], line=hub_axis, distance=V_HUB_R_BORE)
cad.length(line=hub_lines[1], length=HUB_SEAT_D)          # = the 6902's width
cad.distance(hub_pts[2], hub_pts[9], HUB_HALF_H * 2.0)    # overall hub height
cad.ensure_convergence()

stator_hub = cad.revolve("zx", cad.region(loop=hub_lines, inside=(16.0, 0.0)),
                         axis_line=hub_axis, angle=360)
cad.set_color("stator_hub", COL_PRINT_HUB, finish="matte")

# =============================================================================
# ROTOR CARRIER — printed. A 10 mm disc with 32 through-windows; each magnet
# drops in and seats directly on the steel back-iron disc behind it.
#
# Built at MODULE level (so its dimensions are live in the app) at the TOP
# rotor's height. The bottom rotor is the same part mirrored about XY — and
# because the machine is symmetric about z = 0, that single mirror lands it
# exactly where it belongs, with no follow-up move.
# =============================================================================
V_R_ROTOR = cad.variable(R_ROTOR, driving=True)
V_R_ROTOR_BORE = cad.variable(R_ROTOR_BORE, driving=True)
V_R_BOLTS = cad.variable(R_BOLTS, driving=True)
V_CARRIER_T = cad.variable(CARRIER_T, driving=True)
V_STEEL_T = cad.variable(STEEL_T, driving=True)

rc_plane = _plane_at(Z_ROTOR, "carrier_face")
cad.with_sketch(rc_plane)

rc_center = cad.point2d(0.0, 0.0)
rc_outer = cad.circle2d(rc_center, R_ROTOR)
cad.coincident(p0=rc_center, p1=origin_carrier_face)
cad.radius(circle=rc_outer, radius=V_R_ROTOR)

rcb_center = cad.point2d(0.0, 0.0)
rc_bore = cad.circle2d(rcb_center, R_ROTOR_BORE)
cad.concentric(circle1=rc_bore, circle2=rc_outer)
cad.radius(circle=rc_bore, radius=V_R_ROTOR_BORE)

rc_bolt_circle = cad.circle2d(cad.point2d(0.0, 0.0), R_BOLTS, construction=True)
cad.concentric(circle1=rc_bolt_circle, circle2=rc_outer)
cad.radius(circle=rc_bolt_circle, radius=V_R_BOLTS)

rc_holes = [[rc_bore]]
for i in range(4):                            # M4 rotor-stack bolts
    bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
    bc = cad.point2d(round(bx, 3), round(by, 3))
    rc_holes.append([cad.circle2d(bc, R_BOLT_HOLE)])
    cad.point_on_circle(point=bc, circle=rc_bolt_circle)

for i in range(N_POLES):                      # magnet windows
    ang = i * 360.0 / N_POLES
    rc_holes.append(_quad(
        [_rot(MAG_RIN - POCKET_CLEAR, -(MAG_HALF_W + POCKET_CLEAR), ang),
         _rot(MAG_ROUT + POCKET_CLEAR, -(MAG_HALF_W + POCKET_CLEAR), ang),
         _rot(MAG_ROUT + POCKET_CLEAR, MAG_HALF_W + POCKET_CLEAR, ang),
         _rot(MAG_RIN - POCKET_CLEAR, MAG_HALF_W + POCKET_CLEAR, ang)]))

cad.ensure_convergence()

rc_in = _rot(100.0, 0.0, 360.0 / N_POLES / 2.0)
carrier_top = cad.extrude(
    rc_plane,
    cad.region(loop=[rc_outer], holes=rc_holes,
               inside=(round(rc_in[0], 3), round(rc_in[1], 3))),
    V_CARRIER_T)
cad.set_color("carrier_top", COL_PRINT_CARRIER, finish="matte")

carrier_bot = cad.mirror_body(carrier_top, plane="xy")
cad.set_color("carrier_bot", COL_PRINT_CARRIER, finish="matte")

# =============================================================================
# STEEL BACK-IRON DISC — purchased, laser-cut from 3 mm mild steel. It closes
# the magnetic circuit behind the magnets and is the face they seat on.
# Send the `steel_top` body's outline out as the DXF.
# =============================================================================
sd_plane = _plane_at(Z_STEEL, "steel_face")
cad.with_sketch(sd_plane)

sd_center = cad.point2d(0.0, 0.0)
sd_outer = cad.circle2d(sd_center, R_ROTOR)
cad.coincident(p0=sd_center, p1=origin_steel_face)
cad.radius(circle=sd_outer, radius=V_R_ROTOR)      # same blank OD as the carrier

sdb_center = cad.point2d(0.0, 0.0)
sd_bore = cad.circle2d(sdb_center, R_ROTOR_BORE)
cad.concentric(circle1=sd_bore, circle2=sd_outer)
cad.radius(circle=sd_bore, radius=V_R_ROTOR_BORE)

sd_bolt_circle = cad.circle2d(cad.point2d(0.0, 0.0), R_BOLTS, construction=True)
cad.concentric(circle1=sd_bolt_circle, circle2=sd_outer)
cad.radius(circle=sd_bolt_circle, radius=V_R_BOLTS)

sd_holes = [[sd_bore]]
for i in range(4):
    bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
    sc = cad.point2d(round(bx, 3), round(by, 3))
    sd_holes.append([cad.circle2d(sc, R_BOLT_HOLE)])
    cad.point_on_circle(point=sc, circle=sd_bolt_circle)

cad.ensure_convergence()

steel_top = cad.extrude(sd_plane,
                        cad.region(loop=[sd_outer], holes=sd_holes,
                                   inside=(100.0, 20.0)),
                        V_STEEL_T, export=False)
cad.set_color("steel_top", COL_STEEL, finish="metallic")

steel_bot = cad.mirror_body(steel_top, plane="xy", export=False)
cad.set_color("steel_bot", COL_STEEL, finish="metallic")

# =============================================================================
# ROTOR HUB — printed. A flange bolted through the steel disc and carrier at
# R40, plus a shaft boss with a 15 mm bore. Cross-drill the boss for the M4
# grub screw after printing (the screw is placed below).
#
# The flange is a plate sketch; the boss is a zx-revolve so its circles do not
# land in — and subdivide — the flange's own sketch.
# =============================================================================
V_R_HUB_FLANGE = cad.variable(R_HUB_FLANGE, driving=True)
V_R_SHAFT = cad.variable(R_SHAFT, driving=True)
V_HUB_FLANGE_T = cad.variable(HUB_FLANGE_T, driving=True)

rh_plane = _plane_at(Z_HUB, "hub_face")
cad.with_sketch(rh_plane)

rh_center = cad.point2d(0.0, 0.0)
rh_outer = cad.circle2d(rh_center, R_HUB_FLANGE)
cad.coincident(p0=rh_center, p1=origin_hub_face)
cad.radius(circle=rh_outer, radius=V_R_HUB_FLANGE)

rhs_center = cad.point2d(0.0, 0.0)
rh_shaft = cad.circle2d(rhs_center, R_SHAFT)
cad.concentric(circle1=rh_shaft, circle2=rh_outer)
cad.radius(circle=rh_shaft, radius=V_R_SHAFT)

rh_bolt_circle = cad.circle2d(cad.point2d(0.0, 0.0), R_BOLTS, construction=True)
cad.concentric(circle1=rh_bolt_circle, circle2=rh_outer)
cad.radius(circle=rh_bolt_circle, radius=V_R_BOLTS)

rh_holes = [[rh_shaft]]
for i in range(4):
    bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
    hc = cad.point2d(round(bx, 3), round(by, 3))
    rh_holes.append([cad.circle2d(hc, R_BOLT_HOLE)])
    cad.point_on_circle(point=hc, circle=rh_bolt_circle)

cad.ensure_convergence()

rh_flange = cad.extrude(rh_plane,
                        cad.region(loop=[rh_outer], holes=rh_holes,
                                   inside=(25.0, 0.0)),
                        V_HUB_FLANGE_T, export=False)

cad.with_sketch("zx")
rb_z0 = Z_HUB + HUB_FLANGE_T
rb_z1 = rb_z0 + HUB_BOSS_H
rb_prof = [(R_SHAFT, rb_z0), (R_HUB_BOSS, rb_z0), (R_HUB_BOSS, rb_z1), (R_SHAFT, rb_z1)]
rb_pts = [cad.point2d(r, z) for (r, z) in rb_prof]
rb_lines = [cad.line2d(rb_pts[j], rb_pts[j + 1]) for j in range(len(rb_pts) - 1)]
rb_lines.append(cad.line2d(rb_pts[-1], rb_pts[0]))
cad.horizontal(line=rb_lines[0])
cad.horizontal(line=rb_lines[2])
cad.vertical(line=rb_lines[1])
cad.vertical(line=rb_lines[3])
cad.length(line=rb_lines[1], length=HUB_BOSS_H)

rb_axis = cad.line2d(cad.point2d(0.0, rb_z0), cad.point2d(0.0, rb_z1),
                     construction=True)
rh_boss = cad.revolve("zx", cad.region(loop=rb_lines,
                                       inside=((R_SHAFT + R_HUB_BOSS) / 2.0,
                                               (rb_z0 + rb_z1) / 2.0)),
                      axis_line=rb_axis, angle=360, export=False)

hub_top = cad.bool_union(rh_flange, rh_boss)
cad.set_color("hub_top", COL_PRINT_ROTORHUB, finish="matte")

hub_bot = cad.mirror_body(hub_top, plane="xy")
cad.set_color("hub_bot", COL_PRINT_ROTORHUB, finish="matte")

# =============================================================================
# COIL — one phase-coloured component per phase, instanced 24x. The body is the
# ENVELOPE of the winding path: a filleted trapezoidal loop (the "racetrack")
# whose window matches the magnet footprint. Not individual strands, by design.
# =============================================================================
def coil_comp(phase):
    def build():
        cad.with_sketch("xy")
        oloop = _rounded_quad([(COIL_RIN, -COIL_HALF_W_IN), (COIL_ROUT, -COIL_HALF_W_OUT),
                               (COIL_ROUT, COIL_HALF_W_OUT), (COIL_RIN, COIL_HALF_W_IN)],
                              COIL_CORNER_R)
        wloop = _rounded_quad(_coil_hole_corners(), COIL_CORNER_R - WIND_W / 2.0)
        mid_r = (MAG_RIN + MAG_ROUT) / 2.0
        bundle = cad.extrude("xy",
                             cad.region(loop=oloop, holes=[wloop], inside=(mid_r, 14.0)),
                             COIL_T, offset=-COIL_T / 2.0, export=False)
        cad.set_color(bundle, PHASE_COLORS[phase], finish="matte")
        cad.component_export(bundle, name="w")

    return cad.parametric("coil", build, phase=phase,
                          label=f"Phase {'ABC'[phase]} coil")


COIL_BY_PHASE = [coil_comp(0), coil_comp(1), coil_comp(2)]
for i in range(N_COILS):
    cad.instance(COIL_BY_PHASE[i % 3], axis=(0, 0, 1), angle=i * 360.0 / N_COILS,
                 name=f"coil{i}", export=False)

# =============================================================================
# COIL FORMER — printed, 24 off. A core that fills the winding window: wind
# each coil directly onto one of these, then epoxy former + coil into its
# stator window together. Modeled 0.15 mm under the window all round.
# =============================================================================
with cad.component("coil_former", label="Coil winding former (printed)"):
    cad.with_sketch("xy")
    cf_loop = _rounded_quad(_coil_hole_corners(inset=0.15),
                            COIL_CORNER_R - WIND_W / 2.0 - 0.15)
    cf_body = cad.extrude("xy",
                          cad.region(loop=cf_loop,
                                     inside=((COIL_RIN + COIL_ROUT) / 2.0, 0.0)),
                          COIL_T, offset=-COIL_T / 2.0)
    cad.set_color(cf_body, "#ECEFF1", finish="matte")
    cad.component_export(cf_body, name="core")

for i in range(N_COILS):
    cad.instance("coil_former", axis=(0, 0, 1), angle=i * 360.0 / N_COILS,
                 name=f"former{i}")

# =============================================================================
# MAGNET — N42 block 40 x 20 x 10, drawn at its working radius so an instance
# only has to rotate about the axis. Colour = the pole facing the stator.
# =============================================================================
def magnet_comp(pole):
    def build():
        cad.with_sketch("xy")
        outline = _quad([(MAG_RIN, -MAG_HALF_W), (MAG_ROUT, -MAG_HALF_W),
                         (MAG_ROUT, MAG_HALF_W), (MAG_RIN, MAG_HALF_W)])
        mid_r = (MAG_RIN + MAG_ROUT) / 2.0
        blk = cad.extrude("xy", cad.region(loop=outline, inside=(mid_r, 0.0)),
                          MAG_T, export=False)
        cad.set_color(blk, COL_N if pole == "N" else COL_S, finish="metallic")
        cad.component_export(blk, name="m")

    return cad.parametric("mag40x20x10", build, pole=pole,
                          label=f"N42 block 40x20x10, {pole} to stator")


MAG_N = magnet_comp("N")
MAG_S = magnet_comp("S")
for i in range(N_POLES):
    ang = i * 360.0 / N_POLES
    # Top rotor N,S,N,... facing down; bottom rotor the opposite pole facing
    # up, so flux crosses the stator and returns through the steel discs.
    cad.instance(MAG_N if i % 2 == 0 else MAG_S, axis=(0, 0, 1), angle=ang,
                 translate=(0, 0, Z_ROTOR), name=f"mag_t{i}", export=False)
    cad.instance(MAG_S if i % 2 == 0 else MAG_N, axis=(0, 0, 1), angle=ang,
                 translate=(0, 0, -(Z_ROTOR + MAG_T)), name=f"mag_b{i}", export=False)

# =============================================================================
# CATALOG PARTS — every one of these is a standard-library factory, vendored
# into lib/standard/. Screws are MATED onto the holes they pass through, so
# moving a bolt circle in the app carries its hardware with it.
# =============================================================================

# ---- shaft: 15 mm ground stock, 100 mm, chamfered both ends ----------------
SHAFT_LEN = 100.0
shaft_inst = cad.instance(shaft(cad, diameter=R_SHAFT * 2.0, length=SHAFT_LEN,
                                end="chamfered"),
                          translate=(0, 0, -SHAFT_LEN / 2.0), name="shaft",
                          export=False)

# ---- 2x 6902 in the stator hub's end seats ---------------------------------
BRG = bearing(cad, designation="6902")
cad.instance(BRG, translate=(0, 0, -HUB_HALF_H), name="brg_low", export=False)
cad.instance(BRG, translate=(0, 0, HUB_HALF_H - HUB_SEAT_D), name="brg_high",
             export=False)

# ---- 8x M4 x 30 rotor-stack bolts, with a washer and a nut each -------------
# Head bears on the rotor hub's flange top; the nut lands under the carrier.
M4_SCREW = cap_screw(cad, thread="M4", length=30.0)
M4_WASHER = washer(cad, thread="M4")
M4_NUT = hex_nut(cad, thread="M4")
Z_STACK_TOP = Z_HUB + HUB_FLANGE_T            # screws enter here, pointing -Z
for i in range(4):
    bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
    cad.instance(M4_SCREW, translate=(bx, by, Z_STACK_TOP),
                 name=f"bolt_t{i}", export=False)
    cad.instance(M4_NUT, translate=(bx, by, Z_ROTOR - 3.2),
                 name=f"nut_t{i}", export=False)
    cad.instance(M4_WASHER, translate=(bx, by, Z_ROTOR - 4.0),
                 name=f"wsh_t{i}", export=False)
    cad.instance(M4_SCREW, mirror_plane="xy", translate=(bx, by, -Z_STACK_TOP),
                 name=f"bolt_b{i}", export=False)
    cad.instance(M4_NUT, translate=(bx, by, -(Z_ROTOR - 3.2) - 3.2),
                 name=f"nut_b{i}", export=False)
    cad.instance(M4_WASHER, translate=(bx, by, -(Z_ROTOR - 4.0) - 0.8),
                 name=f"wsh_b{i}", export=False)

# ---- 6x M5 x 16 stator mounting screws -------------------------------------
M5_SCREW = cap_screw(cad, thread="M5", length=16.0)
for i in range(6):
    mx, my = _rot(R_MOUNT, 0.0, i * 60.0)
    cad.instance(M5_SCREW, translate=(mx, my, STATOR_T / 2.0),
                 name=f"mount{i}", export=False)

# ---- 2x M4 grub screw locking each rotor hub to the shaft -------------------
# Cross-drilled radially through the boss after printing; shown at the boss
# mid-height on the +X side.
M4_GRUB = grub_screw(cad, thread="M4", length=6.0)
Z_GRUB = Z_HUB + HUB_FLANGE_T + HUB_BOSS_H / 2.0
cad.instance(M4_GRUB, axis=(0, 1, 0), angle=90.0,
             translate=(R_HUB_BOSS, 0.0, Z_GRUB), name="grub_t", export=False)
cad.instance(M4_GRUB, axis=(0, 1, 0), angle=90.0,
             translate=(R_HUB_BOSS, 0.0, -Z_GRUB), name="grub_b", export=False)

# ---- 2x shaft collar: the axial stop that keeps the rotors off the stator ---
COLLAR = shaft_collar(cad, bore=R_SHAFT * 2.0, style="split")
COLLAR_W = max(R_SHAFT * 2.0 * 0.5, 5.0)
cad.instance(COLLAR, translate=(0, 0, HUB_HALF_H + 0.5), name="collar_top",
             export=False)
cad.instance(COLLAR, translate=(0, 0, -(HUB_HALF_H + 0.5) - COLLAR_W),
             name="collar_bot", export=False)

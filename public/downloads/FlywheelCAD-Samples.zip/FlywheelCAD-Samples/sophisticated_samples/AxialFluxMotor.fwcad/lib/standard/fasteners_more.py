# flywheelcad standard library
"""More metric fasteners: countersunk & button-head socket screws, socket set
(grub) screws, heat-set threaded inserts, hex standoffs, and threaded rod.

Companion to fasteners.py (cap screws / nuts / washers). Dimensions follow:
    countersunk   ISO 10642 / DIN 7991 (90° flat head, hex socket)
    button head   ISO 7380-1           (dome head, hex socket)
    grub screw    ISO 4026 / DIN 913   (headless socket set screw)
    heat-set      common brass tapered press-in inserts (McMaster / CNC Kitchen
                  catalog class) — outer Ø, length, bore per thread
    standoff      common hex brass PCB standoff (across-flats + bore per thread)
    threaded rod  ISO 261 nominal major Ø

`grub_screw` and `threaded_rod` are fully-threaded parts, so both take a
`threads="cosmetic"|"real"` parameter (see `fasteners.cap_screw`'s docstring
for the full convention/forced-quality writeup this follows) — "cosmetic"
(default) is a smooth cylinder, "real" cuts an ISO metric 60° V-thread the
full length via `cad.helix(...)` + `cad.sweep(...)`.

Orientation (screws / grub / insert): the seating plane is world XY at z = 0.
    countersunk  flush top face at z = 0, cone + shank point DOWN (-Z)
    button head  under-head at z = 0, dome UP (+Z), shank DOWN (-Z)
    grub screw   top at z = 0, points DOWN (-Z)
    heat-set     flush top face at z = 0, body pressed DOWN (-Z)
Standoffs and rod STAND UP: base/end_a at z = 0, top/end_b at +Z.

Anchor contract:
    countersunk / grub / heat-set : top (0,0,0), tip
    button head                   : under_head (0,0,0), head_top, tip
    standoff                      : base (0,0,0), top ; M-F also stud_end
    threaded rod                  : end_a (0,0,0), end_b
"""

__library_version__ = "1.1"

import math

# thread -> nominal Ø, and per-type head/socket dimensions (mm).
# csk  = ISO 10642 flat head (dk, head height k, socket s)
# btn  = ISO 7380 button head (dk, k, s)
# grub = ISO 4026 socket across-flats s
METRIC = {
    "M2":   dict(dia=2.0, csk=(4.0,  1.2, 1.5), btn=(3.8,  1.3, 1.3), grub=1.0),
    "M2.5": dict(dia=2.5, csk=(5.0,  1.5, 2.0), btn=(4.7,  1.5, 1.5), grub=1.3),
    "M3":   dict(dia=3.0, csk=(6.0,  1.7, 2.0), btn=(5.7,  1.65, 2.0), grub=1.5),
    "M4":   dict(dia=4.0, csk=(8.0,  2.3, 2.5), btn=(7.6,  2.2, 2.5), grub=2.0),
    "M5":   dict(dia=5.0, csk=(10.0, 2.8, 3.0), btn=(9.5,  2.75, 3.0), grub=2.5),
    "M6":   dict(dia=6.0, csk=(12.0, 3.3, 4.0), btn=(10.5, 3.3, 4.0), grub=3.0),
    "M8":   dict(dia=8.0, csk=(16.0, 4.4, 5.0), btn=(14.0, 4.4, 5.0), grub=4.0),
}

# Heat-set insert: (top Ø, tip Ø, length, thread bore) — tapered brass press-in.
HEATSET = {
    "M2":   dict(od_top=3.6, od_tip=3.2, length=4.0, bore=1.7),
    "M2.5": dict(od_top=4.2, od_tip=3.6, length=5.0, bore=2.1),
    "M3":   dict(od_top=5.0, od_tip=4.0, length=5.7, bore=2.5),
    "M4":   dict(od_top=6.0, od_tip=5.0, length=8.1, bore=3.3),
    "M5":   dict(od_top=7.0, od_tip=6.0, length=9.5, bore=4.2),
}

# Hex standoff across-flats by thread (common brass PCB standoff).
STANDOFF_AF = {"M2": 4.0, "M2.5": 5.0, "M3": 5.5, "M4": 7.0, "M5": 8.0}

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL lists
# of str/int/float — a variable or list(...) call yields NO dropdown. So every
# choice list is spelled out literally here. Enumerated thread + quality + the
# standoff gender get dropdowns; continuous lengths stay free-text.
PARAM_CHOICES = {
    "*": {
        "thread": ["M2", "M2.5", "M3", "M4", "M5", "M6", "M8"],
        "quality": ["preview", "standard", "high", "ultra"],
    },
    "heatset_insert": {"thread": ["M2", "M2.5", "M3", "M4", "M5"]},
    "standoff": {
        "thread": ["M2", "M2.5", "M3", "M4", "M5"],
        "gender": ["female-female", "male-female"],
    },
    "grub_screw": {"threads": ["cosmetic", "real"]},
    "threaded_rod": {"threads": ["cosmetic", "real"]},
    "countersunk": {"threads": ["cosmetic", "real"]},
    "button_head": {"threads": ["cosmetic", "real"]},
}

_STEEL = "#455A64"
_BRASS = "#B08D57"

# ISO 261 coarse pitch (mm), same series as fasteners.py's METRIC table — this
# module's own METRIC dict above only carries diameter, so the pitch used to
# geometrically cut a "real" thread (grub_screw / threaded_rod) is repeated
# here rather than cross-imported (every module in this library is
# self-contained; see fasteners.cap_screw for the fundamentals this shares).
_ISO_PITCH = {
    "M2": 0.40, "M2.5": 0.45, "M3": 0.50, "M4": 0.70,
    "M5": 0.80, "M6": 1.00, "M8": 1.25,
}
_THREAD_HALF_ANGLE = math.radians(30.0)
_THREAD_DEPTH_FACTOR = 0.6134


def _v_thread_region(cad, pitch):
    """An ISO metric 60° V-thread tooth: a triangle, apex pointing radially
    INWARD (negative local-x — `cad.sweep`'s (u, v) map to (path normal =
    radially outward, binormal)), CENTERED AT THE SKETCH ORIGIN, depth
    ≈0.6134×pitch. See `fasteners.cap_screw` for the full writeup."""
    depth = _THREAD_DEPTH_FACTOR * pitch
    half_base = depth * math.tan(_THREAD_HALF_ANGLE)
    cad.with_sketch("xy")
    apex = cad.point2d(-depth, 0.0)
    crest_a = cad.point2d(0.0, half_base)
    crest_b = cad.point2d(0.0, -half_base)
    t1 = cad.line2d(apex, crest_a)
    t2 = cad.line2d(crest_a, crest_b)
    t3 = cad.line2d(crest_b, apex)
    return cad.region(loop=[t1, t2, t3], inside=(-depth / 3.0, 0.0))


def _cut_real_thread(cad, body, radius, pitch, turns, axis_origin, quality):
    """Sweep the V-thread tooth along a helix at `radius` and difference it
    out of `body` — a real cut thread the full `turns * pitch` length."""
    tooth = _v_thread_region(cad, pitch)
    path = cad.helix(radius=radius, pitch=pitch, turns=turns, axis_origin=axis_origin)
    tool = cad.sweep("xy", tooth, path, quality=quality, export=False)
    return cad.bool_difference(body, tool, quality=quality)


def _plane_at(cad, z):
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _hexagon(cad, af, cx=0.0, cy=0.0):
    """Hex outline (list of lines) from across-flats width, flats top/bottom."""
    r = (af / 2.0) / math.cos(math.radians(30.0))
    pts = [cad.point2d(cx + r * math.cos(math.radians(60 * k + 30)),
                       cy + r * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


def _hex_socket(cad, af, top_z, depth, quality):
    """A negative body: a hex recess cut down from top_z by `depth`."""
    plane = _plane_at(cad, top_z + 0.5)
    cad.with_sketch(plane)
    outline = _hexagon(cad, af)
    return cad.extrude(plane, cad.region(loop=outline, inside=(0.0, 0.0)),
                       depth + 0.5, offset=-(depth + 0.5), quality=quality, export=False)


def _revolve_profile(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) profile on ZX about the axis at r = 0.

    on_axis=True: the profile touches r = 0, so the closing edge IS the axis.
    on_axis=False: annular profile — a separate r = 0 construction axis is used.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


# Dimensions per ISO 10642 / DIN 7991
def countersunk(cad, thread="M3", length=12.0, quality=None, threads="cosmetic"):
    """An ISO 10642 flat (countersunk) socket-head screw.

    thread: "M2".."M8";  length: flush-top face to tip, mm.
    Anchors: top (z=0, flush face), tip. Head + shank point -Z.

    threads: "cosmetic" (default) — a smooth shank, as before. "real" — an
             actual ISO metric 60° V-thread cut along the CYLINDRICAL shank
             only, from the tip up to the base of the 90° cone (z=-k) — the
             cone itself is left unthreaded (a countersunk screw's taper
             isn't a constant-radius section a helix can cut into) — via
             `cad.helix(...)` + `cad.sweep(...)` + `bool_difference`, same
             pattern as `fasteners.cap_screw`. Like `cap_screw`,
             `threads="real"` FORCES a high-resolution mesh regardless of the
             `quality` argument — "ultra" for pitch < 0.6 mm (M2/M2.5/M3),
             "high" otherwise.
    """
    key = str(thread).upper()
    d = METRIC[key]
    dia, (dk, k, s) = d["dia"], d["csk"]
    length = float(length)
    thread_mode = str(threads).lower()
    real_threads = thread_mode == "real"
    pitch = _ISO_PITCH[key]
    build_quality = ("ultra" if pitch < 0.6 else "high") if real_threads else quality

    def build():
        r, hr = dia / 2.0, dk / 2.0
        # (radius, height): flush rim at z=0, 90° cone down to the shank, then
        # the shank to the tip, closing up the axis.
        solid = _revolve_profile(cad, [
            (0.0, 0.0), (hr, 0.0), (r, -k), (r, -length), (0.0, -length),
        ], inside=(r / 2.0, -length / 2.0), quality=build_quality)
        socket = _hex_socket(cad, s, 0.0, k * 0.75, build_quality)
        screw = cad.bool_difference(solid, socket, quality=build_quality)
        if real_threads:
            thread_len = length - k
            turns = thread_len / pitch
            screw = _cut_real_thread(cad, screw, r, pitch, turns,
                                     axis_origin=(0.0, 0.0, -length), quality=build_quality)
        cad.set_color(screw, _STEEL, finish="metallic")
        cad.component_export(screw)
        cad.component_export_point("top", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"csk_{key.replace('.', '_')}", build,
                          length=length, threads=thread_mode, quality=quality or "std",
                          label=f"{key} x {length:g} countersunk" + (" (real threads)" if real_threads else ""))


# Dimensions per ISO 7380-1
def button_head(cad, thread="M3", length=12.0, quality=None, threads="cosmetic"):
    """An ISO 7380 button (dome) head socket screw.

    Anchors: under_head (z=0), head_top, tip. Dome up (+Z), shank down (-Z).

    threads: "cosmetic" (default) — a smooth shank, as before. "real" — an
             actual ISO metric 60° V-thread cut the full shank length, via
             `cad.helix(...)` + `cad.sweep(...)` + `bool_difference`, same
             pattern as `fasteners.cap_screw`. Like `cap_screw`,
             `threads="real"` FORCES a high-resolution mesh regardless of the
             `quality` argument — "ultra" for pitch < 0.6 mm (M2/M2.5/M3),
             "high" otherwise.
    """
    key = str(thread).upper()
    d = METRIC[key]
    dia, (dk, k, s) = d["dia"], d["btn"]
    length = float(length)
    thread_mode = str(threads).lower()
    real_threads = thread_mode == "real"
    pitch = _ISO_PITCH[key]
    build_quality = ("ultra" if pitch < 0.6 else "high") if real_threads else quality

    def build():
        r, hr = dia / 2.0, dk / 2.0
        # Dome approximated by an arc of points from the rim (hr, 0) up to the
        # crown (0, k); the crown sits on the axis, so the closing edge is the
        # revolve axis (no extra apex point — that would be a zero-length edge).
        n = 6
        dome = [(hr * math.cos(math.pi / 2 * t / n),
                 k * math.sin(math.pi / 2 * t / n)) for t in range(n + 1)]
        pts = [(0.0, -length), (r, -length), (r, 0.0)] + dome
        solid = _revolve_profile(cad, pts, inside=(r / 2.0, -length / 2.0), quality=build_quality)
        socket = _hex_socket(cad, s, k, k * 0.6, build_quality)
        screw = cad.bool_difference(solid, socket, quality=build_quality)
        if real_threads:
            turns = length / pitch
            screw = _cut_real_thread(cad, screw, r, pitch, turns,
                                     axis_origin=(0.0, 0.0, -length), quality=build_quality)
        cad.set_color(screw, _STEEL, finish="metallic")
        cad.component_export(screw)
        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("head_top", cad.point(0.0, 0.0, k))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"btn_{key.replace('.', '_')}", build,
                          length=length, threads=thread_mode, quality=quality or "std",
                          label=f"{key} x {length:g} button head" + (" (real threads)" if real_threads else ""))


# Dimensions per ISO 4026 / DIN 913
def grub_screw(cad, thread="M3", length=6.0, quality=None, threads="cosmetic"):
    """An ISO 4026 socket set (grub) screw: a headless threaded cylinder with
    a hex socket. Anchors: top (z=0), tip. Points -Z.

    threads: "cosmetic" (default) — a smooth cylinder, as before. "real" — a
             real ISO metric 60° V-thread cut the full length (grub screws
             are fully threaded), via `cad.helix(...)` + `cad.sweep(...)` +
             `bool_difference`. Like `fasteners.cap_screw`, `threads="real"`
             FORCES high-resolution meshing on this part regardless of the
             `quality` argument — "ultra" for pitch < 0.6 mm (M2/M2.5/M3),
             "high" otherwise.
    """
    key = str(thread).upper()
    d = METRIC[key]
    dia, s = d["dia"], d["grub"]
    length = float(length)
    thread_mode = str(threads).lower()
    real_threads = thread_mode == "real"
    pitch = _ISO_PITCH[key]
    build_quality = ("ultra" if pitch < 0.6 else "high") if real_threads else quality

    def build():
        r = dia / 2.0
        solid = _revolve_profile(cad, [
            (0.0, 0.0), (r, 0.0), (r, -length), (0.0, -length),
        ], inside=(r / 2.0, -length / 2.0), quality=build_quality)
        socket = _hex_socket(cad, s, 0.0, min(length * 0.5, r * 1.6), build_quality)
        screw = cad.bool_difference(solid, socket, quality=build_quality)
        if real_threads:
            turns = length / pitch
            screw = _cut_real_thread(cad, screw, r, pitch, turns,
                                     axis_origin=(0.0, 0.0, -length), quality=build_quality)
        cad.set_color(screw, _STEEL, finish="metallic")
        cad.component_export(screw)
        cad.component_export_point("top", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"grub_{key.replace('.', '_')}", build,
                          length=length, threads=thread_mode, quality=quality or "std",
                          label=f"{key} x {length:g} grub screw" + (" (real threads)" if real_threads else ""))


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def heatset_insert(cad, thread="M3", quality=None):
    """A tapered brass heat-set threaded insert (press-in, for 3D prints).

    Anchors: top (z=0, flush face), tip. Body presses -Z into the part."""
    key = str(thread).upper()
    h = HEATSET[key]
    top_r, tip_r = h["od_top"] / 2.0, h["od_tip"] / 2.0
    L, bore_r = h["length"], h["bore"] / 2.0

    def build():
        # Annular cross-section (bore wall -> outer wall), so a separate r=0
        # construction axis carries the revolve.
        ins = _revolve_profile(cad, [
            (bore_r, 0.0), (top_r, 0.0), (tip_r, -L), (bore_r, -L),
        ], inside=((bore_r + top_r) / 2.0, -L / 2.0), quality=quality, on_axis=False)
        cad.set_color(ins, _BRASS, finish="metallic")
        cad.component_export(ins)
        cad.component_export_point("top", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -L))

    return cad.parametric(f"heatset_{key.replace('.', '_')}", build,
                          quality=quality or "std",
                          label=f"{key} heat-set insert")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def standoff(cad, thread="M3", length=15.0, gender="female-female", quality=None):
    """A hex brass standoff. Anchors: base (z=0), top (z=length); a male-female
    standoff also exposes stud_end (below the base). Stands up +Z."""
    key = str(thread).upper()
    af = STANDOFF_AF[key]
    dia = METRIC[key]["dia"]
    length = float(length)
    male = str(gender).lower().startswith("male")
    stud_len = min(6.0, length * 0.4) if male else 0.0

    def build():
        cad.with_sketch("xy")
        outline = _hexagon(cad, af)
        bore = cad.circle2d(cad.point2d(0.0, 0.0), (dia + 0.3) / 2.0)
        # Female bore is a region hole; a male stud is added below the base.
        body = cad.extrude("xy",
                           cad.region(loop=outline, holes=[[bore]],
                                      inside=(0.0, af / 2.0 - 0.3)),
                           length, quality=quality, export=(not male))
        if male:
            stud = _revolve_profile(cad, [
                (0.0, 0.0), (dia / 2.0, 0.0), (dia / 2.0, -stud_len), (0.0, -stud_len),
            ], inside=(dia / 4.0, -stud_len / 2.0), quality=quality)
            body = cad.bool_union(body, stud, quality=quality)
        cad.set_color(body, _BRASS, finish="metallic")
        cad.component_export(body)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, length))
        if male:
            cad.component_export_point("stud_end", cad.point(0.0, 0.0, -stud_len))

    return cad.parametric(f"standoff_{key.replace('.', '_')}", build,
                          length=length, gender=("mf" if male else "ff"),
                          quality=quality or "std",
                          label=f"{key} standoff {length:g} ({'M-F' if male else 'F-F'})")


# Dimensions per ISO 261
def threaded_rod(cad, thread="M3", length=60.0, quality=None, threads="cosmetic"):
    """Threaded rod / studding at the nominal major diameter. Stands up +Z.
    Anchors: end_a (z=0), end_b (z=length).

    threads: "cosmetic" (default) — a smooth cylinder, as before. "real" — a
             real ISO metric 60° V-thread cut the full length, via
             `cad.helix(...)` + `cad.sweep(...)` + `bool_difference`. Like
             `fasteners.cap_screw`, `threads="real"` FORCES high-resolution
             meshing on this part regardless of the `quality` argument —
             "ultra" for pitch < 0.6 mm (M2/M2.5/M3), "high" otherwise.
    """
    key = str(thread).upper()
    dia = METRIC[key]["dia"]
    length = float(length)
    thread_mode = str(threads).lower()
    real_threads = thread_mode == "real"
    pitch = _ISO_PITCH[key]
    build_quality = ("ultra" if pitch < 0.6 else "high") if real_threads else quality

    def build():
        r = dia / 2.0
        rod = _revolve_profile(cad, [
            (0.0, 0.0), (r, 0.0), (r, length), (0.0, length),
        ], inside=(r / 2.0, length / 2.0), quality=build_quality)
        if real_threads:
            turns = length / pitch
            rod = _cut_real_thread(cad, rod, r, pitch, turns,
                                   axis_origin=(0.0, 0.0, 0.0), quality=build_quality)
        cad.set_color(rod, _STEEL, finish="metallic")
        cad.component_export(rod)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, length))

    return cad.parametric(f"rod_{key.replace('.', '_')}", build,
                          length=length, threads=thread_mode, quality=quality or "std",
                          label=f"{key} x {length:g} threaded rod" + (" (real threads)" if real_threads else ""))

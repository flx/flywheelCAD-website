# flywheelcad standard library
"""Metric fasteners: socket head cap screws, hex nuts, washers — and the
matching NEGATIVE bodies (clearance and tap volumes) for boolean cuts.

Dimensions follow DIN 912 (socket head cap screws), ISO 4032 (hex nuts),
ISO 7089 (flat washers), and ISO 273 medium-fit clearance holes, for
threads M2 through M8.

The negative-body factories are the workflow feature: place a screw AND
cut its hole in two lines —

    from lib.standard.fasteners import cap_screw, clearance
    s = cap_screw(cad, thread="M3", length=12)
    c = clearance(cad, thread="M3", length=12, head_pocket=True)
    screw1 = cad.instance(s, translate=(20, 0, 5))
    cut1 = cad.instance(c, translate=(20, 0, 5), export=False)
    plate = cad.bool_difference(plate, cut1)

`cap_screw`'s shank is cosmetic-smooth by default (`threads="cosmetic"`);
pass `threads="real"` for an actual ISO metric 60° V-thread, cut the full
shank length via `cad.helix(...)` + `cad.sweep(...)` + `bool_difference` —
see that factory's docstring for the forced-quality caveat.

Orientation (all parts): the under-head / seating plane is world XY at
z = 0; screws and negatives point DOWN (-Z), heads and pockets up (+Z).

Anchor contract:
    screws:     under_head (0,0,0), head_top, tip
    nuts:       top, bottom (both on the axis)
    washers:    top, bottom
    negatives:  under_head (0,0,0), tip
"""

__library_version__ = "1.1"

import math

# thread: pitch, clearance hole Ø (ISO 273 medium), tap drill Ø,
# DIN 912 head (Ø, height, socket across-flats),
# ISO 4032 nut (across-flats, height), ISO 7089 washer (OD, thickness).
METRIC = {
    "M2":   dict(pitch=0.40, clear_d=2.4, tap_d=1.6,
                 head_d=3.8,  head_h=2.0, socket=1.5,
                 nut_af=4.0,  nut_h=1.6,  washer_od=5.0,  washer_t=0.3),
    "M2.5": dict(pitch=0.45, clear_d=2.9, tap_d=2.05,
                 head_d=4.5,  head_h=2.5, socket=2.0,
                 nut_af=5.0,  nut_h=2.0,  washer_od=6.0,  washer_t=0.5),
    "M3":   dict(pitch=0.50, clear_d=3.4, tap_d=2.5,
                 head_d=5.5,  head_h=3.0, socket=2.5,
                 nut_af=5.5,  nut_h=2.4,  washer_od=7.0,  washer_t=0.5),
    "M4":   dict(pitch=0.70, clear_d=4.5, tap_d=3.3,
                 head_d=7.0,  head_h=4.0, socket=3.0,
                 nut_af=7.0,  nut_h=3.2,  washer_od=9.0,  washer_t=0.8),
    "M5":   dict(pitch=0.80, clear_d=5.5, tap_d=4.2,
                 head_d=8.5,  head_h=5.0, socket=4.0,
                 nut_af=8.0,  nut_h=4.7,  washer_od=10.0, washer_t=1.0),
    "M6":   dict(pitch=1.00, clear_d=6.6, tap_d=5.0,
                 head_d=10.0, head_h=6.0, socket=5.0,
                 nut_af=10.0, nut_h=5.2,  washer_od=12.0, washer_t=1.6),
    "M8":   dict(pitch=1.25, clear_d=9.0, tap_d=6.8,
                 head_d=13.0, head_h=8.0, socket=6.0,
                 nut_af=13.0, nut_h=6.8,  washer_od=16.0, washer_t=1.6),
}

# Dropdown choices for the browser's "Insert from Library" parameter form.
# Every factory (cap_screw, hex_nut, washer, clearance, tap) takes the same
# "thread" domain (the METRIC table's keys) and the same "quality" domain.
PARAM_CHOICES = {
    "*": {
        "thread": ["M2", "M2.5", "M3", "M4", "M5", "M6", "M8"],
        "quality": ["preview", "standard", "high", "ultra"],
    },
    "cap_screw": {"threads": ["cosmetic", "real"]},
    "hex_nut": {"threads": ["cosmetic", "real"]},
}

# ISO metric 60° V-thread fundamentals (shared by the "real" thread cut):
# half-angle 30° off the crest/root centerline, actual thread depth (external,
# ISO 68-1 h3 = 17H/24) ≈ 0.6134 × pitch, where H = pitch·sqrt(3)/2 is the
# fundamental-triangle height.
_THREAD_HALF_ANGLE = math.radians(30.0)
_THREAD_DEPTH_FACTOR = 0.6134


def _nominal(thread):
    return float(str(thread).lstrip("Mm"))


def _plane_at(cad, z):
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _hexagon(cad, af, cx=0.0, cy=0.0):
    """Hexagon outline from across-flats width, flats up/down."""
    r = (af / 2.0) / math.cos(math.radians(30.0))  # across-corners radius
    pts = []
    for k in range(6):
        a = math.radians(60.0 * k + 30.0)
        pts.append(cad.point2d(cx + r * math.cos(a), cy + r * math.sin(a)))
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


def _v_thread_region_internal(cad, pitch):
    """The INTERNAL counterpart of an ISO metric 60° V-thread tooth: the same
    triangle as the external tooth (see `cap_screw`), but the apex points
    radially OUTWARD (positive local-x — opposite of the external tooth's
    negative local-x), CENTERED AT THE SKETCH ORIGIN, depth ≈0.6134×pitch.

    Swept along a helix AT THE BORE'S OWN (minor-diameter) radius and
    differenced out of a nut, this widens an initial minor-diameter bore
    outward to ~nominal (major) diameter along the helix, leaving the un-cut
    crest ridges (at the minor diameter) between turns — the visual
    appearance of an internal thread. See `hex_nut` for the full writeup."""
    depth = _THREAD_DEPTH_FACTOR * pitch
    half_base = depth * math.tan(_THREAD_HALF_ANGLE)
    cad.with_sketch("xy")
    apex = cad.point2d(depth, 0.0)
    crest_a = cad.point2d(0.0, half_base)
    crest_b = cad.point2d(0.0, -half_base)
    t1 = cad.line2d(apex, crest_a)
    t2 = cad.line2d(crest_a, crest_b)
    t3 = cad.line2d(crest_b, apex)
    return cad.region(loop=[t1, t2, t3], inside=(depth / 3.0, 0.0))


def _cut_real_internal_thread(cad, body, bore_radius, pitch, turns, axis_origin, quality):
    """Sweep the internal V-thread tooth along a helix at `bore_radius` (the
    bore's own minor-diameter radius — the bore must already be cut to this
    radius before calling this) and difference it out of `body`. The tool
    widens the groove outward to ~nominal (major) diameter, leaving the
    un-cut crest ridges between turns — a real cut internal thread the full
    `turns * pitch` length."""
    tooth = _v_thread_region_internal(cad, pitch)
    path = cad.helix(radius=bore_radius, pitch=pitch, turns=turns, axis_origin=axis_origin)
    tool = cad.sweep("xy", tooth, path, quality=quality, export=False)
    return cad.bool_difference(body, tool, quality=quality)


# Dimensions per DIN 912
def cap_screw(cad, thread="M3", length=12.0, quality=None, threads="cosmetic"):
    """A DIN 912 socket head cap screw.

    thread: "M2" … "M8";  length: under-head to tip, mm.
    threads: "cosmetic" (default) — a smooth unthreaded shank, as before.
             "real" — an actual ISO metric 60° V-thread cut the full shank
             length: a triangular tooth profile (depth ≈0.6134×pitch,
             pointing radially inward, centered at the sketch origin) swept
             along a `cad.helix(...)` at the shank's nominal radius, then
             `bool_difference`d out of the shank. A real thread groove is
             sub-cell at coarse dual-contouring resolutions (see
             archive/docs-2026-08-23/ArchitectureNotes-Sweep.md §0), so `threads="real"` FORCES a
             high-resolution mesh on this part regardless of the `quality`
             argument — "ultra" for pitch < 0.6 mm (M2/M2.5/M3), "high"
             otherwise. Thread runout/chamfer is not modeled (a clean
             stopping thread at each end).
    Anchors: under_head (z=0), head_top, tip. Points -Z.
    """
    key = str(thread).upper()
    d = METRIC[key]
    length = float(length)
    nominal = _nominal(key)
    thread_mode = str(threads).lower()
    real_threads = thread_mode == "real"
    pitch = d["pitch"]
    build_quality = ("ultra" if pitch < 0.6 else "high") if real_threads else quality

    def build():
        head_r, head_h = d["head_d"] / 2.0, d["head_h"]
        # Head + shank as one stepped revolve on zx (radius, height), with
        # a small under-head chamfer step for the catalog silhouette.
        cad.with_sketch("zx")
        q1 = cad.point2d(0.0, -length)
        q2 = cad.point2d(nominal / 2.0, -length)
        q3 = cad.point2d(nominal / 2.0, 0.0)
        q4 = cad.point2d(head_r, 0.0)
        q5 = cad.point2d(head_r, head_h)
        q6 = cad.point2d(0.0, head_h)
        e1 = cad.line2d(q1, q2)
        e2 = cad.line2d(q2, q3)
        e3 = cad.line2d(q3, q4)
        e4 = cad.line2d(q4, q5)
        e5 = cad.line2d(q5, q6)
        e6 = cad.line2d(q6, q1)  # closes along the axis
        solid = cad.revolve("zx",
                            cad.region(loop=[e1, e2, e3, e4, e5, e6],
                                       inside=(nominal / 4.0, -length / 2.0)),
                            axis_line=e6, angle=360.0, quality=build_quality, export=False)

        # Hex socket recess in the head.
        socket_af = d["socket"]
        depth = head_h * 0.6
        s_plane = _plane_at(cad, head_h + 0.5)
        cad.with_sketch(s_plane)
        hex_outline = _hexagon(cad, socket_af)
        cut = cad.extrude(s_plane,
                          cad.region(loop=hex_outline, inside=(0.0, 0.0)),
                          depth + 0.5, offset=-(depth + 0.5), quality=build_quality, export=False)

        screw = cad.bool_difference(solid, cut, quality=build_quality)

        if real_threads:
            # A single ISO 60° V tooth (apex pointing radially INWARD, i.e.
            # negative local-x — cad.sweep's (u, v) map to (path normal =
            # radially outward, binormal)), drawn CENTERED AT THE SKETCH
            # ORIGIN so the nominal radius lives entirely in the helix path,
            # not the profile. Swept at the shank's outer (major-diameter)
            # radius over the full threaded length and differenced out.
            depth_h = _THREAD_DEPTH_FACTOR * pitch
            half_base = depth_h * math.tan(_THREAD_HALF_ANGLE)
            cad.with_sketch("xy")
            apex = cad.point2d(-depth_h, 0.0)
            crest_a = cad.point2d(0.0, half_base)
            crest_b = cad.point2d(0.0, -half_base)
            t1 = cad.line2d(apex, crest_a)
            t2 = cad.line2d(crest_a, crest_b)
            t3 = cad.line2d(crest_b, apex)
            tooth = cad.region(loop=[t1, t2, t3], inside=(-depth_h / 3.0, 0.0))
            turns = length / pitch
            thread_path = cad.helix(radius=nominal / 2.0, pitch=pitch, turns=turns,
                                    axis_origin=(0.0, 0.0, -length))
            tool = cad.sweep("xy", tooth, thread_path, quality=build_quality, export=False)
            screw = cad.bool_difference(screw, tool, quality=build_quality)

        cad.set_color(screw, "#455A64", finish="metallic")
        cad.component_export(screw)

        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("head_top", cad.point(0.0, 0.0, head_h))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"screw_{key.replace('.', '_')}", build,
                          length=length, threads=thread_mode, quality=quality or "std",
                          label=f"{key} x {length:g} cap screw" + (" (real threads)" if real_threads else ""))


# Dimensions per ISO 4032
def hex_nut(cad, thread="M3", quality=None, threads="cosmetic"):
    """An ISO 4032 hex nut. Anchors: bottom (z=0), top. Flats face ±Y.

    threads: "cosmetic" (default) — a smooth bore at the nominal thread Ø, as
             before. "real" — an actual ISO metric 60° V internal thread cut
             into the bore wall the full nut height: the bore is first cut
             narrower, to ≈ nominal − 0.6134·pitch (the minor diameter — the
             crest of an internal thread), then a V tooth (apex pointing
             radially OUTWARD, opposite `cap_screw`'s external tooth) is
             swept along a `cad.helix(...)` at that same bore radius and
             `bool_difference`d out, widening the groove back out to ~nominal
             (the major diameter) — see `_v_thread_region_internal`. Like
             `cap_screw`, `threads="real"` FORCES a high-resolution mesh
             regardless of the `quality` argument — ALWAYS "ultra" (not just
             "high"): the internal thread's crest ridges are a thin annulus
             right at the bore's material/void boundary, and empirically need
             finer dual-contouring cells than an external thread at the same
             pitch to resolve cleanly (a bare "high" cut renders as a broken
             jagged crater instead of a clean spiral — verified 2026-07).
             Thread runout/chamfer is not modeled.
    """
    key = str(thread).upper()
    d = METRIC[key]
    nominal = _nominal(key)
    thread_mode = str(threads).lower()
    real_threads = thread_mode == "real"
    pitch = d["pitch"]
    build_quality = "ultra" if real_threads else quality

    def build():
        depth = _THREAD_DEPTH_FACTOR * pitch
        bore_r = (nominal / 2.0 - depth) if real_threads else nominal / 2.0
        cad.with_sketch("xy")
        outline = _hexagon(cad, d["nut_af"])
        bore = cad.circle2d(cad.point2d(0.0, 0.0), bore_r)
        nut = cad.extrude("xy",
                          cad.region(loop=outline, holes=[[bore]],
                                     inside=(0.0, d["nut_af"] / 2.0 - 0.4)),
                          d["nut_h"], quality=build_quality, export=False)
        if real_threads:
            turns = d["nut_h"] / pitch
            nut = _cut_real_internal_thread(cad, nut, bore_r, pitch, turns,
                                            axis_origin=(0.0, 0.0, 0.0), quality=build_quality)
        cad.set_color(nut, "#455A64", finish="metallic")
        cad.component_export(nut)
        cad.component_export_point("bottom", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, d["nut_h"]))

    return cad.parametric(f"nut_{key.replace('.', '_')}", build,
                          threads=thread_mode, quality=quality or "std",
                          label=f"{key} hex nut" + (" (real threads)" if real_threads else ""))


# Dimensions per ISO 7089
def washer(cad, thread="M3", quality=None):
    """An ISO 7089 flat washer. Anchors: bottom (z=0), top."""
    key = str(thread).upper()
    d = METRIC[key]
    nominal = _nominal(key)

    def build():
        cad.with_sketch("xy")
        outer = cad.circle2d(cad.point2d(0.0, 0.0), d["washer_od"] / 2.0)
        bore = cad.circle2d(cad.point2d(0.0, 0.0), (nominal + 0.3) / 2.0)
        w = cad.extrude("xy",
                        cad.region(loop=[outer], holes=[[bore]],
                                   inside=(0.0, (d["washer_od"] + nominal) / 4.0)),
                        d["washer_t"], quality=quality)
        cad.set_color(w, "#78909C", finish="metallic")
        cad.component_export(w)
        cad.component_export_point("bottom", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, d["washer_t"]))

    return cad.parametric(f"washer_{key.replace('.', '_')}", build,
                          quality=quality or "std",
                          label=f"{key} washer")


# Dimensions per ISO 273 (medium-fit clearance)
def clearance(cad, thread="M3", length=12.0, head_pocket=False, quality=None):
    """NEGATIVE body: an ISO 273 medium-fit clearance volume to subtract.

    Aligns with cap_screw at the same placement: hole down from z=0 to
    -length (plus a small tip margin so the cut always breaks through);
    head_pocket=True adds a counterbore above z=0 sized for the DIN 912
    head. Subtract it from your part:

        cut = cad.instance(c, translate=..., export=False)
        part = cad.bool_difference(part, cut)

    Anchors: under_head (z=0), tip.
    """
    key = str(thread).upper()
    d = METRIC[key]
    length = float(length)
    pocket = bool(head_pocket)

    def build():
        margin = 1.0
        cad.with_sketch("xy")
        hole = cad.circle2d(cad.point2d(0.0, 0.0), d["clear_d"] / 2.0)
        body = cad.extrude("xy",
                           cad.region(loop=[hole], inside=(0.0, 0.0)),
                           length + margin, offset=-(length + margin),
                           quality=quality, export=False)
        parts = [body]
        if pocket:
            cb_r = d["head_d"] / 2.0 + 0.3
            cb_h = d["head_h"] + 0.4
            cb_plane = _plane_at(cad, cb_h + 6.0)
            cad.with_sketch(cb_plane)
            cb = cad.circle2d(cad.point2d(0.0, 0.0), cb_r)
            parts.append(cad.extrude(cb_plane,
                                     cad.region(loop=[cb], inside=(0.0, 0.0)),
                                     cb_h + 6.0, offset=-(cb_h + 6.0),
                                     quality=quality, export=False))
        cut = parts[0] if len(parts) == 1 else cad.bool_union(*parts, quality=quality)
        cad.set_color(cut, "#EF5350", finish="glass")
        cad.component_export(cut)
        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"clear_{key.replace('.', '_')}", build,
                          length=length, pocket=pocket, quality=quality or "std",
                          label=f"{key} clearance hole" + (" w/ pocket" if pocket else ""))


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def tap(cad, thread="M3", length=10.0, quality=None):
    """NEGATIVE body: a tap-drill volume (for threads cut into the part).
    Same orientation as clearance(). Anchors: under_head (z=0), tip."""
    key = str(thread).upper()
    d = METRIC[key]
    length = float(length)

    def build():
        cad.with_sketch("xy")
        hole = cad.circle2d(cad.point2d(0.0, 0.0), d["tap_d"] / 2.0)
        cut = cad.extrude("xy",
                          cad.region(loop=[hole], inside=(0.0, 0.0)),
                          length, offset=-length, quality=quality)
        cad.set_color(cut, "#EF5350", finish="glass")
        cad.component_export(cut)
        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"tap_{key.replace('.', '_')}", build,
                          length=length, quality=quality or "std",
                          label=f"{key} x {length:g} tap drill")

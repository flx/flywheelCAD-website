# flywheelcad standard library
"""Small electronics breakout-board footprints (PCB slab + representative
component blocks). Companion to board_footprints.py (microcontroller boards)
and electronics.py (discrete through-hole hardware).

Five module classes, dimensions per the library-expansion task spec (generic
hobbyist/maker breakout-board classes, not tied to one exact vendor part
number):

    oled_display     "0.96": 27 x 27 x 1.2 mm PCB (0.96in SSD1306 I2C OLED
                     module class), 24 x 14 mm display glass block, 2
                     diagonal Ø2mm mounting holes, a 4-pin header row.
                     "1.3": 35 x 33 x 1.2 mm PCB (1.3in SH1106 module
                     class), 30 x 16 mm display, 4 corner Ø2mm holes.
    relay_module     Generic Songle SRD-05VDC-SL-C style relay breakout:
                     (channels*18 + 6) x 40 x 1.6 mm PCB, one 15x10x15 mm
                     relay can per channel, a control-pin header row, 4
                     corner Ø3mm mounting holes.
    stepper_driver   Pololu-style A4988/DRV8825 stepper driver carrier
                     class: 20 x 15 x 1.6 mm PCB (same footprint for both
                     chip variants), a 9x9x5 mm aluminium-finish heatsink
                     over the driver IC, two 8-pin 2.54mm-pitch header rows
                     along the long edges.
    buck_converter   MP1584EN-class mini buck (step-down) module: 22 x 17
                     x 1.6 mm PCB, a 7x7x4 mm inductor block, a 5x5x4 mm
                     trim-pot block, 4 through-hole I/O pins/pads.
    battery_holder   "18650": (count*19.5 + 3) x 72 x 20 mm case, Ø18.7mm
                     cell cavities cut as open-top troughs. "AA": (count*15
                     + 3) x 56 x 15 mm case, Ø14.5mm cavities. "CR2032": a
                     round Ø25 x 5mm coin holder with a Ø20.5mm recess.

Orientation: every board/case sits on world XY with its bottom face at
z = 0; component blocks (relay cans, headers, heatsinks, inductors, etc.)
protrude +Z from the top face. Every factory's origin is the BOARD/CASE
CENTER (board_footprints.py convention) -- simplest and consistent across
all five factories.

Per the single-exported-body convention used across this library (one
cad.component_export() per factory via cad.bool_union(*parts)), each board is
colored uniformly as PCB green -- EXCEPT stepper_driver, whose aluminium
heatsink is a second export (bool_union does not carry per-input color).
battery_holder is not a PCB, so it is colored as black holder plastic.

Anchor contract:
    oled_display     origin (0,0,0), mount_0.. (2 or 4, per size)
    relay_module     origin (0,0,0), mount_0..3
    stepper_driver   origin (0,0,0), pin_a0
    buck_converter   origin (0,0,0)
    battery_holder   origin (0,0,0)
"""

__library_version__ = "1.0"

import math

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO dropdown.
# So every choice list is spelled out literally here. Continuous numeric
# params (channels, count) stay free-text.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "oled_display": {"size": ["0.96", "1.3"]},
    "stepper_driver": {"kind": ["A4988", "DRV8825"]},
    "battery_holder": {"cell": ["AA", "18650", "CR2032"]},
}

_PCB = "#1B5E20"
_ALUMINIUM = "#CFD8DC"
_HOLDER_PLASTIC = "#212121"


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y).

    Used to give a shape group its OWN sketch page even when several sit at
    the same height: elements sharing one sketch page get intersected/split
    by area detection. A fresh plane per block keeps them independent."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _slab(cad, hw, hd, thickness, holes, hole_r, quality=None):
    """Board slab centered on the origin: rectangle [-hw,hw] x [-hd,hd],
    full thickness 0..thickness, with round through mounting holes at
    `holes` (list of (x, y), board-center-relative), if any. export=False.

    On a FRESH plane at z = 0, for the reason `_block` below already gives:
    two boards in one document have overlapping plan outlines, and on the
    shared "xy" sketch the second one's loops subdivide the first one's
    region, which strands the earlier board on stale geometry."""
    plane = _plane_at(cad, 0.0)
    cad.with_sketch(plane)
    outline = _rect(cad, -hw, -hd, hw, hd)
    if holes:
        hole_circles = [cad.circle2d(cad.point2d(hx, hy), hole_r) for (hx, hy) in holes]
        body_region = cad.region(loop=outline, holes=[[c] for c in hole_circles],
                                 inside=(0.0, 0.0))
    else:
        body_region = cad.region(loop=outline, inside=(0.0, 0.0))
    return cad.extrude(plane, body_region, thickness, quality=quality, export=False)


def _block(cad, cx, cy, z0, w, d, h, quality=None):
    """A box centered at (cx, cy) in XY, spanning z0..z0+h. export=False.
    Uses a FRESH plane (own sketch page) so many blocks at the same height
    never collide during area detection -- including at z = 0, which used to
    fall back to the shared "xy" sketch and undo exactly that."""
    plane = _plane_at(cad, z0)
    cad.with_sketch(plane)
    outline = _rect(cad, cx - w / 2.0, cy - d / 2.0, cx + w / 2.0, cy + d / 2.0)
    return cad.extrude(plane, cad.region(loop=outline, inside=(cx, cy)), h,
                       quality=quality, export=False)


def _revolve_profile(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) profile on ZX about the axis at r = 0.

    on_axis=True: the profile touches r = 0, so the closing edge IS the axis.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


def _trough(cad, cx, r, box_h, wall, half_len, quality, n=8):
    """A D-shaped void (flat top at z=box_h, semicircular bottom of radius r
    centered at z = r + wall) extruded along +Y from -half_len to +half_len
    on the built-in "zx" plane (u=X, v=Z; extrudes along +Y -- the correct
    plane for a cross-section that runs along an insertion axis). Subtract
    this from a box to cut an open-top cylindrical cell cavity. export=False."""
    z_center = r + wall
    pts = [(cx - r, box_h), (cx - r, z_center)]
    for i in range(1, n):
        theta = math.radians(180.0 + 180.0 * i / n)
        pts.append((cx + r * math.cos(theta), z_center + r * math.sin(theta)))
    pts.append((cx + r, z_center))
    pts.append((cx + r, box_h))

    cad.with_sketch("zx")
    p2d = [cad.point2d(x, z) for (x, z) in pts]
    n_pts = len(p2d)
    lines = [cad.line2d(p2d[i], p2d[(i + 1) % n_pts]) for i in range(n_pts)]
    region = cad.region(loop=lines, inside=(cx, box_h - 0.1))
    return cad.extrude("zx", region, half_len * 2.0, offset=-half_len,
                       quality=quality, export=False)


# ---------------------------------------------------------------------------
# 1. OLED display module
# ---------------------------------------------------------------------------

_OLED = {
    "0.96": dict(w=27.0, d=27.0, disp_w=24.0, disp_h=14.0, inset=1.75, n_holes=2),
    "1.3":  dict(w=35.0, d=33.0, disp_w=30.0, disp_h=16.0, inset=2.0,  n_holes=4),
}
_OLED_T = 1.2
_OLED_HOLE_R = 2.0 / 2.0
_OLED_DISPLAY_T = 0.6
_OLED_HEADER_PINS = 4
_OLED_HEADER_D = 2.5
_OLED_HEADER_H = 8.5


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def oled_display(cad, size="0.96", quality=None):
    """A small OLED display breakout module.

    size "0.96": 27 x 27 x 1.2 mm PCB (0.96in SSD1306 I2C OLED module
    class), 24 x 14 mm display glass area (thin black block on top), 2
    diagonal Ø2mm mounting holes inset 1.75mm from the edges.
    size "1.3": 35 x 33 x 1.2 mm PCB (1.3in SH1106 module class), 30 x 16
    mm display, 4 corner Ø2mm holes inset 2.0mm.
    A 4-pin (2.54mm pitch) header row sits along the -Y edge.
    Anchors: origin (0,0,0), mount_0..N (z=0, N = 1 or 3)."""
    key = str(size)
    d = _OLED[key]
    hw, hd = d["w"] / 2.0, d["d"] / 2.0
    inset = d["inset"]
    if d["n_holes"] == 2:
        holes = [(hw - inset, hd - inset), (-(hw - inset), -(hd - inset))]
    else:
        holes = [(hw - inset, hd - inset), (-(hw - inset), hd - inset),
                 (-(hw - inset), -(hd - inset)), (hw - inset, -(hd - inset))]
    header_len = (_OLED_HEADER_PINS - 1) * 2.54

    def build():
        parts = [_slab(cad, hw, hd, _OLED_T, holes, _OLED_HOLE_R, quality=quality)]
        parts.append(_block(cad, 0.0, 0.0, _OLED_T, d["disp_w"], d["disp_h"],
                            _OLED_DISPLAY_T, quality=quality))
        parts.append(_block(cad, 0.0, -(hd - 1.5), _OLED_T, header_len,
                            _OLED_HEADER_D, _OLED_HEADER_H, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric(f"oled_{key.replace('.', '_')}", build,
                          quality=quality or "std", label=f'{key}" OLED display')


# ---------------------------------------------------------------------------
# 2. Relay module
# ---------------------------------------------------------------------------

_RELAY_PITCH = 18.0
_RELAY_MARGIN = 6.0
_RELAY_D = 40.0
_RELAY_T = 1.6
_RELAY_CAN = (15.0, 10.0, 15.0)
_RELAY_HOLE_R = 3.0 / 2.0
_RELAY_HOLE_INSET = 3.0
_RELAY_HEADER_D = 2.5
_RELAY_HEADER_H = 8.5
_RELAY_HEADER_MARGIN = 4.0


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def relay_module(cad, channels=1, quality=None):
    """A multi-channel relay breakout board (generic Songle SRD-05VDC-SL-C
    style class). PCB (channels*18 + 6) x 40 x 1.6 mm, one 15x10x15 mm
    relay can per channel along the +Y edge, a control-pin header row
    along the -Y edge, 4 corner Ø3mm mounting holes inset 3mm.
    Anchors: origin (0,0,0), mount_0..3 (z=0)."""
    n = int(channels)
    W = n * _RELAY_PITCH + _RELAY_MARGIN
    hw, hd = W / 2.0, _RELAY_D / 2.0
    holes = [(hw - _RELAY_HOLE_INSET, hd - _RELAY_HOLE_INSET),
             (-(hw - _RELAY_HOLE_INSET), hd - _RELAY_HOLE_INSET),
             (-(hw - _RELAY_HOLE_INSET), -(hd - _RELAY_HOLE_INSET)),
             (hw - _RELAY_HOLE_INSET, -(hd - _RELAY_HOLE_INSET))]
    can_w, can_d, can_h = _RELAY_CAN
    header_len = W - 2.0 * _RELAY_HEADER_MARGIN

    def build():
        parts = [_slab(cad, hw, hd, _RELAY_T, holes, _RELAY_HOLE_R, quality=quality)]
        for i in range(n):
            cx = (i - (n - 1) / 2.0) * _RELAY_PITCH
            cy = hd - 3.0 - can_d / 2.0
            parts.append(_block(cad, cx, cy, _RELAY_T, can_w, can_d, can_h,
                                quality=quality))
        parts.append(_block(cad, 0.0, -(hd - 1.5), _RELAY_T, header_len,
                            _RELAY_HEADER_D, _RELAY_HEADER_H, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric(f"relay_{n}ch", build, channels=n,
                          quality=quality or "std", label=f"{n}-channel relay module")


# ---------------------------------------------------------------------------
# 3. Stepper driver carrier
# ---------------------------------------------------------------------------

_STEP_W, _STEP_D, _STEP_T = 20.0, 15.0, 1.6
_STEP_HEATSINK = (9.0, 9.0, 5.0)
_STEP_PINS = 8
_STEP_PITCH = 2.54
_STEP_HEADER_D = 2.5
_STEP_HEADER_H = 8.5


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def stepper_driver(cad, kind="A4988", quality=None):
    """An A4988/DRV8825-class stepper driver carrier board (Pololu-style
    footprint, same board size for both chip variants). PCB 20 x 15 x
    1.6 mm, a 9x9x5 mm aluminium-finish heatsink over the driver chip, two
    8-pin 2.54mm-pitch header rows along the long edges (span 17.78mm).
    Two exports: the PCB+headers (PCB green) and the heatsink (aluminium),
    since bool_union does not carry per-input color.
    Anchors: origin (0,0,0), pin_a0 (first pin, +Y row, z = board top)."""
    kind = str(kind)
    hw, hd = _STEP_W / 2.0, _STEP_D / 2.0
    span = (_STEP_PINS - 1) * _STEP_PITCH
    row_y = hd - 1.5

    def build():
        parts = [_slab(cad, hw, hd, _STEP_T, None, 0.0, quality=quality)]
        parts.append(_block(cad, 0.0, row_y, _STEP_T, span, _STEP_HEADER_D,
                            _STEP_HEADER_H, quality=quality))
        parts.append(_block(cad, 0.0, -row_y, _STEP_T, span, _STEP_HEADER_D,
                            _STEP_HEADER_H, quality=quality))
        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)

        hs_w, hs_d, hs_h = _STEP_HEATSINK
        heatsink = _block(cad, 0.0, 0.0, _STEP_T, hs_w, hs_d, hs_h, quality=quality)
        cad.set_color(heatsink, _ALUMINIUM, finish="metallic")
        cad.component_export(heatsink)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("pin_a0", cad.point(-span / 2.0, row_y, _STEP_T))

    return cad.parametric(f"stepdrv_{kind.lower()}", build, kind=kind,
                          quality=quality or "std", label=f"{kind} stepper driver")


# ---------------------------------------------------------------------------
# 4. Buck converter module
# ---------------------------------------------------------------------------

_BUCK_W, _BUCK_D, _BUCK_T = 22.0, 17.0, 1.6
_BUCK_INDUCTOR = (7.0, 7.0, 4.0)
_BUCK_POT = (5.0, 5.0, 4.0)
_BUCK_PIN_S = 1.0
_BUCK_PIN_INSET = 2.0
_BUCK_PIN_BELOW = 1.0
_BUCK_PIN_ABOVE = 1.0


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def buck_converter(cad, quality=None):
    """A mini buck (step-down) converter module (MP1584EN-class). PCB
    22 x 17 x 1.6 mm, a 7x7x4 mm inductor block, a 5x5x4 mm trim-pot
    block, 4 corner through-hole I/O pins/pads (inset 2mm, protrude both
    sides of the board). Anchors: origin (0,0,0)."""
    hw, hd = _BUCK_W / 2.0, _BUCK_D / 2.0
    ind_w, ind_d, ind_h = _BUCK_INDUCTOR
    pot_w, pot_d, pot_h = _BUCK_POT
    pin_z0 = -_BUCK_PIN_BELOW
    pin_h = _BUCK_T + _BUCK_PIN_BELOW + _BUCK_PIN_ABOVE
    pin_xy = [(hw - _BUCK_PIN_INSET, hd - _BUCK_PIN_INSET),
              (-(hw - _BUCK_PIN_INSET), hd - _BUCK_PIN_INSET),
              (-(hw - _BUCK_PIN_INSET), -(hd - _BUCK_PIN_INSET)),
              (hw - _BUCK_PIN_INSET, -(hd - _BUCK_PIN_INSET))]

    def build():
        parts = [_slab(cad, hw, hd, _BUCK_T, None, 0.0, quality=quality)]
        parts.append(_block(cad, -6.0, 2.0, _BUCK_T, ind_w, ind_d, ind_h,
                            quality=quality))
        parts.append(_block(cad, 6.0, -2.0, _BUCK_T, pot_w, pot_d, pot_h,
                            quality=quality))
        for (px, py) in pin_xy:
            parts.append(_block(cad, px, py, pin_z0, _BUCK_PIN_S, _BUCK_PIN_S,
                                pin_h, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("buck_converter", build, quality=quality or "std",
                          label="Buck converter module")


# ---------------------------------------------------------------------------
# 5. Battery holder
# ---------------------------------------------------------------------------

_BATT_BOX = {
    "18650": dict(pitch=19.5, margin=3.0, d=72.0, h=20.0, cell_r=18.7 / 2.0),
    "AA":    dict(pitch=15.0, margin=3.0, d=56.0, h=15.0, cell_r=14.5 / 2.0),
}
_BATT_WALL = 1.0
_BATT_END_WALL = 3.0

_CR2032_R = 25.0 / 2.0
_CR2032_H = 5.0
_CR2032_RECESS_R = 20.5 / 2.0
_CR2032_RECESS_DEPTH = 3.0


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def battery_holder(cad, cell="18650", count=1, quality=None):
    """A battery holder. cell "18650": box (count*19.5 + 3) x 72 x 20 mm
    with `count` Ø18.7mm cell cavities, each an open-top trough (D-shaped
    cross-section on the built-in "zx" plane, extruded along +Y) leaving a
    1mm bottom wall and 3mm end walls. cell "AA": box (count*15 + 3) x 56
    x 15 mm, Ø14.5mm cavities, same wall convention. cell "CR2032": a round
    Ø25 x 5mm coin holder with a Ø20.5mm x 3mm-deep recess on top (a single
    revolve profile, no count). Anchors: origin (0,0,0)."""
    key = str(cell).upper() if str(cell).upper() == "CR2032" else str(cell)
    n = int(count)

    def build():
        if key == "CR2032":
            r, h = _CR2032_R, _CR2032_H
            rr, rd = _CR2032_RECESS_R, _CR2032_RECESS_DEPTH
            floor_z = h - rd
            holder = _revolve_profile(cad, [
                (0.0, 0.0), (r, 0.0), (r, h), (rr, h), (rr, floor_z), (0.0, floor_z),
            ], inside=(r / 2.0, floor_z / 2.0), quality=quality)
        else:
            d = _BATT_BOX[key]
            W = n * d["pitch"] + d["margin"]
            hw, hd = W / 2.0, d["d"] / 2.0
            box = _slab(cad, hw, hd, d["h"], None, 0.0, quality=quality)
            half_len = hd - _BATT_END_WALL
            troughs = [_trough(cad, (i - (n - 1) / 2.0) * d["pitch"], d["cell_r"],
                               d["h"], _BATT_WALL, half_len, quality)
                      for i in range(n)]
            holder = cad.bool_difference(box, *troughs, quality=quality)

        cad.set_color(holder, _HOLDER_PLASTIC, finish="matte")
        cad.component_export(holder)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    label = f"{key} coin cell holder" if key == "CR2032" else f"{n}x {key} battery holder"
    return cad.parametric(f"batt_{key.lower().replace('.', '_')}", build,
                          count=n, quality=quality or "std", label=label)

# Camera gimbal — build notes

A pan / tilt / roll camera head for a Canon EOS R6 Mark III class body: three
large-class hobby servos, six printed structural parts, a Raspberry Pi 4B with
a servo HAT on the base, and a 1/4"-20 screw into the camera's tripod socket.

**What this is, and is not.** With ~1.4 kg of camera on it this is a *framing*
head — slow pans, tilts and holds, driven from the Pi. It is not a stabiliser.
Stabilisation needs direct-drive BLDC gimbal motors and an IMU closing the loop
at hundreds of hertz; hobby servos have gear backlash of a degree or so and a
step response measured in tenths of a second. Nothing in this design gets you
past that, and no amount of printing will.

## The camera is a box on purpose

The camera is a transparent box with a transparent cylinder for the lens, and
that is the *right* level of detail. Four things about the camera matter to
this design and none of them is its shape:

| | Value used |
|---|---|
| body envelope | 138.4 × 88.4 × 98.4 mm |
| body mass | ~700 g |
| optical axis above the body base | 48 mm |
| lens envelope / mass | Ø83.5 × 107.3 mm, ~700 g (RF 24-105 f/4) |
| tripod socket | 1/4"-20 UNC, on the lens axis, 10 mm forward of the body centre |

A faithful model of an R6 would add nothing to any of those and would swamp
the parts you actually print. The one piece of camera hardware that IS modelled
properly is the mount screw, because a 1/4"-20 is the only interface between
this design and the camera — and the standard library is metric only, so this
file cuts a real 20-TPI helical thread for it (a 60° V tooth swept along a
`cad.helix` and differenced out of the shank).

## Balance is the design

Combined CG = `LENS_MASS × (CAM_D/2 + LENS_L/2) / (CAM_MASS + LENS_MASS)` ≈
**47 mm forward of the body centre**, on the optical axis. That single number
drives the whole model:

- The camera is mounted **47 mm back** from the pitch axis, so the CG — not the
  camera — is what the axis passes through.
- **Pitch** runs through the CG in both axes it can: z = 144 (the optical axis
  height) and y = 0.
- **Yaw** runs vertically through the CG at x = 0, y = 0.
- **Roll** runs along y at z = 222, *above* the camera.

Change the lens and the CG moves. The adjustment is the **fore/aft slot** the
camera screw runs in — 30 mm of travel, which covers roughly a 24-105 through
a 70-200 on this body. Slide the camera until the tilt axis is neutral, then
tighten. If you need more than 30 mm, widen `SLOT_TRAVEL`.

## What the servos actually carry

| Axis | Static load | Notes |
|---|---|---|
| **Pitch** | ≈ 0 when balanced | The servo fights friction and acceleration only — which is why the slot matters more than the servo does |
| **Roll** | m·g·d·sin θ with d = 78 mm | The load hangs *below* the roll axis, so the assembly is a pendulum: self-centring at level, and about **7 kg·cm at 30° of roll** for ~1.8 kg. An HS-805BB gives ~24.7 kg·cm at 6 V, so roughly 28 % of stall — fine to hold, hot if you hold it all day |
| **Yaw** | no gravity torque | The axis is through the CG, so yaw only fights inertia and friction |

**The known weak point is the yaw axis.** There is no bearing on it: the full
~2.5 kg of head and camera goes through the servo's output shaft and its
gearbox, as both an axial load and an overturning moment. That is what most
hobby pan-tilt heads do at this size, and it is the first thing to upgrade —
a turntable bearing between the deck and the yaw plate, on a riser ring that
clears the horn (the horn disc is Ø44 and sits 6.5 mm above the spline, so the
ring needs to stand off ~17 mm). The roll axis is cantilevered off its servo
for the same reason and deserves the same treatment second.

## What is editable, and where

| You want to change | Do it |
|---|---|
| plate sizes, mast height and thickness, bridge and arm dimensions, slot width | **In the app** — every printed part is drawn at module level from a constrained sketch (`V_FOOT_S`, `V_DECK_S`, `V_YAWPLATE_W/D/T`, `V_MAST_H/T`, `V_BRIDGE_W/T`, `V_CRADLE_W/D/T`, `V_UPRIGHT_H`, `V_YOKE_H`, `V_SLOT_R`) |
| camera body, lens, masses, the Z stack | **In `main.py`** — change `CAM_*` / `LENS_*` and the CG offset and every part that hangs off it recomputes |

## Three placement traps worth knowing

**1. A servo's spline is not on its case centre.** For the large class it sits
18 mm toward the case's +x end. Every servo here is therefore positioned by
where its *spline* has to land, not by where its case looks tidy — and the
deck's cutout and flange holes are offset to match. Place the yaw servo at
x = 0 and the whole head pans about a point 18 mm off the CG.

**2. A plane's sketch axes come from its normal.** The mast, the two roll
uprights and the two yoke arms are all drawn on planes normal to X, whose
frame works out as u = −Y, v = +Z. Written as if it were (x, z), the mast
extrudes to x = −120 instead of straddling the centreline.

**3. A disc horn cannot bolt to a 12 mm edge.** The roll servo's output is a
disc in a plane normal to y, so the roll frame carries a real back plate for
it. The bridge alone would have given the horn a plate edge to bolt to.

## Bill of materials

| Qty | Part | |
|----:|------|---|
| 3 | large-class hobby servo (HS-805BB class) | *library* |
| 3 | disc horn, large spline | *library* |
| 1 | 608 bearing (pitch idler side) | *library* |
| 1 | Raspberry Pi 4B + servo HAT + 4 PCB standoffs | *library* |
| 1 | buck converter + 3-cell 18650 holder + rocker switch + USB-C | *library* |
| 1 | 1/4-20 tripod mount (the head's own tripod interface) | *library* |
| 4 | M3 standoff, 40 mm, female-female | *library* |
| ~24 | M3 × 10 cap screw + M3 heat-set insert | *library* |
| 2 | cable clip | *library* |
| 1 | 1/4"-20 × 12 camera screw | drawn here, real thread |
| 6 | printed parts: base plate, deck plate, yaw plate, mast, roll frame, pitch yoke | drawn here |

## Assembly order

1. Heat-set inserts into all six printed parts before anything else.
2. Tripod mount under the base plate; Pi, HAT, buck, battery and switch on top.
3. Four standoffs up to the deck plate; yaw servo into the deck cutout,
   flange screws from above, case hanging into the gap.
4. Disc horn onto the yaw spline, yaw plate onto the horn.
5. Mast onto the yaw plate — it bolts down into two inserts. Roll servo onto
   the mast's *back* face, spline forward through the mast's bore.
6. Roll frame's back plate onto the roll horn.
7. Pitch servo onto the outside of the right roll upright, 608 into the left.
8. Pitch yoke between them — horn onto the servo, bearing onto the left stub.
9. Camera screw up through the slot into the camera. **Balance before you
   power anything**: with the servos unpowered the camera should sit level at
   any tilt angle. If it does not, slide it in the slot until it does.

## Notes on the model

- **Mesh:** the plates come out on the sampled mesher rather than the exact
  one, because each has small holes close to a large thin plate's edge. That
  costs triangles, not accuracy — the base plate's mesh volume agrees with the
  analytic figure to 0.002 %, so every hole is present. A default-quality
  render of the whole head takes about 5 seconds.
- The 1/4"-20 screw carries its own `quality="high"`: a 1.27 mm thread pitch
  is below one cell at the document default, and a real thread that meshes as
  a smooth cylinder is worse than no thread at all.

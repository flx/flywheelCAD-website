# flywheelcad-format: 1
# =============================================================================
# CAMERA GIMBAL — 3-axis servo head for a Canon EOS R6 Mark III class body
# =============================================================================
# A pan / tilt / roll camera head: three large-class hobby servos, six printed
# structural parts, a Raspberry Pi 4B and its servo HAT on the base, and the
# camera itself represented — deliberately — as nothing more than a transparent
# box with a transparent cylinder for the lens.
#
# The camera is NOT modelled. What matters about it here is its envelope, its
# mass, where its centre of gravity sits, and where its 1/4"-20 tripod socket
# is; a faithful model of an R6 would add nothing to any of those and would
# swamp the parts you actually print. The one piece of camera hardware that IS
# modelled properly is the mount screw, because a 1/4"-20 UNC is the single
# interface between this design and the camera, and the standard library is
# metric-only — so this file cuts a real 20-TPI helical thread for it.
#
# ---------------------------------------------------------------------------
# THE BALANCE PROBLEM, WHICH IS THE WHOLE DESIGN
# ---------------------------------------------------------------------------
# Body 138.4 x 98.4 x 88.4 mm and ~700 g; an RF 24-105 f/4 adds ~700 g out in
# front. The combined centre of gravity therefore sits about 47 mm FORWARD of
# the body centre and about 48 mm above the baseplate — on the optical axis.
#
# So the camera is deliberately mounted 47 mm back from the pitch axis: the
# whole point is that the CG, not the camera, is what the axes pass through.
#   * PITCH runs through the CG in both axes it can (z = 144, y = 0).
#   * YAW runs vertically through the CG (x = 0, y = 0).
#   * ROLL does NOT. It runs along y at z = 222, above the camera, because
#     putting it through the CG would mean a frame that reaches around the
#     body from both sides. That is a real trade and the roll servo pays for
#     it in static holding torque — see BUILD_NOTES.md.
#
# With ~1.4 kg on it this is a FRAMING head — slow pans and holds — not a
# stabiliser. A stabiliser needs direct-drive BLDC gimbal motors and an IMU;
# hobby servos have too much backlash and too little bandwidth.
#
# ---------------------------------------------------------------------------
# HOW TO CHANGE THIS DESIGN
# ---------------------------------------------------------------------------
#   IN THE APP   — every printed part is drawn at module level from a
#                  constrained sketch whose dimensions are bound to driving
#                  variables, so the Variables panel edits real geometry.
#   IN THIS FILE — the camera envelope and the Z stack. Change `CAM_W/D/H`,
#                  `CAM_MASS`, `LENS_*` for a different body and lens and the
#                  CG offset, and everything that hangs off it, recomputes.
#
# ---------------------------------------------------------------------------
# BILL OF MATERIALS
# ---------------------------------------------------------------------------
#    3x  large-class hobby servo (HS-805BB class) + 3x horn   [library parts]
#    1x  608 bearing (the pitch axis idler side)              [library part]
#    1x  Raspberry Pi 4B + servo HAT + 4x PCB standoff        [library parts]
#    1x  buck converter + 1x 3-cell 18650 holder + 1x switch  [library parts]
#    1x  USB-C socket (Pi power passthrough) + 2x cable clip  [library parts]
#    1x  1/4-20 tripod mount (the head's own tripod interface) [library part]
#    4x  M3 standoff 40 mm, female-female                     [library part]
#  ~14x  M3 x 10 cap screw + 2x M3 heat-set insert           [library parts]
#    1x  1/4"-20 x 12 camera screw (drawn here, real thread)
#    6x  printed structural parts (drawn here)
# =============================================================================
from flywheelcad import *

cad = FlywheelCAD()

import math

from lib.standard.servos import servo, horn
from lib.standard.bearings import bearing
from lib.standard.board_footprints import raspberry_pi, pcb_standoff
from lib.standard.electronics_more import rpi_hat
from lib.standard.modules import buck_converter, battery_holder
from lib.standard.switches import rocker_switch
from lib.standard.connectors import usb
from lib.standard.mounts import tripod_mount, cable_clip
from lib.standard.fasteners import cap_screw
from lib.standard.fasteners_more import heatset_insert, standoff

# =============================================================================
# PARAMETER BLOCK
# =============================================================================

# ---- the camera, as an envelope and a mass -----------------------------------
CAM_W, CAM_D, CAM_H = 138.4, 88.4, 98.4    # Canon R6-series body envelope
CAM_MASS = 700.0                            # g, body with card and battery
OPTICAL_Z = 48.0                            # optical axis above the body base
SOCKET_FWD = 10.0                           # 1/4"-20 socket, fwd of body centre
LENS_D, LENS_L = 83.5, 107.3                # RF 24-105 f/4 envelope
LENS_MASS = 700.0                           # g

# Where the combined CG sits, measured forward of the BODY centre. Everything
# below hangs off this one number — it is why the camera sits back from the
# pitch axis rather than on it.
CG_FWD = (LENS_MASS * (CAM_D / 2.0 + LENS_L / 2.0)) / (CAM_MASS + LENS_MASS)

# ---- the Z stack ------------------------------------------------------------
FOOT_T = 8.0                # base plate: electronics + tripod interface
Z_FOOT = 0.0
STANDOFF_L = 40.0
Z_DECK = Z_FOOT + FOOT_T + STANDOFF_L       # 48 — deck plate underside
DECK_T = 8.0
Z_SERVO_FLANGE = Z_DECK + DECK_T            # 56 — yaw servo flange sits here
SERVO_SPLINE_UP = 20.0                      # large servo: spline top above flange
HORN_HUB_H = 6.5                            # large horn hub height
Z_YAWPLATE = Z_SERVO_FLANGE + SERVO_SPLINE_UP + HORN_HUB_H   # 82.5
YAWPLATE_T = 6.0
Z_CRADLE = 90.0             # yoke cradle plate underside
CRADLE_T = 6.0
Z_CAM = Z_CRADLE + CRADLE_T                 # 96 — camera base sits here
Z_PITCH = Z_CAM + OPTICAL_Z                 # 144 — pitch axis on the optical axis
Z_ROLL = 222.0              # roll axis, above the camera (see the note above)
Z_MAST_TOP = 233.0

# ---- plan dimensions --------------------------------------------------------
FOOT_S = 180.0              # base plate, square
DECK_S = 140.0              # deck plate, square
YAWPLATE_W = 140.0          # x
YAWPLATE_D = 170.0          # y, reaching back to the mast
Y_MAST_BACK = -134.0        # mast back face: the roll servo bolts here
MAST_T = 16.0
Y_MAST = Y_MAST_BACK + MAST_T               # -118, mast front face
MAST_W = 80.0
SERVO_SPLINE_OFF = 18.0     # large servo: the output spline is offset from the
                            # case centre by (body_l - body_w)/2. Every servo
                            # below is therefore placed by where its SPLINE has
                            # to land, not by where its case looks tidy.
CRADLE_W = 200.0            # x
CRADLE_D = 110.0            # y
X_YOKE_IN, X_YOKE_OUT = 78.0, 90.0          # pitch yoke arm, inner/outer x
X_ROLL_IN, X_ROLL_OUT = 96.0, 110.0         # roll frame upright, inner/outer x
ARM_D = 60.0                # both arms are this deep in y, centred on y = 0
BRIDGE_T = 12.0
BRIDGE_W = 220.0            # x
Y_BRIDGE_BACK = Y_MAST_BACK + SERVO_SPLINE_UP + HORN_HUB_H      # -107.5
BACKPLATE_T = 8.0
SLOT_R = 3.6                # 1/4" clearance; the slot is 30 mm of travel
SLOT_TRAVEL = 30.0

M3_CLEAR_R = 1.7
M3_INSERT_R = 2.1

# ---- the camera screw (drawn here — the library is metric only) -------------
UNC_D = 6.35                # 1/4" major diameter
UNC_PITCH = 25.4 / 20.0     # 20 TPI = 1.27 mm
UNC_ENGAGE = 6.0            # thread length into the camera's socket
SCREW_HEAD_D = 16.0
SCREW_HEAD_T = 5.0
THREAD_DEPTH_FACTOR = 0.6134                # ISO/UNC 60 deg V, h3 = 17H/24

COL_PRINT = "#00838F"
COL_PRINT_ALT = "#00695C"
COL_GLASS = "#90A4AE55"
COL_SCREW = "#B0BEC5"


# =============================================================================
# HELPERS
# =============================================================================
def _plane_at(z, name):
    """A sketch plane parallel to XY at height z (frame u = +X, v = +Y)."""
    return cad.create_sketch_plane(cad.point(0.0, 0.0, z),
                                   cad.point(1.0, 0.0, z),
                                   cad.point(0.0, 1.0, z), name=name)


def _plane_x(x, name):
    """A sketch plane normal to X at `x`. Its frame comes from the normal:
    u = -Y, v = +Z. Sketch (u, v) is therefore (-y, z)."""
    return cad.create_sketch_plane(cad.point(x, 0.0, 0.0),
                                   cad.point(x, 0.0, 1.0),
                                   cad.point(x, 1.0, 0.0), name=name)


def _rect(x0, y0, x1, y1):
    """Four sketch lines round an axis-aligned rectangle, in sketch coords."""
    p = [cad.point2d(x0, y0), cad.point2d(x1, y0),
         cad.point2d(x1, y1), cad.point2d(x0, y1)]
    return p, [cad.line2d(p[i], p[(i + 1) % 4]) for i in range(4)]


def _square_holes(cx, cy, half_x, half_y, r):
    """Four hole loops on a rectangular bolt pattern."""
    return [[cad.circle2d(cad.point2d(cx + sx * half_x, cy + sy * half_y), r)]
            for (sx, sy) in ((1, 1), (-1, 1), (-1, -1), (1, -1))]


# =============================================================================
# BASE PLATE — the head's foot. Carries the tripod interface underneath, the
# Raspberry Pi and its power on top, and four standoffs up to the deck.
# =============================================================================
V_FOOT_S = cad.variable(FOOT_S, driving=True)
V_FOOT_T = cad.variable(FOOT_T, driving=True)

foot_plane = _plane_at(Z_FOOT, "foot_face")
cad.with_sketch(foot_plane)
fh = FOOT_S / 2.0
foot_pts, foot_lines = _rect(-fh, -fh, fh, fh)
cad.horizontal(line=foot_lines[0])
cad.parallel(line1=foot_lines[2], line2=foot_lines[0])
cad.vertical(line=foot_lines[1])
cad.perpendicular(line1=foot_lines[3], line2=foot_lines[0])
cad.distance(foot_pts[0], foot_pts[1], V_FOOT_S)     # it is a SQUARE plate:
cad.equal_lines(line1=foot_lines[0], line2=foot_lines[1])   # one dimension only

tripod_c = cad.point2d(0.0, 0.0)
tripod_bore = cad.circle2d(tripod_c, 6.6)            # 1/4" clearance
cad.coincident(p0=tripod_c, p1=origin_foot_face)
cad.radius(circle=tripod_bore, radius=6.6)
foot_holes = [[tripod_bore]]
foot_holes += _square_holes(0.0, 0.0, DECK_S / 2.0 - 12.0, DECK_S / 2.0 - 12.0,
                            M3_CLEAR_R)
cad.ensure_convergence()

base_plate = cad.extrude(foot_plane,
                         cad.region(loop=foot_lines, holes=foot_holes,
                                    inside=(fh - 8.0, fh - 8.0)),
                         V_FOOT_T)
cad.set_color("base_plate", COL_PRINT, finish="matte")

# A servo's output spline is not on its case centre — it sits one
# SERVO_SPLINE_OFF toward the case's +x end. Every servo in this file is
# therefore positioned by where its SPLINE has to land, and the case falls
# where it falls; the yaw servo's case centre is here.
X_YAW_SERVO = -SERVO_SPLINE_OFF

# =============================================================================
# DECK PLATE — carries the yaw servo. Its case hangs through the cutout into
# the space between the two plates, which is why the standoffs are 40 mm.
# =============================================================================
V_DECK_S = cad.variable(DECK_S, driving=True)
V_DECK_T = cad.variable(DECK_T, driving=True)

deck_plane = _plane_at(Z_DECK, "deck_face")
cad.with_sketch(deck_plane)
dh = DECK_S / 2.0
deck_pts, deck_lines = _rect(-dh, -dh, dh, dh)
cad.horizontal(line=deck_lines[0])
cad.parallel(line1=deck_lines[2], line2=deck_lines[0])
cad.vertical(line=deck_lines[1])
cad.perpendicular(line1=deck_lines[3], line2=deck_lines[0])
cad.distance(deck_pts[0], deck_pts[1], V_DECK_S)
cad.equal_lines(line1=deck_lines[0], line2=deck_lines[1])

# Servo body cutout: the large case is 66 x 30, plus a fitting clearance. It
# is centred on the CASE, which is one spline-offset to the -x of the yaw axis.
cut_pts, cut_lines = _rect(X_YAW_SERVO - 34.0, -16.0, X_YAW_SERVO + 34.0, 16.0)
deck_holes = [cut_lines]
# The four servo flange screws (large class: +-37.45, +-8.9) …
deck_holes += _square_holes(X_YAW_SERVO, 0.0, 37.45, 8.9, M3_CLEAR_R)
# … and the standoffs coming up from the base plate.
deck_holes += _square_holes(0.0, 0.0, DECK_S / 2.0 - 12.0, DECK_S / 2.0 - 12.0,
                            M3_CLEAR_R)
cad.ensure_convergence()

deck_plate = cad.extrude(deck_plane,
                         cad.region(loop=deck_lines, holes=deck_holes,
                                    inside=(dh - 6.0, 0.0)),
                         V_DECK_T)
cad.set_color("deck_plate", COL_PRINT_ALT, finish="matte")

# =============================================================================
# YAW PLATE — rides on the yaw servo's horn and carries the mast. Long in y
# because the mast has to stand clear behind the camera.
# =============================================================================
V_YAWPLATE_W = cad.variable(YAWPLATE_W, driving=True)
V_YAWPLATE_D = cad.variable(YAWPLATE_D, driving=True)
V_YAWPLATE_T = cad.variable(YAWPLATE_T, driving=True)

Y_YAW_BACK = Y_MAST_BACK - 4.0                      # -138
Y_YAW_FRONT = Y_YAW_BACK + YAWPLATE_D               # 36
yaw_plane = _plane_at(Z_YAWPLATE, "yawplate_face")
cad.with_sketch(yaw_plane)
yh = YAWPLATE_W / 2.0
yaw_pts, yaw_lines = _rect(-yh, Y_YAW_BACK, yh, Y_YAW_FRONT)
cad.horizontal(line=yaw_lines[0])
cad.parallel(line1=yaw_lines[2], line2=yaw_lines[0])
cad.vertical(line=yaw_lines[1])
cad.perpendicular(line1=yaw_lines[3], line2=yaw_lines[0])
cad.distance(yaw_pts[0], yaw_pts[1], V_YAWPLATE_W)
cad.distance(yaw_pts[1], yaw_pts[2], V_YAWPLATE_D)

# Horn bolt circle on the yaw axis, plus the mast's fixing holes.
yaw_holes = _square_holes(0.0, 0.0, 12.0, 12.0, M3_CLEAR_R)
yaw_holes += _square_holes(0.0, Y_MAST_BACK + MAST_T / 2.0, MAST_W / 2.0 - 10.0,
                           4.0, M3_INSERT_R)
cad.ensure_convergence()

yaw_plate = cad.extrude(yaw_plane,
                        cad.region(loop=yaw_lines, holes=yaw_holes,
                                   inside=(yh - 8.0, Y_YAW_FRONT - 8.0)),
                        V_YAWPLATE_T)
cad.set_color("yaw_plate", COL_PRINT, finish="matte")

# =============================================================================
# MAST — the single upright behind the camera. Drawn on a plane normal to X so
# its side profile is what you dimension, which is how you would draw it: a
# tall rectangle with the roll-servo interface near the top.
# =============================================================================
V_MAST_H = cad.variable(Z_MAST_TOP - (Z_YAWPLATE + YAWPLATE_T), driving=True)
V_MAST_T = cad.variable(MAST_T, driving=True)

# The plane's normal is -X, so a positive extrude runs -X: start at +MAST_W/2
# and the mast fills -40 … +40 rather than marching off to -120.
mast_plane = _plane_x(MAST_W / 2.0, "mast_face")
cad.with_sketch(mast_plane)
# Sketch (u, v) = (-y, z) on this plane, so a y of -118 is a u of +118.
MU0, MU1 = -Y_MAST, -Y_MAST_BACK                    # 118 … 134
MV0, MV1 = Z_YAWPLATE + YAWPLATE_T, Z_MAST_TOP      # 88.5 … 233
mast_pts, mast_lines = _rect(MU0, MV0, MU1, MV1)
cad.horizontal(line=mast_lines[0])
cad.parallel(line1=mast_lines[2], line2=mast_lines[0])
cad.vertical(line=mast_lines[1])
cad.perpendicular(line1=mast_lines[3], line2=mast_lines[0])
cad.distance(mast_pts[0], mast_pts[1], V_MAST_T)
cad.distance(mast_pts[1], mast_pts[2], V_MAST_H)
cad.ensure_convergence()

mast_blank = cad.extrude(mast_plane,
                         cad.region(loop=mast_lines, inside=(MU0 + 4.0, MV0 + 20.0)),
                         MAST_W, export=False)

# The roll servo lives on the mast's BACK face and reaches through it, so the
# mast needs a clearance bore on the roll axis.
bore_plane = cad.create_sketch_plane(cad.point(0.0, Y_MAST_BACK - 2.0, 0.0),
                                     cad.point(0.0, Y_MAST_BACK - 2.0, 1.0),
                                     cad.point(1.0, Y_MAST_BACK - 2.0, 0.0),
                                     name="mast_bore_face")
cad.with_sketch(bore_plane)
mast_bore = cad.circle2d(cad.point2d(0.0, Z_ROLL), 15.0)
spline_bore = cad.extrude(bore_plane,
                          cad.region(loop=[mast_bore], inside=(0.0, Z_ROLL)),
                          MAST_T + 4.0, export=False)
mast = cad.bool_difference(mast_blank, spline_bore)
cad.set_color("mast", COL_PRINT_ALT, finish="matte")

# =============================================================================
# ROLL FRAME — one printed part: a bridge over the camera plus two uprights
# down to the pitch pivots. The bridge is the body that rotates about the roll
# axis; the uprights carry the pitch servo on one side and its idler bearing
# on the other.
# =============================================================================
V_BRIDGE_W = cad.variable(BRIDGE_W, driving=True)
V_BRIDGE_T = cad.variable(BRIDGE_T, driving=True)

bridge_plane = _plane_at(Z_ROLL - BRIDGE_T / 2.0, "bridge_face")
cad.with_sketch(bridge_plane)
bh = BRIDGE_W / 2.0
Y_BRIDGE_FRONT = ARM_D / 2.0
br_pts, br_lines = _rect(-bh, Y_BRIDGE_BACK, bh, Y_BRIDGE_FRONT)
cad.horizontal(line=br_lines[0])
cad.parallel(line1=br_lines[2], line2=br_lines[0])
cad.vertical(line=br_lines[1])
cad.perpendicular(line1=br_lines[3], line2=br_lines[0])
cad.distance(br_pts[0], br_pts[1], V_BRIDGE_W)
cad.ensure_convergence()

bridge = cad.extrude(bridge_plane,
                     cad.region(loop=br_lines,
                                inside=(bh - 8.0, Y_BRIDGE_FRONT - 8.0)),
                     V_BRIDGE_T, export=False)

# The roll horn is a disc in a plane normal to y, so it cannot bolt to the
# bridge's 12 mm edge — the frame needs a real back plate to take it.
back_plane = cad.create_sketch_plane(cad.point(0.0, Y_BRIDGE_BACK, 0.0),
                                     cad.point(0.0, Y_BRIDGE_BACK, 1.0),
                                     cad.point(1.0, Y_BRIDGE_BACK, 0.0),
                                     name="backplate_face")
cad.with_sketch(back_plane)
bp_pts, bp_lines = _rect(-40.0, Z_ROLL - 22.0, 40.0, Z_ROLL + 22.0)
cad.horizontal(line=bp_lines[0])
cad.parallel(line1=bp_lines[2], line2=bp_lines[0])
cad.vertical(line=bp_lines[1])
cad.perpendicular(line1=bp_lines[3], line2=bp_lines[0])
bp_holes = _square_holes(0.0, Z_ROLL, 12.0, 12.0, M3_CLEAR_R)
cad.ensure_convergence()
# This plane's normal is +y, so a positive extrude runs FORWARD from the
# horn's face into the frame — which is the side the plate belongs on.
back_plate = cad.extrude(back_plane,
                         cad.region(loop=bp_lines, holes=bp_holes,
                                    inside=(30.0, Z_ROLL)),
                         BACKPLATE_T, export=False)

# The two uprights, each drawn on its own X-normal plane so its side profile
# is real dimensioned geometry rather than a computed box.
V_UPRIGHT_H = cad.variable(Z_ROLL - BRIDGE_T / 2.0 - Z_PITCH, driving=True)

up_r_plane = _plane_x(X_ROLL_IN, "upright_r_face")
cad.with_sketch(up_r_plane)
ur_pts, ur_lines = _rect(-ARM_D / 2.0, Z_PITCH, ARM_D / 2.0,
                         Z_ROLL - BRIDGE_T / 2.0)
cad.horizontal(line=ur_lines[0])
cad.parallel(line1=ur_lines[2], line2=ur_lines[0])
cad.vertical(line=ur_lines[1])
cad.perpendicular(line1=ur_lines[3], line2=ur_lines[0])
cad.distance(ur_pts[1], ur_pts[2], V_UPRIGHT_H)
cad.ensure_convergence()
upright_r = cad.extrude(up_r_plane,
                        cad.region(loop=ur_lines, inside=(0.0, Z_PITCH + 10.0)),
                        X_ROLL_OUT - X_ROLL_IN, direction="negative",
                        export=False)

up_l_plane = _plane_x(-X_ROLL_OUT, "upright_l_face")
cad.with_sketch(up_l_plane)
ul_pts, ul_lines = _rect(-ARM_D / 2.0, Z_PITCH, ARM_D / 2.0,
                         Z_ROLL - BRIDGE_T / 2.0)
cad.horizontal(line=ul_lines[0])
cad.parallel(line1=ul_lines[2], line2=ul_lines[0])
cad.vertical(line=ul_lines[1])
cad.perpendicular(line1=ul_lines[3], line2=ul_lines[0])
cad.distance(ul_pts[1], ul_pts[2], V_UPRIGHT_H)
cad.ensure_convergence()
upright_l = cad.extrude(up_l_plane,
                        cad.region(loop=ul_lines, inside=(0.0, Z_PITCH + 10.0)),
                        X_ROLL_OUT - X_ROLL_IN, direction="negative",
                        export=False)

roll_frame = cad.bool_union(bridge, upright_r, upright_l, back_plate)
cad.set_color("roll_frame", COL_PRINT, finish="matte")

# =============================================================================
# PITCH YOKE — the other printed U: the cradle the camera bolts to, plus two
# arms up to the pitch pivots. One part, so the camera interface and the pitch
# axis can never drift apart.
# =============================================================================
V_CRADLE_W = cad.variable(CRADLE_W, driving=True)
V_CRADLE_D = cad.variable(CRADLE_D, driving=True)
V_CRADLE_T = cad.variable(CRADLE_T, driving=True)

Y_CAM = -CG_FWD                                   # camera body centre in y
cradle_plane = _plane_at(Z_CRADLE, "cradle_face")
cad.with_sketch(cradle_plane)
ch = CRADLE_W / 2.0
Y_CRADLE_BACK = Y_CAM - CAM_D / 2.0 - 6.0
cr_pts, cr_lines = _rect(-ch, Y_CRADLE_BACK, ch, Y_CRADLE_BACK + CRADLE_D)
cad.horizontal(line=cr_lines[0])
cad.parallel(line1=cr_lines[2], line2=cr_lines[0])
cad.vertical(line=cr_lines[1])
cad.perpendicular(line1=cr_lines[3], line2=cr_lines[0])
cad.distance(cr_pts[0], cr_pts[1], V_CRADLE_W)
cad.distance(cr_pts[1], cr_pts[2], V_CRADLE_D)

# The camera screw runs in a fore/aft SLOT, not a hole. That slot is the
# balance adjustment this whole design depends on: swap the lens and the CG
# moves, and the way you put it back on the pitch axis is to slide the camera.
# A stadium — two straight sides closed by two half-circle ends.
Y_SOCKET = Y_CAM + SOCKET_FWD
V_SLOT_R = cad.variable(SLOT_R, driving=True)
sl_y0 = Y_SOCKET - SLOT_TRAVEL / 2.0
sl_y1 = Y_SOCKET + SLOT_TRAVEL / 2.0
sl_c0 = cad.point2d(0.0, sl_y0)
sl_c1 = cad.point2d(0.0, sl_y1)
sl_a = cad.point2d(-SLOT_R, sl_y0)
sl_b = cad.point2d(SLOT_R, sl_y0)
sl_c = cad.point2d(SLOT_R, sl_y1)
sl_d = cad.point2d(-SLOT_R, sl_y1)
sl_left = cad.line2d(sl_a, sl_d)
sl_right = cad.line2d(sl_c, sl_b)
sl_top = cad.arc2d(sl_c1, sl_d, sl_c, clockwise=True)
sl_bot = cad.arc2d(sl_c0, sl_b, sl_a, clockwise=True)
cad.vertical(line=sl_left)
cad.vertical(line=sl_right)
cad.radius(circle=sl_top, radius=V_SLOT_R)
cad.radius(circle=sl_bot, radius=V_SLOT_R)
cad.distance(sl_c0, sl_c1, SLOT_TRAVEL)
cradle_holes = [[sl_left, sl_top, sl_right, sl_bot]]
cradle_holes += _square_holes(0.0, Y_CRADLE_BACK + 14.0, 40.0, 6.0, M3_CLEAR_R)
cad.ensure_convergence()

cradle = cad.extrude(cradle_plane,
                     cad.region(loop=cr_lines, holes=cradle_holes,
                                inside=(ch - 8.0, Y_CRADLE_BACK + 6.0)),
                     V_CRADLE_T, export=False)

V_YOKE_H = cad.variable(Z_PITCH + 12.0 - (Z_CRADLE + CRADLE_T), driving=True)

yk_r_plane = _plane_x(X_YOKE_IN, "yoke_r_face")
cad.with_sketch(yk_r_plane)
yr_pts, yr_lines = _rect(-ARM_D / 2.0, Z_CRADLE + CRADLE_T, ARM_D / 2.0,
                         Z_PITCH + 12.0)
cad.horizontal(line=yr_lines[0])
cad.parallel(line1=yr_lines[2], line2=yr_lines[0])
cad.vertical(line=yr_lines[1])
cad.perpendicular(line1=yr_lines[3], line2=yr_lines[0])
cad.distance(yr_pts[1], yr_pts[2], V_YOKE_H)
cad.ensure_convergence()
yoke_r = cad.extrude(yk_r_plane,
                     cad.region(loop=yr_lines, inside=(0.0, Z_PITCH)),
                     X_YOKE_OUT - X_YOKE_IN, direction="negative", export=False)

yk_l_plane = _plane_x(-X_YOKE_OUT, "yoke_l_face")
cad.with_sketch(yk_l_plane)
yl_pts, yl_lines = _rect(-ARM_D / 2.0, Z_CRADLE + CRADLE_T, ARM_D / 2.0,
                         Z_PITCH + 12.0)
cad.horizontal(line=yl_lines[0])
cad.parallel(line1=yl_lines[2], line2=yl_lines[0])
cad.vertical(line=yl_lines[1])
cad.perpendicular(line1=yl_lines[3], line2=yl_lines[0])
cad.distance(yl_pts[1], yl_pts[2], V_YOKE_H)
cad.ensure_convergence()
yoke_l = cad.extrude(yk_l_plane,
                     cad.region(loop=yl_lines, inside=(0.0, Z_PITCH)),
                     X_YOKE_OUT - X_YOKE_IN, direction="negative", export=False)

pitch_yoke = cad.bool_union(cradle, yoke_r, yoke_l)
cad.set_color("pitch_yoke", COL_PRINT_ALT, finish="matte")

# =============================================================================
# THE CAMERA SCREW — 1/4"-20 UNC, with a REAL helical thread.
#
# The standard library stops at M8 and is metric throughout, and a 1/4"-20 is
# the one thread this design cannot substitute: it is the interface to the
# camera. So the thread is cut the way §6.4 describes — a 60 deg V tooth swept
# along a helix at the major radius and differenced out of the shank. It needs
# a fine mesh to resolve a 1.27 mm pitch, so this body (and only this body)
# carries its own quality.
# =============================================================================
with cad.component("camera_screw", label='1/4"-20 camera mount screw'):
    scr_plane = _plane_at(0.0, "screw_face")
    cad.with_sketch(scr_plane)
    head_c = cad.circle2d(cad.point2d(0.0, 0.0), SCREW_HEAD_D / 2.0)
    head = cad.extrude(scr_plane, cad.region(loop=[head_c], inside=(0.0, 0.0)),
                       SCREW_HEAD_T, quality="high", export=False)
    shank_plane = _plane_at(SCREW_HEAD_T, "screw_shank_face")
    cad.with_sketch(shank_plane)
    shank_c = cad.circle2d(cad.point2d(0.0, 0.0), UNC_D / 2.0)
    shank = cad.extrude(shank_plane,
                        cad.region(loop=[shank_c], inside=(0.0, 0.0)),
                        CRADLE_T + UNC_ENGAGE, quality="high", export=False)
    blank = cad.bool_union(head, shank, quality="high", export=False)

    # The tooth: apex pointing radially INWARD, centred on the sketch origin —
    # the offset lives in the helix, never in both places.
    depth = THREAD_DEPTH_FACTOR * UNC_PITCH
    half_base = depth * math.tan(math.radians(30.0))
    cad.with_sketch("xy")
    t_apex = cad.point2d(-depth, 0.0)
    t_a = cad.point2d(0.0, half_base)
    t_b = cad.point2d(0.0, -half_base)
    tl1 = cad.line2d(t_apex, t_a)
    tl2 = cad.line2d(t_a, t_b)
    tl3 = cad.line2d(t_b, t_apex)
    tooth = cad.region(loop=[tl1, tl2, tl3], inside=(-depth / 3.0, 0.0))
    turns = (CRADLE_T + UNC_ENGAGE) / UNC_PITCH
    thread_path = cad.helix(radius=UNC_D / 2.0, pitch=UNC_PITCH, turns=turns,
                            axis_origin=(0.0, 0.0, SCREW_HEAD_T))
    tool = cad.sweep("xy", tooth, thread_path, quality="high", export=False)
    screw_body = cad.bool_difference(blank, tool, quality="high")
    cad.set_color(screw_body, COL_SCREW, finish="metallic")
    cad.component_export(screw_body, name="s")
    cad.component_export_point("tip", cad.point(0.0, 0.0,
                                                SCREW_HEAD_T + CRADLE_T + UNC_ENGAGE))

# Head under the cradle, thread up through it into the camera's socket. The
# screw is built head-first from z = 0 pointing +Z, so the head goes one head
# thickness BELOW the cradle and everything above follows.
cad.instance("camera_screw",
             translate=(0.0, Y_SOCKET, Z_CRADLE - SCREW_HEAD_T),
             name="cam_screw", export=False)

# =============================================================================
# THE CAMERA — a transparent box and a transparent cylinder. Nothing more is
# needed and nothing more would be honest: this is an envelope, not a model.
# =============================================================================
cam_plane = _plane_at(Z_CAM, "camera_face")
cad.with_sketch(cam_plane)
cw = CAM_W / 2.0
_cbp, cam_lines = _rect(-cw, Y_CAM - CAM_D / 2.0, cw, Y_CAM + CAM_D / 2.0)
camera_body = cad.extrude(cam_plane,
                          cad.region(loop=cam_lines, inside=(0.0, Y_CAM)),
                          CAM_H, export=False)
cad.set_color("camera_body", COL_GLASS, finish="glass")

lens_plane = cad.create_sketch_plane(cad.point(0.0, Y_CAM + CAM_D / 2.0, 0.0),
                                     cad.point(0.0, Y_CAM + CAM_D / 2.0, 1.0),
                                     cad.point(1.0, Y_CAM + CAM_D / 2.0, 0.0),
                                     name="lens_face")
cad.with_sketch(lens_plane)
lens_c = cad.circle2d(cad.point2d(0.0, Z_PITCH), LENS_D / 2.0)
camera_lens = cad.extrude(lens_plane,
                          cad.region(loop=[lens_c], inside=(0.0, Z_PITCH)),
                          LENS_L, export=False)
cad.set_color("camera_lens", COL_GLASS, finish="glass")

# =============================================================================
# SERVOS, HORNS AND IDLERS
# =============================================================================
SERVO = servo(cad, size="large")
HORN_DISC = horn(cad, style="disc", spline="large", length=22.0)
BRG = bearing(cad, designation="608")

# ---- yaw: flange on the deck, spline up, disc horn under the yaw plate -----
yaw_servo = cad.instance(SERVO, translate=(X_YAW_SERVO, 0.0, Z_SERVO_FLANGE),
                         name="yaw_servo", export=False)
yaw_horn = cad.instance(HORN_DISC, name="yaw_horn", export=False)
cad.mate_coincident(yaw_horn, "hub", yaw_servo.spline_tip)

# ---- roll: servo on the mast's BACK face, spline forward through its bore --
# A -90 turn about X lays the servo's +Z axis onto +y, which puts the case
# behind the mast and the spline through it. The spline then has to land on
# the roll axis: hence the -SERVO_SPLINE_OFF in x, and the mast back face in y.
roll_servo = cad.instance(SERVO, axis=(1, 0, 0), angle=-90.0,
                          translate=(-SERVO_SPLINE_OFF, Y_MAST_BACK, Z_ROLL),
                          name="roll_servo", export=False)
roll_horn = cad.instance(HORN_DISC, axis=(1, 0, 0), angle=-90.0,
                         name="roll_horn", export=False)
cad.mate_coincident(roll_horn, "hub", roll_servo.spline_tip)

# ---- pitch: servo inside the right upright, idler bearing on the left ------
# A -90 turn about y lays the servo's +Z onto -x, so the case stands OUTSIDE
# the roll upright and only the spline reaches in to the yoke arm. Placed the
# other way round the case lands inside the frame, straight through the camera.
pitch_servo = cad.instance(SERVO, axis=(0, 1, 0), angle=-90.0,
                           translate=(X_ROLL_OUT, 0.0,
                                      Z_PITCH - SERVO_SPLINE_OFF),
                           name="pitch_servo", export=False)
pitch_horn = cad.instance(HORN_DISC, axis=(0, 1, 0), angle=-90.0,
                          name="pitch_horn", export=False)
cad.mate_coincident(pitch_horn, "hub", pitch_servo.spline_tip)

cad.instance(BRG, axis=(0, 1, 0), angle=90.0,
             translate=(-X_ROLL_IN, 0.0, Z_PITCH), name="pitch_idler",
             export=False)


# =============================================================================
# ELECTRONICS ON THE BASE PLATE
# =============================================================================
Z_TOP_FOOT = Z_FOOT + FOOT_T
PI_STANDOFF = pcb_standoff(cad, height=6.0)
PI = raspberry_pi(cad, model="4B")
pi = cad.instance(PI, translate=(-30.0, 30.0, Z_TOP_FOOT + 6.0), name="pi",
                  export=False)
cad.instance(rpi_hat(cad), translate=(-30.0, 30.0, Z_TOP_FOOT + 6.0 + 12.0),
             name="servo_hat", export=False)
for i, (sx, sy) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
    cad.instance(PI_STANDOFF, translate=(-30.0 + sx * 29.0, 30.0 + sy * 24.5,
                                         Z_TOP_FOOT),
                 name=f"pi_standoff{i}", export=False)

cad.instance(battery_holder(cad, cell="18650", count=3),
             translate=(40.0, -40.0, Z_TOP_FOOT), name="battery", export=False)
cad.instance(buck_converter(cad), translate=(-40.0, -50.0, Z_TOP_FOOT),
             name="buck", export=False)
cad.instance(rocker_switch(cad), axis=(1, 0, 0), angle=-90.0,
             translate=(0.0, -FOOT_S / 2.0, Z_TOP_FOOT + 14.0), name="psw",
             export=False)
cad.instance(usb(cad, kind="C"), translate=(-30.0, 66.0, Z_TOP_FOOT + 6.0),
             name="usb_c", export=False)

CLIP = cable_clip(cad, cable_d=6.0)
cad.instance(CLIP, translate=(-MAST_W / 2.0 - 4.0, Y_MAST_BACK + MAST_T / 2.0, 140.0),
             name="clip0", export=False)
cad.instance(CLIP, translate=(-MAST_W / 2.0 - 4.0, Y_MAST_BACK + MAST_T / 2.0, 200.0),
             name="clip1", export=False)

# =============================================================================
# THE HEAD'S OWN TRIPOD INTERFACE AND ITS STANDOFFS
# =============================================================================
cad.instance(tripod_mount(cad), mirror_plane="xy", translate=(0.0, 0.0, Z_FOOT),
             name="tripod", export=False)

M3_STANDOFF = standoff(cad, thread="M3", length=STANDOFF_L,
                       gender="female-female")
M3_SCREW = cap_screw(cad, thread="M3", length=10.0)
M3_INSERT = heatset_insert(cad, thread="M3")
for i, (sx, sy) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
    px = sx * (DECK_S / 2.0 - 12.0)
    py = sy * (DECK_S / 2.0 - 12.0)
    cad.instance(M3_STANDOFF, translate=(px, py, Z_TOP_FOOT),
                 name=f"post{i}", export=False)
    cad.instance(M3_SCREW, translate=(px, py, Z_DECK + DECK_T),
                 name=f"deck_screw{i}", export=False)
    cad.instance(M3_SCREW, mirror_plane="xy", translate=(px, py, Z_FOOT),
                 name=f"foot_screw{i}", export=False)

# Yaw servo flange screws, and the heat-set inserts the mast bolts into.
for i, (sx, sy) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
    cad.instance(M3_SCREW,
                 translate=(X_YAW_SERVO + sx * 37.45, sy * 8.9,
                            Z_SERVO_FLANGE + 4.0),
                 name=f"yaw_screw{i}", export=False)
for i, sx in enumerate((1, -1)):
    cad.instance(M3_INSERT,
                 translate=(sx * (MAST_W / 2.0 - 10.0),
                            Y_MAST_BACK + MAST_T / 2.0,
                            Z_YAWPLATE + YAWPLATE_T),
                 name=f"mast_insert{i}", export=False)

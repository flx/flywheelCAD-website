# Radial flux motor — build notes

A 12-slot / 14-pole outrunner BLDC, 100 mm stator OD, 30 mm stack, 121.6 mm
bell OD. The companion piece to `AxialFluxMotor` — same job, the usual
geometry: flux crosses a cylindrical gap, the magnets ride inside a rotating
bell, and the stator is a slotted iron core with concentrated windings.

## Why 12N14P

It is the combination almost every hobby outrunner uses, for three reasons
that all fall out of the slot/pole arithmetic:

- **Winding factor 0.933.** Each slot is 210 electrical degrees from the next
  (7 pole pairs × 360° ÷ 12 slots). Grouping the coils into phases leaves a
  30° spread inside each phase, so the coils very nearly add in phase.
- **Cogging period = LCM(12, 14) = 84** steps per revolution. High cogging
  order means low cogging *amplitude*, and no skew is needed to get it.
- **Adjacent-pair windings.** Phases come out as pairs of neighbouring teeth,
  which is the easiest thing there is to wind by hand.

## What is editable, and where

| You want to change | Do it |
|---|---|
| stator OD / bore, stack height | **In the app** — `V_R_STATOR_OUT`, `V_R_STATOR_BORE`, `V_STACK_H` |
| bearing seat Ø, carrier bore, flange Ø and thickness, flange bolt circle | **In the app** — the carrier is a revolved half-section plus a plate, both dimensioned |
| bell OD, skirt inner Ø, shaft bore, front-plate thickness | **In the app** — `V_R_BELL_OUT`, `V_R_BELL_IN`, `V_R_SHAFT`, `V_BELL_PLATE_T` |
| slot count, pole count, slot shape, magnet arc, air gap, winding build | **In `main.py`**, parameter block — these also move the placed magnets, coils and hardware |

As in the axial motor, each `cad.variable(...)` is declared immediately above
the sketch it drives rather than hoisted into the parameter block. This file
has no fillets, so the bug that forces it there — a variable declared before a
`cad.fillet(...)` is dragged off its value by that sketch's solve, FlywheelCAD
0.22 — cannot bite here. The habit is kept anyway: it reads better, and
copying this file into one that *does* have fillets should not introduce the
defect.

## Two things this file does that the axial motor does not

**Open slots, cut by a circular pattern.** A stator slot has to be *open* — a
gap through the pole shoe — or you could never get wire onto the tooth. An
open slot is exactly what a region hole cannot express, since a hole loop is
by definition enclosed. So the slot is drawn once as its own solid, turned
into twelve by `cad.pattern_circular(...)`, and subtracted:

```python
slot_seed = cad.extrude(slot_plane, region, STACK_H + 2.0, export=False)
slots     = cad.pattern_circular(slot_seed, count=N_SLOTS, angle=360, export=False)
stator_core = cad.bool_difference(core_blank, *slots, export=False)
```

Note the `export=False` on the pattern: a boolean *hides* the operands it
consumes, but hidden is not the same as excluded from the 3MF, and without it
eleven slot-shaped ghosts land in your export.

**Arc magnets.** The poles are true arc segments — two concentric `cad.arc2d`
runs closed by two radial lines — so the pole face lies *on* the air gap
rather than chording across it. A flat block magnet on a 14-flat liner is the
easier thing to source; if you go that way the gap grows toward each magnet's
edges and you lose a few percent of flux.

## Bill of materials

| Qty | Part | Notes |
|----:|------|-------|
| 14 | N42 arc magnet, R50.8 / R54.8 × 22° × 32 mm | or 40 × 15 × 4 blocks on a 14-flat liner |
| 1 | 12-slot lamination stack, OD 100 / ID 48 × 30 | laser-cut 0.35 mm silicon steel — DXF from the `stator_core` body |
| 1 | steel back-iron ring, OD 113.6 / ID 109.6 × 32 | rolled or turned |
| 2 | 6000 deep-groove ball bearing (10 × 26 × 8) | *library part* |
| 1 | 10 mm shaft, 100 mm, chamfered both ends | *library part* |
| 1 | DIN 471 circlip, 10 mm shaft | *library part* — the rear axial stop |
| 1 | 10 mm thrust washer | *library part* — fills the 1.2 mm hub/carrier gap |
| 1 | 10 mm split shaft collar | *library part* |
| 1 | DIN 6885 key, 3 × 3 × 20 | *library part* — the output drive |
| 4 | M4 × 12 cap screw | *library part*, counterbored flush into the flange |
| 6 | M3 × 10 cap screw + M3 heat-set insert | *library parts*, into the bell front plate |
| 2 | M4 × 6 grub screw | *library part*, bell hub → shaft |
| 1 | 3-way JST connector + cable clip | *library parts*, hall sensors and phase wires |
| ~200 g | 1.0 mm enamelled magnet wire | |

**Printed:** `rotor_bell`, `stator_carrier`. The carrier holds both bearings,
so print it at 100 % infill (or turn it from aluminium) and consider a
press-fit sleeve at each seat; a printed bearing bore creeps under load.

## Winding

Twelve concentrated coils, one per tooth, in adjacent pairs:

```
tooth   0  1  2  3  4  5  6  7  8  9 10 11
phase   A  A  B  B  C  C  A  A  B  B  C  C
sense   +  -  +  -  +  -  +  -  +  -  +  -
```

The second coil of every pair is wound in the **opposite direction** — that is
what turns the 210°-per-slot progression into three phases 120° apart. Wire
all four coils of a phase in series and star the three ends together.

Model the winding as an envelope, not as strands: the block around each tooth
is 5 mm of build-up on all four sides over a 0.4 mm bobbin clearance. Each
coil side then occupies 5 × 30 = 150 mm² of slot, which at a realistic 40–50 %
fill is **76–95 turns of 1.0 mm wire** — call it 85. Two coil sides share a
slot, and 2 × 5 mm of build fits the ~12 mm the slot is wide at mid-height
with about 0.8 mm to spare.

## Estimated performance (arithmetic, not measurements)

With N42 magnets 4 mm thick over a 0.8 mm gap, the gap flux density is roughly

    B_gap ≈ Br · l_m / (l_m + g·μ_rec) ≈ 1.3 · 4 / (4 + 0.84) ≈ 1.07 T

and about 0.85 T after leakage. The pole face is 19.5 mm (a 22° arc at R50.8)
by 30 mm, so flux per pole Φ ≈ 0.50 mWb.

With 4 coils per phase and k_w = 0.933, λ = k_w · 4N · Φ:

| turns/coil | λ (Wb) | K_t = 1.5·p·λ | K_v | torque at 20 A |
|---:|---:|---:|---:|---:|
| 20 | 0.037 | 0.39 N·m/A | ≈ 21 rpm/V | 7.8 N·m |
| 40 | 0.074 | 0.78 N·m/A | ≈ 11 rpm/V | 15.6 N·m |
| 85 (a full window) | 0.158 | 1.66 N·m/A | ≈ 5 rpm/V | 33 N·m |

Electrical frequency is 117 Hz at 1000 rpm (7 pole pairs) regardless.

**K_v scales inversely with turns, so this is the one real decision.** Filling
the window gives a direct-drive wheel motor — enormous torque, and 5 rpm/V
means 48 V gets you 240 rpm. Twenty turns gives a 21 rpm/V motor that will
happily spin past 1000 rpm on the same pack. Pick turns for the voltage and
speed you have, then check the current the wire can carry.

These are first-order numbers — no saturation, no end-turn leakage, no
temperature derating; treat them as sizing, not as a datasheet.

## Assembly order

1. Stack and bond the laminations; insulate the slots (paper or a printed
   bobbin per tooth).
2. Wind all 12 coils, watching the direction table above. Bring 12 wire ends
   out, then join them into 3 phases + star.
3. Press the two 6000s into the carrier; glue the stator stack onto the
   carrier tube, coils outward.
4. Bond the back-iron ring into the bell skirt, then glue the 14 magnets to
   it, alternating N/S (red/blue in the model). **Use a spacing jig** — the
   magnets repel their neighbours and attract the ring, and a hand-placed ring
   will not be evenly pitched.
5. Shaft up through the carrier from the back; circlip into its groove behind
   the rear bearing; thrust washer onto the carrier's front face.
6. Bell down onto the shaft, two grub screws into the hub. Check the rotor
   spins without rubbing — the air gap is 0.8 mm and a printed bell is not
   round until you say it is.
7. Shaft collar at the back as the final axial stop.

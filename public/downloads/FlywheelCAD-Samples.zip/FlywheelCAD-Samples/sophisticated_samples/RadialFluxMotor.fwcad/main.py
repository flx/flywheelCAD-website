# flywheelcad-format: 1
# =============================================================================
# RADIAL FLUX MOTOR — 12N14P outrunner BLDC, ~122 mm bell OD
# =============================================================================
# The other half of the pair with AxialFluxMotor: the same job done the usual
# way round. Flux crosses a cylindrical air gap instead of a flat one, the
# magnets ride on the INSIDE of a rotating bell, and the stator is a slotted
# iron core with concentrated windings — 12 slots, 14 poles, the combination
# every hobby outrunner from a 6374 upward uses (high winding factor, low
# cogging, and it needs no skew).
#
# Sizes are the "robot drive / e-bike mid-drive" class: 100 mm stator OD,
# 30 mm stack, 10 mm rotating shaft on two 6000 bearings.
#
# ---------------------------------------------------------------------------
# HOW TO CHANGE THIS DESIGN
# ---------------------------------------------------------------------------
# Same contract as the axial motor. Numbers live once in the parameter block;
# the ones that shape a part are bound to DRIVING VARIABLES declared directly
# above the sketch they drive, so the app's Variables panel and the sketch
# dimensions both edit the real thing. Slot and magnet patterns are generated
# and deliberately carry no dimensions — their design decision is the count.
#
# Two techniques worth reading here that the axial motor does not use:
#   * the slots are cut with `cad.pattern_circular` + `cad.bool_difference` —
#     ONE drawn slot becomes twelve, and the difference gives real OPEN slots
#     you can actually wind, which a region hole cannot;
#   * the magnets are true ARC segments (`cad.arc2d` between two radii), so
#     their inner face lies on the air gap instead of chording across it.
#
# ---------------------------------------------------------------------------
# BILL OF MATERIALS
# ---------------------------------------------------------------------------
#   14x  N42 arc magnet, R50.8/R54.8 x 22 deg x 32 mm  (or 40x15x4 blocks on
#        a 14-flat liner, if arcs are hard to source)
#    2x  6000 deep-groove ball bearing, 10 x 26 x 8       [library part]
#    1x  10 mm shaft, 100 mm, chamfered                   [library part]
#    1x  DIN 471 circlip for 10 mm shaft                  [library part]
#    1x  DIN 6885 key, 10 mm shaft, 20 long               [library part]
#    1x  10 mm thrust washer + 1x 10 mm shaft collar      [library parts]
#    1x  steel back-iron ring, OD 113.6 / ID 109.6 x 32   (rolled or turned)
#    1x  12-slot lamination stack, OD 100 / ID 48 x 30    (laser-cut 0.35 mm
#         silicon steel — DXF from the `stator_core` body)
#    4x  M4 x 12 cap screw, counterbored into the flange     [library part]
#    6x  M3 x 10 cap screw into M3 heat-set inserts (bell)    [library parts]
#    2x  M4 x 6 grub screw (bell hub -> shaft)                [library part]
#    1x  3-way JST connector (hall sensors) + a cable clip    [library parts]
#   ~200 g of 1.0 mm enamelled magnet wire
#
# PRINTED: rotor_bell, stator_carrier (or turn it from aluminium — it holds
# the bearings, so a printed one wants 100 % infill and a press-fit sleeve).
# See BUILD_NOTES.md for winding order, phase wiring and the Kv arithmetic.
# =============================================================================
from flywheelcad import *

cad = FlywheelCAD()

import math

from lib.standard.bearings import bearing
from lib.standard.shafting import shaft, shaft_collar, key, thrust_washer
from lib.standard.fasteners import cap_screw, clearance
from lib.standard.fasteners_more import grub_screw, heatset_insert
from lib.standard.fasteners_pins import retaining_ring
from lib.standard.connectors import jst
from lib.standard.mounts import cable_clip

# =============================================================================
# PARAMETER BLOCK
# =============================================================================

# ---- pole / slot counts (integers: a count is not a dimension) --------------
N_POLES = 14                # rotor magnets
N_SLOTS = 12                # stator slots — 12N14P is the classic pairing

# ---- stator core ------------------------------------------------------------
STACK_H = 30.0              # lamination stack height
R_STATOR_OUT = 50.0         # stator OD/2 — the air-gap face
R_STATOR_BORE = 24.0        # bore over the carrier tube
R_YOKE_OUT = 31.0           # yoke OD/2 = the root of every slot
R_SHOE_IN = 45.0            # where the slot narrows into the pole shoe
SLOT_HW_ROOT = 4.0          # slot half-width at the yoke
SLOT_HW_SHOE = 8.0          # slot half-width under the shoe (tooth ~8 mm wide
                            # at both ends: the slot widens as the pitch does)
SLOT_OPEN_HW = 2.0          # half-width of the slot opening at the OD

# ---- air gap and magnets ----------------------------------------------------
AIR_GAP = 0.8               # stator OD -> magnet inner face
MAG_T = 4.0                 # magnet radial thickness
MAG_ARC = 22.0              # magnet included angle (pole pitch is 25.71 deg)
MAG_L = 32.0                # magnet axial length (1 mm proud of the stack each end)
R_MAG_IN = R_STATOR_OUT + AIR_GAP          # 50.8
R_MAG_OUT = R_MAG_IN + MAG_T               # 54.8
Z_MAG = -1.0                # magnet starts 1 mm below the stack

# ---- rotor bell -------------------------------------------------------------
YOKE_T = 2.0                # steel back-iron ring thickness
R_BELL_IN = R_MAG_OUT + YOKE_T             # 56.8 — skirt inner wall
BELL_WALL = 4.0             # printed skirt wall
R_BELL_OUT = R_BELL_IN + BELL_WALL         # 60.8 (bell OD 121.6)
BELL_PLATE_T = 6.0          # front plate thickness
R_BELL_HUB = 16.0           # hub boss radius
R_SHAFT = 5.0               # 10 mm shaft
Z_SKIRT_END = -6.0          # skirt reaches 6 mm past the back of the stack
Z_BELL_FRONT = 44.0         # outer face of the front plate
R_BELL_BOLTS = 34.0         # M3 bolt circle on the front plate  (coupled)

# ---- stator carrier (the stationary tube the bearings live in) --------------
R_BRG_SEAT = 13.0           # 6000 outer radius — the press-fit seat
BRG_W = 8.0                 # 6000 width
R_TUBE_BORE = 12.5          # shoulder bore: clears the ROTATING inner ring
Z_TUBE_BACK = -14.0
Z_TUBE_FRONT = 34.0
R_FLANGE = 40.0             # mounting flange radius
FLANGE_T = 6.0
R_FLANGE_BOLTS = 32.0       # 4x M4 to the frame              (coupled)

# ---- winding ----------------------------------------------------------------
WIND_T = 5.0                # winding build-up around the tooth
WIND_CLEAR = 0.4            # bobbin/insulation clearance over the tooth
R_WIND_IN = 32.0            # radial start of the winding
R_WIND_OUT = 44.0           # radial end (clear of the shoe)
TOOTH_HW = 4.1              # tooth half-width at the winding band

PHASE_COLORS = ["#B87333", "#2E7D32", "#5E35B1"]
COL_N, COL_S = "#C62828", "#1565C0"
COL_LAM = "#78909C"
COL_YOKE = "#90A4AE"
COL_BELL = "#EF6C00"
COL_CARRIER = "#37474F"


# =============================================================================
# HELPERS — pattern geometry (derived data; deliberately undimensioned, §D)
# =============================================================================
def _rot(x, y, deg):
    a = math.radians(deg)
    return (x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a))


def _polar(r, deg):
    a = math.radians(deg)
    return (r * math.cos(a), r * math.sin(a))


def _plane_at(z, name):
    """A sketch plane parallel to XY at height z (frame u=+X, v=+Y). Every
    module-level part gets its own, so no two parts share a sketch."""
    return cad.create_sketch_plane(cad.point(0.0, 0.0, z),
                                   cad.point(1.0, 0.0, z),
                                   cad.point(0.0, 1.0, z), name=name)


def _closed_polyline(pts2d):
    """A closed loop of straight lines through the given sketch points."""
    ps = [cad.point2d(round(x, 3), round(y, 3)) for (x, y) in pts2d]
    ls = [cad.line2d(ps[j], ps[j + 1]) for j in range(len(ps) - 1)]
    ls.append(cad.line2d(ps[-1], ps[0]))
    return ps, ls


# =============================================================================
# STATOR CORE — purchased/laser-cut, modelled as one solid stack.
#
# A disc with a bore, minus twelve OPEN slots. The slots have to be open (a
# gap through the pole shoe) or the coils could not be wound onto the teeth,
# and an open slot is exactly what a region hole CANNOT express — a hole loop
# is by definition enclosed. So the slot is drawn once as its own solid and
# subtracted twelve times:
#
#     seed slot  ->  cad.pattern_circular(..., count=12)  ->  bool_difference
#
# The two circles carry radius dimensions; the slot polygon does not, because
# it is one member of a twelve-fold pattern.
# =============================================================================
V_R_STATOR_OUT = cad.variable(R_STATOR_OUT, driving=True)
V_R_STATOR_BORE = cad.variable(R_STATOR_BORE, driving=True)
V_STACK_H = cad.variable(STACK_H, driving=True)

core_plane = _plane_at(0.0, "stator_core_face")
cad.with_sketch(core_plane)

sc_center = cad.point2d(0.0, 0.0)
sc_outer = cad.circle2d(sc_center, R_STATOR_OUT)
cad.coincident(p0=sc_center, p1=origin_stator_core_face)
cad.radius(circle=sc_outer, radius=V_R_STATOR_OUT)

scb_center = cad.point2d(0.0, 0.0)
sc_bore = cad.circle2d(scb_center, R_STATOR_BORE)
cad.concentric(circle1=sc_bore, circle2=sc_outer)
cad.radius(circle=sc_bore, radius=V_R_STATOR_BORE)

core_blank = cad.extrude(core_plane,
                         cad.region(loop=[sc_outer], holes=[[sc_bore]],
                                    inside=(round((R_STATOR_BORE + R_YOKE_OUT) / 2.0, 3), 0.0)),
                         V_STACK_H, export=False)

# The seed slot, drawn on its own plane (so its polygon never lands in the
# core's sketch) and already rotated onto the first slot centre-line, which
# sits half a pitch off the +X axis — that puts a TOOTH on +X, where the coil
# component below is built.
SLOT_ANG = 180.0 / N_SLOTS                     # 15 deg for 12 slots
slot_plane = _plane_at(-1.0, "slot_cutter_face")
cad.with_sketch(slot_plane)
slot_pts = [_rot(R_YOKE_OUT, -SLOT_HW_ROOT, SLOT_ANG),
            _rot(R_SHOE_IN, -SLOT_HW_SHOE, SLOT_ANG),
            _rot(R_SHOE_IN, -SLOT_OPEN_HW, SLOT_ANG),
            _rot(R_STATOR_OUT + 5.0, -SLOT_OPEN_HW, SLOT_ANG),
            _rot(R_STATOR_OUT + 5.0, SLOT_OPEN_HW, SLOT_ANG),
            _rot(R_SHOE_IN, SLOT_OPEN_HW, SLOT_ANG),
            _rot(R_SHOE_IN, SLOT_HW_SHOE, SLOT_ANG),
            _rot(R_YOKE_OUT, SLOT_HW_ROOT, SLOT_ANG)]
_slot_ps, slot_lines = _closed_polyline(slot_pts)
slot_in = _polar((R_YOKE_OUT + R_SHOE_IN) / 2.0, SLOT_ANG)
slot_seed = cad.extrude(slot_plane,
                        cad.region(loop=slot_lines,
                                   inside=(round(slot_in[0], 3), round(slot_in[1], 3))),
                        STACK_H + 2.0, export=False)

slots = cad.pattern_circular(slot_seed, axis=(0, 0, 1), count=N_SLOTS, angle=360,
                             export=False)
stator_core = cad.bool_difference(core_blank, *slots, export=False)
cad.set_color("stator_core", COL_LAM, finish="metallic")

# =============================================================================
# STATOR CARRIER — the stationary tube the two 6000s press into, plus the
# flange that bolts the whole motor to a frame. Revolved half-section (so the
# bearing seats are real dimensioned lines) unioned with a flange plate (so
# the bolt holes are real region holes).
# =============================================================================
V_R_BRG_SEAT = cad.variable(R_BRG_SEAT, driving=True)
V_R_TUBE_BORE = cad.variable(R_TUBE_BORE, driving=True)
V_R_FLANGE = cad.variable(R_FLANGE, driving=True)
V_R_FLANGE_BOLTS = cad.variable(R_FLANGE_BOLTS, driving=True)
V_FLANGE_T = cad.variable(FLANGE_T, driving=True)

cad.with_sketch("zx")
# (r, z), starting at the back bearing seat's inner lip and running forward.
tube_prof = [(R_TUBE_BORE, Z_TUBE_BACK + BRG_W), (R_BRG_SEAT, Z_TUBE_BACK + BRG_W),
             (R_BRG_SEAT, Z_TUBE_BACK), (R_STATOR_BORE, Z_TUBE_BACK),
             (R_STATOR_BORE, Z_TUBE_FRONT), (R_BRG_SEAT, Z_TUBE_FRONT),
             (R_BRG_SEAT, Z_TUBE_FRONT - BRG_W),
             (R_TUBE_BORE, Z_TUBE_FRONT - BRG_W)]
tube_pts, tube_lines = _closed_polyline(tube_prof)

tube_axis = cad.line2d(cad.point2d(0.0, Z_TUBE_BACK), cad.point2d(0.0, Z_TUBE_FRONT),
                       construction=True)
for j in range(0, 8, 2):
    cad.horizontal(line=tube_lines[j])
for j in range(1, 8, 2):
    cad.vertical(line=tube_lines[j])
cad.point_line_distance(point=tube_pts[1], line=tube_axis, distance=V_R_BRG_SEAT)
cad.point_line_distance(point=tube_pts[0], line=tube_axis, distance=V_R_TUBE_BORE)
cad.length(line=tube_lines[1], length=BRG_W)        # = the 6000's width
cad.length(line=tube_lines[5], length=BRG_W)
cad.ensure_convergence()

carrier_tube = cad.revolve("zx",
                           cad.region(loop=tube_lines,
                                      inside=((R_TUBE_BORE + R_STATOR_BORE) / 2.0, 0.0)),
                           axis_line=tube_axis, angle=360, export=False)

flange_plane = _plane_at(Z_TUBE_BACK, "carrier_flange_face")
cad.with_sketch(flange_plane)
cf_center = cad.point2d(0.0, 0.0)
cf_outer = cad.circle2d(cf_center, R_FLANGE)
cad.coincident(p0=cf_center, p1=origin_carrier_flange_face)
cad.radius(circle=cf_outer, radius=V_R_FLANGE)

cfb_center = cad.point2d(0.0, 0.0)
cf_bore = cad.circle2d(cfb_center, R_BRG_SEAT)
cad.concentric(circle1=cf_bore, circle2=cf_outer)
cad.radius(circle=cf_bore, radius=V_R_BRG_SEAT)

cf_bolt_circle = cad.circle2d(cad.point2d(0.0, 0.0), R_FLANGE_BOLTS, construction=True)
cad.concentric(circle1=cf_bolt_circle, circle2=cf_outer)
cad.radius(circle=cf_bolt_circle, radius=V_R_FLANGE_BOLTS)

cf_holes = [[cf_bore]]
for i in range(4):
    fx, fy = _polar(R_FLANGE_BOLTS, 45.0 + i * 90.0)
    fc = cad.point2d(round(fx, 3), round(fy, 3))
    cf_holes.append([cad.circle2d(fc, 2.25)])       # M4 clearance
    cad.point_on_circle(point=fc, circle=cf_bolt_circle)
cad.ensure_convergence()

carrier_flange = cad.extrude(flange_plane,
                             cad.region(loop=[cf_outer], holes=cf_holes,
                                        inside=(0.0, round(R_FLANGE - 3.0, 3))),
                             V_FLANGE_T, export=False)

carrier_solid = cad.bool_union(carrier_tube, carrier_flange, export=False)

# The library's negative-body workflow, in three lines: `clearance(...,
# head_pocket=True)` is the ISO 273 hole PLUS its DIN 912 counterbore as a
# solid. Place one at each bolt position and subtract — the screw heads then
# sit flush in the flange instead of proud of it, and the pocket depth can
# never disagree with the screw, because both come from the same table.
# Both the pocket and the screw hang from the screw's UNDER-HEAD plane, and
# the counterbore is the volume ABOVE it — so seating the head flush means
# putting that plane one head-height below the flange's top face.
M4_HEAD_H = 4.0                                    # DIN 912 M4 head height
Z_M4_UNDER_HEAD = Z_TUBE_BACK + FLANGE_T - M4_HEAD_H
M4_POCKET = clearance(cad, thread="M4", length=FLANGE_T + 2.0, head_pocket=True)
pockets = [cad.instance(M4_POCKET,
                        translate=_polar(R_FLANGE_BOLTS, 45.0 + i * 90.0)
                        + (Z_M4_UNDER_HEAD,),
                        name=f"pocket{i}", export=False)
           for i in range(4)]
stator_carrier = cad.bool_difference(carrier_solid, *pockets)
cad.set_color("stator_carrier", COL_CARRIER, finish="matte")

# =============================================================================
# ROTOR BELL — printed. A revolved cup: hub with a 10 mm bore, front plate,
# and a skirt whose inner wall is the seat for the back-iron ring. The M3
# holes that hold the ring/output adapter go in as a second sketch so their
# circles do not subdivide the revolve's own section.
# =============================================================================
V_R_BELL_OUT = cad.variable(R_BELL_OUT, driving=True)
V_R_BELL_IN = cad.variable(R_BELL_IN, driving=True)
V_R_SHAFT = cad.variable(R_SHAFT, driving=True)
V_BELL_PLATE_T = cad.variable(BELL_PLATE_T, driving=True)

# Drawn on YZ, not ZX. A revolve profile is ordinary sketch geometry, so two
# half-sections on the SAME plane merge into one set of faces the moment their
# (r, z) footprints overlap — the carrier tube above and this cup do overlap,
# and the region then traces the merged outline instead of the requested loop.
# Any plane through the axis of revolution serves; using a second one keeps the
# two sections in separate sketches.
cad.with_sketch("yz")
Z_PLATE_IN = Z_BELL_FRONT - BELL_PLATE_T           # 38
# The hub does not hang DOWN into the carrier — the front bearing is already
# there. It runs UP through the front plate instead, which is where a real
# outrunner puts it: the grub screws are then reachable from outside, and the
# 1.2 mm gap left below the hub is exactly one thrust washer.
Z_HUB_BOT = Z_TUBE_FRONT + 1.2                     # 35.2
Z_HUB_TOP = Z_BELL_FRONT + 8.0                     # 52
bell_prof = [(R_SHAFT, Z_HUB_BOT), (R_BELL_HUB, Z_HUB_BOT),
             (R_BELL_HUB, Z_PLATE_IN), (R_BELL_IN, Z_PLATE_IN),
             (R_BELL_IN, Z_SKIRT_END), (R_BELL_OUT, Z_SKIRT_END),
             (R_BELL_OUT, Z_BELL_FRONT), (R_BELL_HUB, Z_BELL_FRONT),
             (R_BELL_HUB, Z_HUB_TOP), (R_SHAFT, Z_HUB_TOP)]
bell_pts, bell_lines = _closed_polyline(bell_prof)

bell_axis = cad.line2d(cad.point2d(0.0, Z_SKIRT_END), cad.point2d(0.0, Z_HUB_TOP),
                       construction=True)
for j in range(0, 10, 2):
    cad.horizontal(line=bell_lines[j])
for j in range(1, 10, 2):
    cad.vertical(line=bell_lines[j])
cad.point_line_distance(point=bell_pts[6], line=bell_axis, distance=V_R_BELL_OUT)
cad.point_line_distance(point=bell_pts[3], line=bell_axis, distance=V_R_BELL_IN)
cad.point_line_distance(point=bell_pts[9], line=bell_axis, distance=V_R_SHAFT)
cad.length(line=bell_lines[4], length=BELL_WALL)   # skirt wall thickness
cad.ensure_convergence()

bell_cup = cad.revolve("yz",
                       cad.region(loop=bell_lines,
                                  inside=((R_BELL_HUB + R_BELL_IN) / 2.0,
                                          Z_PLATE_IN + BELL_PLATE_T / 2.0)),
                       axis_line=bell_axis, angle=360, export=False)

bolt_plane = _plane_at(Z_BELL_FRONT + 1.0, "bell_bolt_face")
cad.with_sketch(bolt_plane)
bb_circle = cad.circle2d(cad.point2d(0.0, 0.0), R_BELL_BOLTS, construction=True)
cad.coincident(p0=cad.point2d(0.0, 0.0), p1=origin_bell_bolt_face)
cad.radius(circle=bb_circle, radius=R_BELL_BOLTS)
bb_cutters = []
for i in range(6):
    hx, hy = _polar(R_BELL_BOLTS, i * 60.0)
    hc = cad.point2d(round(hx, 3), round(hy, 3))
    bb_cutters.append([cad.circle2d(hc, 2.1)])      # M3 heat-set insert bore
    cad.point_on_circle(point=hc, circle=bb_circle)
bb_drill = cad.extrude(bolt_plane,
                       cad.region(loop=[bb_cutters[0][0]], inside=(round(R_BELL_BOLTS, 3), 0.0)),
                       BELL_PLATE_T + 4.0, direction="negative", export=False)
bb_drills = cad.pattern_circular(bb_drill, axis=(0, 0, 1), count=6, angle=360,
                                export=False)
rotor_bell = cad.bool_difference(bell_cup, *bb_drills)
cad.set_color("rotor_bell", COL_BELL, finish="matte")

# =============================================================================
# BACK-IRON RING — purchased, rolled or turned steel. It is the magnetic
# return path AND what the magnets actually glue to; the printed skirt just
# holds it. Visual only (export=False).
# =============================================================================
yoke_plane = _plane_at(Z_MAG, "backiron_face")
cad.with_sketch(yoke_plane)
by_center = cad.point2d(0.0, 0.0)
by_outer = cad.circle2d(by_center, R_BELL_IN)
cad.coincident(p0=by_center, p1=origin_backiron_face)
cad.radius(circle=by_outer, radius=R_BELL_IN)
by_bore = cad.circle2d(cad.point2d(0.0, 0.0), R_MAG_OUT)
cad.concentric(circle1=by_bore, circle2=by_outer)
cad.radius(circle=by_bore, radius=R_MAG_OUT)
back_iron = cad.extrude(yoke_plane,
                        cad.region(loop=[by_outer], holes=[[by_bore]],
                                   inside=(round((R_MAG_OUT + R_BELL_IN) / 2.0, 3), 0.0)),
                        MAG_L, export=False)
cad.set_color("back_iron", COL_YOKE, finish="metallic")

# =============================================================================
# MAGNET — a true arc segment: two concentric arcs closed by two radial lines,
# so the pole face sits ON the air gap instead of chording across it. One
# component per pole polarity, instanced 14 times.
# =============================================================================
def magnet_comp(pole):
    def build():
        cad.with_sketch("xy")
        mc = cad.point2d(0.0, 0.0)
        half = MAG_ARC / 2.0
        i0 = cad.point2d(*[round(v, 4) for v in _polar(R_MAG_IN, -half)])
        i1 = cad.point2d(*[round(v, 4) for v in _polar(R_MAG_IN, half)])
        o0 = cad.point2d(*[round(v, 4) for v in _polar(R_MAG_OUT, -half)])
        o1 = cad.point2d(*[round(v, 4) for v in _polar(R_MAG_OUT, half)])
        inner = cad.arc2d(mc, i0, i1)
        outer = cad.arc2d(mc, o0, o1)
        side_a = cad.line2d(i1, o1)
        side_b = cad.line2d(o0, i0)
        blk = cad.extrude("xy",
                          cad.region(loop=[inner, side_a, rev(outer), side_b],
                                     inside=(round((R_MAG_IN + R_MAG_OUT) / 2.0, 3), 0.0)),
                          MAG_L, export=False)
        cad.set_color(blk, COL_N if pole == "N" else COL_S, finish="metallic")
        cad.component_export(blk, name="m")

    return cad.parametric("arc_magnet", build, pole=pole,
                          label=f"N42 arc magnet, {pole} to the gap")


MAG_N = magnet_comp("N")
MAG_S = magnet_comp("S")
for i in range(N_POLES):
    cad.instance(MAG_N if i % 2 == 0 else MAG_S, axis=(0, 0, 1),
                 angle=i * 360.0 / N_POLES, translate=(0, 0, Z_MAG),
                 name=f"mag{i}", export=False)

# =============================================================================
# COIL — one concentrated winding per tooth, 12 off, wired AABBCC AABBCC
# (the 12N14P pattern: two adjacent teeth per phase, wound in opposite
# directions). Modelled as the winding ENVELOPE — a rectangular frame around
# the tooth, drawn on YZ and extruded radially outward along +X.
# =============================================================================
def coil_comp(phase):
    def build():
        cad.with_sketch("yz")
        wy = TOOTH_HW + WIND_CLEAR
        oy = wy + WIND_T
        z0, z1 = -WIND_CLEAR, STACK_H + WIND_CLEAR
        oz0, oz1 = z0 - WIND_T, z1 + WIND_T
        _op, outer_loop = _closed_polyline([(-oy, oz0), (oy, oz0), (oy, oz1), (-oy, oz1)])
        _ip, inner_loop = _closed_polyline([(-wy, z0), (wy, z0), (wy, z1), (-wy, z1)])
        bundle = cad.extrude("yz",
                             cad.region(loop=outer_loop, holes=[inner_loop],
                                        inside=(0.0, round(oz1 - WIND_T / 2.0, 3))),
                             R_WIND_OUT - R_WIND_IN, offset=R_WIND_IN, export=False)
        cad.set_color(bundle, PHASE_COLORS[phase], finish="matte")
        cad.component_export(bundle, name="w")

    return cad.parametric("coil", build, phase=phase,
                          label=f"Phase {'ABC'[phase]} coil")


COIL_BY_PHASE = [coil_comp(0), coil_comp(1), coil_comp(2)]
for i in range(N_SLOTS):
    cad.instance(COIL_BY_PHASE[(i // 2) % 3], axis=(0, 0, 1),
                 angle=i * 360.0 / N_SLOTS, name=f"coil{i}", export=False)

# =============================================================================
# CATALOG PARTS
# =============================================================================
SHAFT_LEN = 100.0
Z_SHAFT_BACK = -22.0
cad.instance(shaft(cad, diameter=R_SHAFT * 2.0, length=SHAFT_LEN, end="chamfered"),
             translate=(0, 0, Z_SHAFT_BACK), name="shaft", export=False)

BRG = bearing(cad, designation="6000")
cad.instance(BRG, translate=(0, 0, Z_TUBE_BACK), name="brg_back", export=False)
cad.instance(BRG, translate=(0, 0, Z_TUBE_FRONT - BRG_W), name="brg_front", export=False)

# Circlip + thrust washer: the axial stop that stops the bell walking forward.
cad.instance(retaining_ring(cad, bore=R_SHAFT * 2.0, kind="external"),
             translate=(0, 0, Z_TUBE_BACK - 0.7), name="circlip", export=False)
cad.instance(thrust_washer(cad, bore=R_SHAFT * 2.0),
             translate=(0, 0, Z_TUBE_FRONT), name="thrust", export=False)
cad.instance(shaft_collar(cad, bore=R_SHAFT * 2.0, style="split"),
             translate=(0, 0, Z_TUBE_BACK - 8.0), name="collar", export=False)

# Output key in the shaft nose, for whatever the motor drives.
# Half the key stands proud of the shaft, the other half sits in its keyway —
# hence the radial offset by one shaft radius.
cad.instance(key(cad, shaft_d=R_SHAFT * 2.0, length=20.0),
             translate=(R_SHAFT, 0, Z_HUB_TOP + 2.0), name="output_key", export=False)

# ---- 4x M4 flange screws, at the same transform as their counterbores ------
M4_SCREW = cap_screw(cad, thread="M4", length=12.0)
for i in range(4):
    fx, fy = _polar(R_FLANGE_BOLTS, 45.0 + i * 90.0)
    cad.instance(M4_SCREW, translate=(fx, fy, Z_M4_UNDER_HEAD),
                 name=f"flange_screw{i}", export=False)

# ---- 6x M3 heat-set inserts + screws in the bell front plate ----------------
M3_INSERT = heatset_insert(cad, thread="M3")
M3_SCREW = cap_screw(cad, thread="M3", length=10.0)
for i in range(6):
    hx, hy = _polar(R_BELL_BOLTS, i * 60.0)
    cad.instance(M3_INSERT, translate=(hx, hy, Z_BELL_FRONT), name=f"insert{i}",
                 export=False)
    cad.instance(M3_SCREW, translate=(hx, hy, Z_BELL_FRONT + 4.0), name=f"bell_screw{i}",
                 export=False)

# ---- 2x M4 grub screw locking the bell hub to the shaft ---------------------
M4_GRUB = grub_screw(cad, thread="M4", length=6.0)
for i in range(2):
    gx, gy = _polar(R_BELL_HUB, i * 180.0)
    cad.instance(M4_GRUB, axis=(0, 1, 0), angle=90.0 + i * 180.0,
                 translate=(gx, gy, Z_BELL_FRONT + 4.0), name=f"grub{i}", export=False)

# ---- hall-sensor connector and a clip for the phase wires -------------------
cad.instance(jst(cad, pins=3), translate=(0.0, R_FLANGE - 6.0, Z_TUBE_BACK + FLANGE_T),
             name="hall_jst", export=False)
cad.instance(cable_clip(cad, cable_d=6.0),
             translate=(-R_FLANGE + 6.0, 0.0, Z_TUBE_BACK + FLANGE_T),
             name="wire_clip", export=False)

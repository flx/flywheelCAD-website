# Sophisticated samples

Four complete machines, at the complexity level of a real project rather than
a feature demo. Where `Samples/showcase/` teaches one concept per file, these
are designs — each one has a bill of materials, an assembly order, and numbers
you can argue with.

| Folder | What it is |
|---|---|
| `AxialFluxMotor.fwcad` | Double-rotor, coreless-stator axial flux machine, ~400 mm OD. 32 poles / 24 coils, every structural part prints flat. A rebuild of the shipped `Samples/AxialFluxMotor` — same machine, a much more editable document. |
| `RadialFluxMotor.fwcad` | 12N14P outrunner BLDC, 100 mm stator OD. Open slots cut by a circular pattern, true arc magnets, a printed bell on two 6000s. |
| `MotorCageMount.fwcad` | A NEMA 23 on an isolated plate inside a 240 mm 2020 T-slot cage. 95 % catalog parts; exactly two plates are drawn. |
| `CameraGimbal.fwcad` | Pan / tilt / roll servo head for a Canon R6 Mark III class body. Six printed parts, a Raspberry Pi on the base, and a real 1/4"-20 thread into the camera. |

## What they have in common

Every one of them is written to be **opened and edited**, not just rendered.
Concretely, and in contrast to the older samples:

**Parts live at module level.** A dimension inside a `with cad.component(...)`
block is not GUI-editable — the app's dimension matcher only looks at lines
that start at column 0. So every part a person might resize is drawn at module
level, and components are kept for what they are actually for: parts that
repeat (24 coils, 64 magnets) and catalog parts.

**Thicknesses are parametric too.** An extrude distance takes a
`cad.variable(...)` exactly as a radius dimension does, and the body resolves
it live — so plate and disc thicknesses are real document parameters here, not
python constants baked into the geometry.

**Sketches carry intent, not just positions.** Rectangles are constrained
rectangles (parallel / perpendicular / equal), circles are concentric to the
axis they share, and bolt circles are construction circles with the holes
constrained onto them — so a hole pattern stays a hole pattern under an edit.

**Pattern output is deliberately undimensioned.** The 24 coil windows, the 32
magnet pockets, the 12 stator slots and the 14 poles carry no dimensions at
all. Their design decision is the count and the radius, which *are*
dimensioned; 32 individually-dimensioned pockets would make a sketch nobody
can read. (This is the judgement §D of the scripting guide asks for.)

**No document-wide mesh quality.** None of these files calls
`cad.set_quality(...)`, so the quality picker in the app keeps working. Where
one body genuinely cannot resolve at the default — the 400 mm axial stator
plate with its 8 mm fillets, the 1.27 mm thread pitch on the camera screw —
that single body carries its own `quality=`, which is the sanctioned escape
hatch. The axial motor renders in ~11 s this way; the old version, which
pinned the whole document to `ultra`, took ~90 s for the same geometry.

## One authoring rule they all follow

Each `cad.variable(...)` is declared **immediately above the sketch it
drives**, not hoisted into the parameter block. In FlywheelCAD 0.22 a variable
declared before a sketch containing `cad.fillet(...)` is dragged off its value
by that sketch's solve — in the axial motor that produced a 92 mm rotor where
185 was asked for, and a stator plate with no thickness at all. Declaring at
the point of use avoids it, and reads better anyway.

## Verifying

Each renders headlessly:

```sh
/Applications/FlywheelCAD.app/Contents/MacOS/FlywheelCAD render \
    AxialFluxMotor.fwcad/main.py -o /tmp/out.3mf
```

All four are covered by `SampleDocumentTests` (executes, and re-executes
identically) and by `RegionResolutionCorpusDigestTests` (their region
resolution is pinned to a committed digest).

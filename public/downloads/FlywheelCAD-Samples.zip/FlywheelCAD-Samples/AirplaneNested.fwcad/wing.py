"""
wing.py — parametric wing leaf component.

A flat, tapered, swept planform (chord along x, span along y) extruded thin.
`wing(...)` builds a distinct component per parameter set and returns its name.
Exports the body plus root/tip quarter-chord mount points.
"""

from flywheelcad import *
cad = FlywheelCAD()


def wing(span=46, root_chord=18, tip_chord=9, sweep=6, thickness=2):
    def build():
        cad.with_sketch("xy")
        le_root = cad.point2d(0, 0)
        te_root = cad.point2d(root_chord, 0)
        te_tip = cad.point2d(sweep + tip_chord, span)
        le_tip = cad.point2d(sweep, span)
        l1 = cad.line2d(le_root, te_root)
        l2 = cad.line2d(te_root, te_tip)
        l3 = cad.line2d(te_tip, le_tip)
        l4 = cad.line2d(le_tip, le_root)
        planform = cad.region(loop=[l1, l2, l3, l4], inside=(root_chord / 2.0, span / 3.0))
        body = cad.extrude("xy", planform, thickness, direction="symmetric")
        cad.set_color(body, "#1565C0", finish="glossy")   # blue wings
        cad.component_export(body)
        cad.component_export_point("root", cad.point(root_chord * 0.25, 0, 0))
        cad.component_export_point("tip", cad.point(sweep + tip_chord * 0.25, span, 0))

    return cad.parametric("wing", build,
                          span=span, root_chord=root_chord,
                          tip_chord=tip_chord, sweep=sweep, thickness=thickness)


if __name__ == "__main__":
    wing()

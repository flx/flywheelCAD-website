# flywheelcad-format: 1
# Motor mount plate — standard-library showcase.
#
# A mounting flange machined from one plate (every cutout is a declared
# region hole — no booleans needed for the plate itself), populated with
# catalog parts from the standard component library. Every part is MATED
# onto a named anchor; nothing is placed by typed coordinates:
#
#   * the plate is a component that exports the anchors the parts attach to
#   * a NEMA 17 stepper hung under the plate by its mount face, shaft up
#     through the boss bore, held by four M3 cap screws mated onto the
#     plate's bolt anchors
#   * a standard-size servo seated by its flange on the plate top, its four
#     M2.5 screws mated onto the servo's own mount holes, and a control horn
#     mated onto the output spline
#   * a 608 bearing mated into its through-seat
#
# The motor and servo hole patterns come from the same library tables the
# parts are built from (NEMA, SERVO), so the plate and the parts cannot
# disagree. Move MOTOR_AT or SERVO_AT and the holes, the parts and their
# screws all follow. Library modules live in lib/standard/ (copy-on-use).

from flywheelcad import *

cad = FlywheelCAD()

from lib.standard.steppers import stepper, NEMA
from lib.standard.servos import servo, horn, SERVO
from lib.standard.fasteners import cap_screw
from lib.standard.bearings import bearing

PLATE_L, PLATE_W, PLATE_T = 160.0, 64.0, 6.0
MOTOR_AT = (-50.0, 0.0)
SERVO_AT = (10.0, 0.0)
BEARING_AT = (62.0, 0.0)

MOTOR = NEMA[17]
SERVO_STD = SERVO["standard"]
hb = MOTOR["bolt"] / 2.0
MOTOR_BOLTS = [(hb, hb), (-hb, hb), (-hb, -hb), (hb, -hb)]  # the stepper's bolt_0..3 order
SERVO_HOLES = SERVO_STD["holes"]                     # the servo's mount_0..3 order


def at(origin, offset):
    return (origin[0] + offset[0], origin[1] + offset[1])


# ---------------------------------------------------------------- plate
# 160 x 64 x 6 flange. All cutouts are nested region holes: corner mounting
# holes (M4 clearance), the motor boss bore + its four M3 clearance holes,
# the servo body cutout + its four screw holes, and the bearing seat.
with cad.component("plate", label="Motor plate 160 x 64"):
    cad.with_sketch("xy")
    hx, hy = PLATE_L / 2.0, PLATE_W / 2.0
    p1 = cad.point2d(-hx, -hy)
    p2 = cad.point2d(hx, -hy)
    p3 = cad.point2d(hx, hy)
    p4 = cad.point2d(-hx, hy)
    outline = [cad.line2d(p1, p2), cad.line2d(p2, p3),
               cad.line2d(p3, p4), cad.line2d(p4, p1)]

    holes = []

    # Corner mounting holes (M4 clearance, 4.5 mm).
    for (cx, cy) in [(74, 26), (-74, 26), (-74, -26), (74, -26)]:
        holes.append([cad.circle2d(cad.point2d(cx, cy), 2.25)])

    # Motor: boss bore (boss + clearance) and M3 clearance on the bolt square.
    holes.append([cad.circle2d(cad.point2d(*MOTOR_AT), MOTOR["boss"] / 2.0 + 0.3)])
    for offset in MOTOR_BOLTS:
        holes.append([cad.circle2d(cad.point2d(*at(MOTOR_AT, offset)), 1.7)])

    # Servo: body cutout (case + fitting clearance) and the flange screw holes.
    sx, sy = SERVO_AT
    cw = SERVO_STD["body_l"] / 2.0 + 0.35
    ch = SERVO_STD["body_w"] / 2.0 + 0.3
    c1 = cad.point2d(sx - cw, sy - ch)
    c2 = cad.point2d(sx + cw, sy - ch)
    c3 = cad.point2d(sx + cw, sy + ch)
    c4 = cad.point2d(sx - cw, sy + ch)
    holes.append([cad.line2d(c1, c2), cad.line2d(c2, c3),
                  cad.line2d(c3, c4), cad.line2d(c4, c1)])
    for offset in SERVO_HOLES:
        holes.append([cad.circle2d(cad.point2d(*at(SERVO_AT, offset)), 1.45)])

    # Bearing seat: 608 pressed through (22 mm OD, light press allowance).
    holes.append([cad.circle2d(cad.point2d(*BEARING_AT), 11.02)])

    body = cad.extrude("xy",
                       cad.region(loop=outline, holes=holes,
                                  inside=(-hx + 6.0, -hy + 6.0)),
                       PLATE_T)
    cad.set_color(body, "#78909C", finish="metallic")
    cad.component_export(body)

    # Anchors: where the catalog parts attach.
    cad.component_export_point("motor_face", cad.point(MOTOR_AT[0], MOTOR_AT[1], 0.0))
    for i, offset in enumerate(MOTOR_BOLTS):
        x, y = at(MOTOR_AT, offset)
        cad.component_export_point(f"motor_bolt_{i}", cad.point(x, y, PLATE_T))
    x, y = at(SERVO_AT, SERVO_HOLES[0])
    cad.component_export_point("servo_seat", cad.point(x, y, PLATE_T))
    cad.component_export_point("bearing_seat", cad.point(BEARING_AT[0], BEARING_AT[1], 0.0))

plate = cad.instance("plate")

# ------------------------------------------------------------ components
# NEMA 17 under the plate: mount face on the plate underside, shaft up
# through the boss bore.
m = stepper(cad, size=17, length=40)
motor = cad.instance(m)
cad.mate_coincident(motor, "mount_face", plate.motor_face)
cad.set_color(motor, "#5C6BC0", finish="matte")

# Four M3 cap screws, heads on the plate top, into the motor's faceplate taps.
m3 = cap_screw(cad, thread="M3", length=8)
for i in range(len(MOTOR_BOLTS)):
    s = cad.instance(m3)
    cad.mate_coincident(s, "under_head", getattr(plate, f"motor_bolt_{i}"))
    cad.set_color(s, "#FFC107", finish="metallic")

# Servo dropped into its cutout, flange seated on the plate top.
sv = servo(cad, size="standard")
servo_inst = cad.instance(sv)
cad.mate_coincident(servo_inst, "mount_0", plate.servo_seat)
cad.set_color(servo_inst, "#F57C00", finish="matte")

# Four M2.5 screws mated onto the servo's own mount holes, lifted by the
# flange thickness so the heads sit on the flange top. They follow the servo.
m25 = cap_screw(cad, thread="M2.5", length=8)
for i in range(len(SERVO_HOLES)):
    s = cad.instance(m25)
    cad.mate_coincident(s, "under_head", getattr(servo_inst, f"mount_{i}"),
                        offset=(0, 0, SERVO_STD["flange_t"]))
    cad.set_color(s, "#FFC107", finish="metallic")

# Control horn mated onto the servo's output spline.
h = horn(cad, style="single", spline="standard")
arm = cad.instance(h)
cad.mate_coincident(arm, "hub", servo_inst.spline_tip)
cad.set_color(arm, "#ECEFF1", finish="glossy")

# 608 bearing pressed into its seat, 1 mm proud of the 6 mm plate.
b = bearing(cad, designation="608")
brg = cad.instance(b)
cad.mate_coincident(brg, "face_a", plate.bearing_seat)
cad.set_color(brg, "#CFD8DC", finish="metallic")

"""
fuselage.py — a toy-airplane fuselage component.

A rounded body of revolution: a half-silhouette in the xy plane (x = length,
y = radius) revolved 360° about the centerline. Exports the body plus mount
points the wings and tail mate to. Run directly it builds as a normal part;
imported by main.py it scopes into a sub-design and is instanced.
"""

from flywheelcad import *
cad = FlywheelCAD()

with cad.component("fuselage"):
    cad.with_sketch("xy")

    # Half-silhouette: a smooth spline through the profile points (nose tip on the
    # axis, bulging through the body, tapering to the tail tip), closed off by the
    # centerline. Revolved 360° it gives a smoothly curved fuselage.
    p0 = cad.point2d(0, 0)      # nose tip (on centerline)
    p1 = cad.point2d(8, 7)
    p2 = cad.point2d(24, 9)
    p3 = cad.point2d(42, 7)
    p4 = cad.point2d(56, 2)
    p5 = cad.point2d(62, 0)     # tail tip (on centerline)

    silhouette = cad.spline2d([p0, p1, p2, p3, p4, p5])
    axis = cad.line2d(p5, p0)   # the centerline (y = 0); also the revolve axis

    body = cad.revolve("xy",
                       cad.region(loop=[silhouette, axis], inside=(28, 4)),
                       axis, 360)
    cad.component_export(body)

    # Mount points (on the centerline) the other parts mate to.
    nose = cad.point(0, 0, 0)
    wing_mount = cad.point(26, 0, 0)
    tail_mount = cad.point(58, 0, 0)
    cad.component_export_point("nose", nose)
    cad.component_export_point("wing_mount", wing_mount)
    cad.component_export_point("tail_mount", tail_mount)

"""
profiles.py — pure-geometry cross-section generators for the glider.

No FlywheelCAD dependency: each function returns a closed list of (u, v) outline
points ready for a closed `spline2d` on a sketch plane. The caller maps (u, v)
onto the plane's local axes.

  - naca_4412       : cambered wing airfoil (lift-producing).
  - naca_symmetric  : symmetric NACA 00xx airfoil (fin / stabilizer).
  - ellipse_section : elliptical fuselage cross-section.
"""

import math


# ----------------------------------------------------------------------------
# NACA 4-digit thickness distribution (shared)
# ----------------------------------------------------------------------------
def _half_thickness(x, t):
    """Half-thickness at normalized chord x for a NACA 4-digit foil of max
    thickness fraction *t*. The -0.1036 x^4 term closes the trailing edge."""
    return 5 * t * (0.2969 * math.sqrt(x) - 0.1260 * x
                    - 0.3516 * x * x + 0.2843 * x ** 3 - 0.1036 * x ** 4)


def _cosine_xs(n):
    """Cosine-spaced chord samples in [0, 1] (concentrated at LE and TE)."""
    return [0.5 * (1 - math.cos(math.pi * i / n)) for i in range(n + 1)]


def _finish(loop, chord, ox, oy, aoa_deg):
    """Scale a normalized (x, y) loop to *chord*, move *origin* to (0,0), and
    rotate by -aoa so positive aoa raises the leading edge."""
    a = math.radians(aoa_deg)
    ca, sa = math.cos(a), math.sin(a)
    pts = []
    for (x, y) in loop:
        tx = (x - ox) * chord
        ty = (y - oy) * chord
        pts.append((tx * ca + ty * sa, -tx * sa + ty * ca))
    return pts


# ----------------------------------------------------------------------------
# NACA 4412 — cambered wing airfoil
# ----------------------------------------------------------------------------
_M, _P, _T = 0.04, 0.40, 0.12   # 4% camber @ 40% chord, 12% thickness


def _camber(x):
    if x < _P:
        return (_M / _P ** 2) * (2 * _P * x - x * x)
    return (_M / (1 - _P) ** 2) * ((1 - 2 * _P) + 2 * _P * x - x * x)


def _camber_slope(x):
    if x < _P:
        return (2 * _M / _P ** 2) * (_P - x)
    return (2 * _M / (1 - _P) ** 2) * (_P - x)


def naca_4412(chord=1.0, aoa_deg=0.0, n=24, te_thickness=0.0):
    """Closed NACA 4412 outline as (x, y) points, origin at the 30%-chord spar,
    ordered TE -> upper -> LE -> lower for a closed spline. `te_thickness` is a
    fraction of chord (0 = sharp TE; >0 = flat blunt TE of that thickness)."""
    ox, oy = 0.30, _camber(0.30)
    te_half = 0.5 * te_thickness
    xs = _cosine_xs(n)
    upper, lower = [], []
    for x in xs:
        yc = _camber(x)
        yt = _half_thickness(x, _T) + te_half * x
        th = math.atan(_camber_slope(x))
        upper.append((x - yt * math.sin(th), yc + yt * math.cos(th)))
        lower.append((x + yt * math.sin(th), yc - yt * math.cos(th)))
    loop = list(reversed(upper)) + (lower[1:] if te_thickness > 0 else lower[1:-1])
    return _finish(loop, chord, ox, oy, aoa_deg)


# ----------------------------------------------------------------------------
# Symmetric NACA 00xx — fin / stabilizer airfoil
# ----------------------------------------------------------------------------
def naca_symmetric(chord=1.0, thickness=0.10, aoa_deg=0.0, n=24, te_thickness=0.0):
    """Closed symmetric NACA 00xx outline (camber = 0, half-thickness ±). Same
    ordering/args as naca_4412; origin at the 30%-chord spar."""
    ox, oy = 0.30, 0.0
    te_half = 0.5 * te_thickness
    xs = _cosine_xs(n)
    upper, lower = [], []
    for x in xs:
        yt = _half_thickness(x, thickness) + te_half * x
        upper.append((x, yt))
        lower.append((x, -yt))
    loop = list(reversed(upper)) + (lower[1:] if te_thickness > 0 else lower[1:-1])
    return _finish(loop, chord, ox, oy, aoa_deg)


# ----------------------------------------------------------------------------
# Elliptical fuselage cross-section
# ----------------------------------------------------------------------------
def ellipse_section(half_width, half_height, n=28, v_center=0.0):
    """Closed elliptical outline as (u, v) points: u = half_width * cos,
    v = v_center + half_height * sin. `n` evenly-spaced points (no duplicate
    endpoint), ready for a closed spline."""
    return [
        (half_width * math.cos(2 * math.pi * i / n),
         v_center + half_height * math.sin(2 * math.pi * i / n))
        for i in range(n)
    ]

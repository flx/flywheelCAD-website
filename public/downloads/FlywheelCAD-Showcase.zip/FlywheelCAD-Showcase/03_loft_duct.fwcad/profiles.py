# Reusable profile helper for the transition-duct sample.
# ----------------------------------------------------------------------------
# `oval(cad, half_w, half_h)` sketches ONE closed elliptical cross-section on
# the CURRENTLY ACTIVE sketch plane and returns it as a region(...), ready to
# hand to cad.multi_loft(). Keeping the profile in its own module means every
# station is guaranteed identical in shape and only its size changes — exactly
# the kind of small sibling helper the loft workflow encourages.

import math


def oval(cad, half_w, half_h):
    """A closed ellipse centred on the active plane's origin.

    half_w / half_h are the semi-axes along the plane's u (right) and v (up)
    directions. An ellipse is defined by its two foci and one point on the
    curve; we place the foci on whichever axis is longer so the geometry is
    always valid (never two coincident foci)."""
    if half_w >= half_h:
        c = math.sqrt(half_w * half_w - half_h * half_h)          # focal offset
        f1 = cad.point2d(-c, 0.0)
        f2 = cad.point2d(c, 0.0)
        on = cad.point2d(0.0, half_h)                              # top of the curve
    else:
        c = math.sqrt(half_h * half_h - half_w * half_w)
        f1 = cad.point2d(0.0, -c)
        f2 = cad.point2d(0.0, c)
        on = cad.point2d(half_w, 0.0)                             # side of the curve
    e = cad.ellipse2d(f1, f2, on)
    return cad.region(loop=[e], inside=(0.0, 0.0))

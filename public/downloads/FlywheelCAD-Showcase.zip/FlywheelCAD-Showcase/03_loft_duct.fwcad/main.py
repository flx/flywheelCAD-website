# flywheelcad-format: 1
# FlywheelCAD showcase 3 of 5 — Loft through a stack of custom planes
# ============================================================================
# A transition fairing that morphs from a nearly-round inlet to a wide, flat
# outlet. The teaching points are CUSTOM SKETCH PLANES and MULTI-LEVEL LOFT:
#
#   * `create_sketch_plane(p0, px, py)` builds a fresh plane at each station
#     along the duct's axis (here, four planes stacked up +Z).
#   * a reusable `profile.oval(...)` helper (sibling module profiles.py) draws
#     the same kind of closed cross-section on every plane — only its size
#     changes from station to station.
#   * `cad.multi_loft([planes], [regions])` sweeps ONE smooth solid through all
#     four sections with no internal seams.
# ============================================================================

from flywheelcad import *
from profiles import oval

cad = FlywheelCAD()

# Each station: (height z along the axis, semi-width, semi-height).
# The section steadily flattens and widens: round-ish → wide oval.
STATIONS = [
    (0.0,  18.0, 17.0),   # inlet — nearly round
    (30.0, 26.0, 12.0),
    (60.0, 34.0, 9.0),
    (90.0, 40.0, 7.0),    # outlet — wide and flat
]


def plane_at(z):
    """A sketch plane parallel to XY at height z (u = +X, v = +Y)."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


# Build the plane + profile for every station, in order.
planes = []
regions = []
for (z, half_w, half_h) in STATIONS:
    plane = plane_at(z)
    cad.with_sketch(plane)
    planes.append(plane)
    regions.append(oval(cad, half_w, half_h))

# One smooth solid through all four sections.
fairing = cad.multi_loft(planes, regions, edge_radius=0.0)
cad.set_color(fairing, "#26A69A", finish="glossy")

# flywheelcad-format: 1
# FlywheelCAD showcase 1 of 5 — Sketching, constraints & dimensions
# ============================================================================
# The teaching point of this sample is the 2D CONSTRAINT SOLVER, not the body.
#
# We draw a flat mounting bracket as a rough sketch, then pin its shape with
# geometric constraints (horizontal / vertical / parallel) and dimensions that
# are BOUND TO SHARED VARIABLES. Because the dimensions read their values from
# `cad.variable`s, the whole part is parametric: open the Variables panel,
# change WIDTH (or HEIGHT, HOLE_DIA, SLANT), and the sketch re-solves — every
# dependent point and the hole follow.
#
# The sketch is FULLY CONSTRAINED: the solver badge reads "Fully constrained",
# and nothing can be dragged without editing a dimension.
# (FlyWheelCADV3Tests/ShowcaseBracketConstraintTests.swift keeps that true.)
#
# The extrude at the end gives it thickness, with rounded edges.
# ============================================================================

from flywheelcad import *

cad = FlywheelCAD()

# ---- Driving variables ------------------------------------------------------
# `driving=True` variables are held at their value during a solve (so they
# drive the geometry) but stay editable in the Variables panel. Edit one and
# the constraints re-solve the sketch around the new value.
WIDTH    = cad.variable(80.0, driving=True)   # overall bracket width  (mm)
HEIGHT   = cad.variable(50.0, driving=True)   # overall bracket height (mm)
SLANT    = cad.variable(105.0, driving=True)  # angle of the right edge (deg)
HOLE_DIA = cad.variable(9.0, driving=True)    # mounting-hole diameter (mm)

cad.with_sketch("xy")

# ---- Rough outline ----------------------------------------------------------
# A trapezoid: level bottom + top, vertical left edge, and a right edge that
# leans in. Coordinates are only a STARTING GUESS — the solver moves the
# points to satisfy the constraints and dimensions below. They can be written
# with the variables themselves: a point takes a variable or an expression
# and resolves it to a number (a guess, not a dimension — no constraint is
# added), so the rough sketch already sits close to its solved shape.
A = cad.point2d(0.0, 0.0)             # bottom-left  (origin corner)
B = cad.point2d(WIDTH, 0.0)           # bottom-right
C = cad.point2d(WIDTH - 12.0, HEIGHT) # top-right (pulled in by the slant)
D = cad.point2d(0.0, HEIGHT)          # top-left

l_bottom = cad.line2d(A, B)   # consecutive lines SHARE a point ref, so their
l_right  = cad.line2d(B, C)   # touching ends are coincident by construction —
l_top    = cad.line2d(C, D)   # no explicit coincidence constraint needed.
l_left   = cad.line2d(D, A)

# ---- Geometric constraints --------------------------------------------------
cad.coincident(A, origin_xy)          # the origin corner sits ON the origin
cad.horizontal(l_bottom)              # bottom edge is level …
cad.parallel(l_top, l_bottom)         # … and the top edge is parallel to it
cad.vertical(l_left)                  # left edge is plumb (so, square to the bottom)
# (the right edge is left free here — its lean is set by the ANGLE dimension)

# ---- Dimensional constraints, bound to the shared variables -----------------
cad.distance(A, B, WIDTH)             # bottom edge length  = WIDTH
cad.distance(A, D, HEIGHT)            # left edge length    = HEIGHT
cad.angle(l_bottom, l_right, SLANT)   # lean of the right edge

# ---- Mounting hole ----------------------------------------------------------
# A radius given as an expression keeps its link: circle2d emits the radius
# DIMENSION `HOLE_DIA / 2` for you, so editing HOLE_DIA resizes the hole.
# The centre is placed by two point-to-line distances, also expressions.
hc   = cad.point2d(WIDTH * 0.35, HEIGHT / 2.0)
hole = cad.circle2d(hc, HOLE_DIA / 2.0)
cad.point_line_distance(hc, l_bottom, HEIGHT / 2.0)  # centred top-to-bottom
cad.point_line_distance(hc, l_left, WIDTH * 0.35)    # 35% in from the left edge

cad.ensure_convergence()   # solve the sketch now, so a headless render is exact

# ---- Give it thickness ------------------------------------------------------
# The region's directed boundary walks the outline; `holes=` cuts the bore.
# `edge_radius` rounds every edge of the body, so the part needs no sketch
# fillet. (A `cad.fillet` would also work, but today the badge reports two
# DOFs free for any filleted corner — TODO
# `(fillet-leaves-two-dofs-on-a-constrained-sketch)`.)
plate = cad.extrude(
    "xy",
    cad.region(loop=[l_bottom, l_right, l_top, l_left],
               holes=[[hole]],
               inside=(5.0, 5.0)),
    6.0,
    edge_radius=1.5,
)
cad.set_color(plate, "#4FC3F7", finish="metallic")

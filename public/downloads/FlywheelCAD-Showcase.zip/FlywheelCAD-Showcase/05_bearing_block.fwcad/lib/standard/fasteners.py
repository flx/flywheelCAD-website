# flywheelcad standard library
"""Metric fasteners: socket head cap screws, hex nuts, washers — and the
matching NEGATIVE bodies (clearance and tap volumes) for boolean cuts.

Dimensions follow DIN 912 (socket head cap screws), ISO 4032 (hex nuts),
ISO 7089 (flat washers), and ISO 273 medium-fit clearance holes, for
threads M2 through M8.

The negative-body factories are the workflow feature: place a screw AND
cut its hole in two lines —

    from lib.standard.fasteners import cap_screw, clearance
    s = cap_screw(cad, thread="M3", length=12)
    c = clearance(cad, thread="M3", length=12, head_pocket=True)
    screw1 = cad.instance(s, translate=(20, 0, 5))
    cut1 = cad.instance(c, translate=(20, 0, 5), export=False)
    plate = cad.bool_difference(plate, cut1)

Orientation (all parts): the under-head / seating plane is world XY at
z = 0; screws and negatives point DOWN (-Z), heads and pockets up (+Z).

Anchor contract:
    screws:     under_head (0,0,0), head_top, tip
    nuts:       top, bottom (both on the axis)
    washers:    top, bottom
    negatives:  under_head (0,0,0), tip
"""

__library_version__ = "1.0"

import math

# thread: pitch, clearance hole Ø (ISO 273 medium), tap drill Ø,
# DIN 912 head (Ø, height, socket across-flats),
# ISO 4032 nut (across-flats, height), ISO 7089 washer (OD, thickness).
METRIC = {
    "M2":   dict(pitch=0.40, clear_d=2.4, tap_d=1.6,
                 head_d=3.8,  head_h=2.0, socket=1.5,
                 nut_af=4.0,  nut_h=1.6,  washer_od=5.0,  washer_t=0.3),
    "M2.5": dict(pitch=0.45, clear_d=2.9, tap_d=2.05,
                 head_d=4.5,  head_h=2.5, socket=2.0,
                 nut_af=5.0,  nut_h=2.0,  washer_od=6.0,  washer_t=0.5),
    "M3":   dict(pitch=0.50, clear_d=3.4, tap_d=2.5,
                 head_d=5.5,  head_h=3.0, socket=2.5,
                 nut_af=5.5,  nut_h=2.4,  washer_od=7.0,  washer_t=0.5),
    "M4":   dict(pitch=0.70, clear_d=4.5, tap_d=3.3,
                 head_d=7.0,  head_h=4.0, socket=3.0,
                 nut_af=7.0,  nut_h=3.2,  washer_od=9.0,  washer_t=0.8),
    "M5":   dict(pitch=0.80, clear_d=5.5, tap_d=4.2,
                 head_d=8.5,  head_h=5.0, socket=4.0,
                 nut_af=8.0,  nut_h=4.7,  washer_od=10.0, washer_t=1.0),
    "M6":   dict(pitch=1.00, clear_d=6.6, tap_d=5.0,
                 head_d=10.0, head_h=6.0, socket=5.0,
                 nut_af=10.0, nut_h=5.2,  washer_od=12.0, washer_t=1.6),
    "M8":   dict(pitch=1.25, clear_d=9.0, tap_d=6.8,
                 head_d=13.0, head_h=8.0, socket=6.0,
                 nut_af=13.0, nut_h=6.8,  washer_od=16.0, washer_t=1.6),
}

# Dropdown choices for the browser's "Insert from Library" parameter form.
# Every factory (cap_screw, hex_nut, washer, clearance, tap) takes the same
# "thread" domain (the METRIC table's keys) and the same "quality" domain.
PARAM_CHOICES = {
    "*": {
        "thread": ["M2", "M2.5", "M3", "M4", "M5", "M6", "M8"],
        "quality": ["preview", "standard", "high", "ultra"],
    },
}


def _nominal(thread):
    return float(str(thread).lstrip("Mm"))


def _plane_at(cad, z):
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _hexagon(cad, af, cx=0.0, cy=0.0):
    """Hexagon outline from across-flats width, flats up/down."""
    r = (af / 2.0) / math.cos(math.radians(30.0))  # across-corners radius
    pts = []
    for k in range(6):
        a = math.radians(60.0 * k + 30.0)
        pts.append(cad.point2d(cx + r * math.cos(a), cy + r * math.sin(a)))
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


def cap_screw(cad, thread="M3", length=12.0, quality=None):
    """A DIN 912 socket head cap screw (unthreaded shank representation).

    thread: "M2" … "M8";  length: under-head to tip, mm.
    Anchors: under_head (z=0), head_top, tip. Points -Z.
    """
    key = str(thread).upper()
    d = METRIC[key]
    length = float(length)
    nominal = _nominal(key)

    def build():
        head_r, head_h = d["head_d"] / 2.0, d["head_h"]
        # Head + shank as one stepped revolve on zx (radius, height), with
        # a small under-head chamfer step for the catalog silhouette.
        cad.with_sketch("zx")
        q1 = cad.point2d(0.0, -length)
        q2 = cad.point2d(nominal / 2.0, -length)
        q3 = cad.point2d(nominal / 2.0, 0.0)
        q4 = cad.point2d(head_r, 0.0)
        q5 = cad.point2d(head_r, head_h)
        q6 = cad.point2d(0.0, head_h)
        e1 = cad.line2d(q1, q2)
        e2 = cad.line2d(q2, q3)
        e3 = cad.line2d(q3, q4)
        e4 = cad.line2d(q4, q5)
        e5 = cad.line2d(q5, q6)
        e6 = cad.line2d(q6, q1)  # closes along the axis
        solid = cad.revolve("zx",
                            cad.region(loop=[e1, e2, e3, e4, e5, e6],
                                       inside=(nominal / 4.0, -length / 2.0)),
                            axis_line=e6, angle=360.0, quality=quality, export=False)

        # Hex socket recess in the head.
        socket_af = d["socket"]
        depth = head_h * 0.6
        s_plane = _plane_at(cad, head_h + 0.5)
        cad.with_sketch(s_plane)
        hex_outline = _hexagon(cad, socket_af)
        cut = cad.extrude(s_plane,
                          cad.region(loop=hex_outline, inside=(0.0, 0.0)),
                          depth + 0.5, offset=-(depth + 0.5), quality=quality, export=False)

        screw = cad.bool_difference(solid, cut, quality=quality)
        cad.set_color(screw, "#455A64", finish="metallic")
        cad.component_export(screw)

        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("head_top", cad.point(0.0, 0.0, head_h))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"screw_{key.replace('.', '_')}", build,
                          length=length, quality=quality or "std",
                          label=f"{key} x {length:g} cap screw")


def hex_nut(cad, thread="M3", quality=None):
    """An ISO 4032 hex nut. Anchors: bottom (z=0), top. Flats face ±Y."""
    key = str(thread).upper()
    d = METRIC[key]
    nominal = _nominal(key)

    def build():
        cad.with_sketch("xy")
        outline = _hexagon(cad, d["nut_af"])
        bore = cad.circle2d(cad.point2d(0.0, 0.0), nominal / 2.0)
        nut = cad.extrude("xy",
                          cad.region(loop=outline, holes=[[bore]],
                                     inside=(0.0, d["nut_af"] / 2.0 - 0.4)),
                          d["nut_h"], quality=quality)
        cad.set_color(nut, "#455A64", finish="metallic")
        cad.component_export(nut)
        cad.component_export_point("bottom", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, d["nut_h"]))

    return cad.parametric(f"nut_{key.replace('.', '_')}", build,
                          quality=quality or "std",
                          label=f"{key} hex nut")


def washer(cad, thread="M3", quality=None):
    """An ISO 7089 flat washer. Anchors: bottom (z=0), top."""
    key = str(thread).upper()
    d = METRIC[key]
    nominal = _nominal(key)

    def build():
        cad.with_sketch("xy")
        outer = cad.circle2d(cad.point2d(0.0, 0.0), d["washer_od"] / 2.0)
        bore = cad.circle2d(cad.point2d(0.0, 0.0), (nominal + 0.3) / 2.0)
        w = cad.extrude("xy",
                        cad.region(loop=[outer], holes=[[bore]],
                                   inside=(0.0, (d["washer_od"] + nominal) / 4.0)),
                        d["washer_t"], quality=quality)
        cad.set_color(w, "#78909C", finish="metallic")
        cad.component_export(w)
        cad.component_export_point("bottom", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, d["washer_t"]))

    return cad.parametric(f"washer_{key.replace('.', '_')}", build,
                          quality=quality or "std",
                          label=f"{key} washer")


def clearance(cad, thread="M3", length=12.0, head_pocket=False, quality=None):
    """NEGATIVE body: an ISO 273 medium-fit clearance volume to subtract.

    Aligns with cap_screw at the same placement: hole down from z=0 to
    -length (plus a small tip margin so the cut always breaks through);
    head_pocket=True adds a counterbore above z=0 sized for the DIN 912
    head. Subtract it from your part:

        cut = cad.instance(c, translate=..., export=False)
        part = cad.bool_difference(part, cut)

    Anchors: under_head (z=0), tip.
    """
    key = str(thread).upper()
    d = METRIC[key]
    length = float(length)
    pocket = bool(head_pocket)

    def build():
        margin = 1.0
        cad.with_sketch("xy")
        hole = cad.circle2d(cad.point2d(0.0, 0.0), d["clear_d"] / 2.0)
        body = cad.extrude("xy",
                           cad.region(loop=[hole], inside=(0.0, 0.0)),
                           length + margin, offset=-(length + margin),
                           quality=quality, export=False)
        parts = [body]
        if pocket:
            cb_r = d["head_d"] / 2.0 + 0.3
            cb_h = d["head_h"] + 0.4
            cb_plane = _plane_at(cad, cb_h + 6.0)
            cad.with_sketch(cb_plane)
            cb = cad.circle2d(cad.point2d(0.0, 0.0), cb_r)
            parts.append(cad.extrude(cb_plane,
                                     cad.region(loop=[cb], inside=(0.0, 0.0)),
                                     cb_h + 6.0, offset=-(cb_h + 6.0),
                                     quality=quality, export=False))
        cut = parts[0] if len(parts) == 1 else cad.bool_union(*parts, quality=quality)
        cad.set_color(cut, "#EF5350", finish="glass")
        cad.component_export(cut)
        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"clear_{key.replace('.', '_')}", build,
                          length=length, pocket=pocket, quality=quality or "std",
                          label=f"{key} clearance hole" + (" w/ pocket" if pocket else ""))


def tap(cad, thread="M3", length=10.0, quality=None):
    """NEGATIVE body: a tap-drill volume (for threads cut into the part).
    Same orientation as clearance(). Anchors: under_head (z=0), tip."""
    key = str(thread).upper()
    d = METRIC[key]
    length = float(length)

    def build():
        cad.with_sketch("xy")
        hole = cad.circle2d(cad.point2d(0.0, 0.0), d["tap_d"] / 2.0)
        cut = cad.extrude("xy",
                          cad.region(loop=[hole], inside=(0.0, 0.0)),
                          length, offset=-length, quality=quality)
        cad.set_color(cut, "#EF5350", finish="glass")
        cad.component_export(cut)
        cad.component_export_point("under_head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric(f"tap_{key.replace('.', '_')}", build,
                          length=length, quality=quality or "std",
                          label=f"{key} x {length:g} tap drill")
